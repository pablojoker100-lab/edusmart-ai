export type Language = 'en' | 'fr' | 'ar';

export type EducationLevel = 'primary' | 'middle' | 'high' | 'university';

export type ActiveTab =
  | 'dashboard'
  | 'chat'
  | 'code'
  | 'ideas'
  | 'content'
  | 'letters'
  | 'lessons'
  | 'subjects'
  | 'tutor'
  | 'solver'
  | 'explainer'
  | 'summarizer'
  | 'writing'
  | 'quiz'
  | 'progress'
  | 'achievements'
  | 'profile'
  | 'settings'
  | 'auth';

export type LessonSubjectId =
  | 'math'
  | 'physics_chemistry'
  | 'svt'
  | 'philosophy'
  | 'arabic'
  | 'french'
  | 'english';

export interface PracticalExample {
  id: string;
  title: string;
  problem: string;
  solution: string;
  examOrigin?: string;
  tip?: string;
}

export interface DifficultTerm {
  term: string;
  definition: string;
  context?: string;
}

export interface LessonQuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface LessonItem {
  id: string;
  title: string;
  titleFr?: string;
  subjectId: LessonSubjectId;
  level: EducationLevel;
  moroccanTrack?: string;
  unit: string;
  estimatedMinutes: number;
  difficulty: 'easy' | 'medium' | 'hard';
  description: string;
  simplifiedExplanation: {
    introduction: string;
    sections: {
      heading: string;
      content: string;
      keyFormulaOrRule?: string;
    }[];
    conclusion: string;
  };
  practicalExamples: PracticalExample[];
  summaryKeyPoints: string[];
  difficultTerms: DifficultTerm[];
  quiz: LessonQuizQuestion[];
  isCustom?: boolean;
}

export interface UserLessonProgress {
  lessonId: string;
  completed: boolean;
  completedAt?: string;
  isFavorite: boolean;
  quizScore?: number;
  quizTotal?: number;
  quizPassed?: boolean;
  lastStudiedAt?: string;
}

export interface SubjectItem {
  id: string;
  name: string;
  category: 'exact' | 'natural' | 'languages' | 'humanities' | 'tech';
  icon: string;
  description: string;
  topicsCount: number;
  gradient: string;
  topics: string[];
}

export interface AchievementItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  xpReward: number;
  category: 'academic' | 'quiz' | 'consistency' | 'exploration';
  unlocked: boolean;
  progressPercent: number;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  level: EducationLevel;
  createdAt: string;
  avatar?: string;
  xp?: number;
}

export interface StudyHistoryItem {
  id: string;
  type: 'solve' | 'quiz' | 'summary' | 'explain';
  title: string;
  subject?: string;
  date: string;
  timestamp?: string;
  score?: string;
  details?: any;
}

export interface UserProgressData {
  solvedCount: number;
  quizzesTaken: number;
  averageScore: number;
  history: StudyHistoryItem[];
}

export interface SolverStep {
  title: string;
  detail: string;
  formula?: string;
}

export interface SolverResponse {
  subject?: string;
  problemSummary: string;
  steps: SolverStep[];
  finalAnswer: string;
  conceptTip: string;
  isAiGenerated?: boolean;
}

export interface SummaryResponse {
  title: string;
  keyPoints: string[];
  importantTerms: { term: string; definition: string }[];
  quickRecap: string;
}

export interface CorrectionResponse {
  originalText: string;
  correctedText: string;
  improvements: { issue: string; fix: string; reason: string }[];
  fluencyScore: number;
  translatedText?: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface QuizResult {
  score: number;
  total: number;
  questions: QuizQuestion[];
  userAnswers: number[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  imagePreview?: string;
  mode?: string;
  isStreaming?: boolean;
}

export interface ChatConversation {
  id: string;
  title: string;
  createdAt: string;
  messages: ChatMessage[];
  mode: string;
}

export interface IdeaItem {
  id: string;
  title: string;
  category: string;
  description: string;
  keySteps: string[];
  targetAudience?: string;
  potentialImpact?: string;
}

export interface CodeResponse {
  language: string;
  code: string;
  explanation: string;
  timeComplexity?: string;
  spaceComplexity?: string;
  bestPractices: string[];
  outputSimulation?: string;
}

export interface ContentResponse {
  type: string;
  title: string;
  hook: string;
  body: string;
  callToAction: string;
  hashtags: string[];
  tipsForEngagement?: string;
}

export interface LetterResponse {
  purpose: string;
  subject: string;
  salutation: string;
  opening: string;
  bodyParagraphs: string[];
  closing: string;
  signOff: string;
  tone: string;
}

