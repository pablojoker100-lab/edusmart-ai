import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { Language, EducationLevel, ActiveTab, UserProfile, UserProgressData } from './types';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { AppSidebar } from './components/AppSidebar';
import { HomeDashboard } from './components/HomeDashboard';
import { MindChat } from './components/MindChat';
import { CodingAssistant } from './components/CodingAssistant';
import { IdeaGenerator } from './components/IdeaGenerator';
import { ContentCreator } from './components/ContentCreator';
import { LetterComposer } from './components/LetterComposer';
import { EducationalSubjects } from './components/EducationalSubjects';
import { StudyAssistant } from './components/StudyAssistant';
import { StudyProgress } from './components/StudyProgress';
import { PointsAchievements } from './components/PointsAchievements';
import { StudentProfile } from './components/StudentProfile';
import { SettingsView } from './components/SettingsView';
import { HomeworkSolver } from './components/HomeworkSolver';
import { StepExplainer } from './components/StepExplainer';
import { LessonSummarizer } from './components/LessonSummarizer';
import { WritingCorrector } from './components/WritingCorrector';
import { QuizArena } from './components/QuizArena';
import { DeploymentModal } from './components/DeploymentModal';
import { SplashScreen } from './components/SplashScreen';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { OfflineIndicator } from './components/OfflineIndicator';
import { LessonsView } from './components/LessonsLibrary/LessonsView';
import { authService } from './services/authService';

export const App: React.FC = () => {
  // Set Arabic (ar) as primary language with RTL as requested
  const [lang, setLang] = useState<Language>('ar');
  const [level, setLevel] = useState<EducationLevel>('high');
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [isDeploymentOpen, setIsDeploymentOpen] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const [progress, setProgress] = useState<UserProgressData>({
    solvedCount: 0,
    quizzesTaken: 0,
    averageScore: 0,
    history: [],
  });

  const refreshProgress = () => {
    authService.getUserProgress().then(setProgress);
  };

  // Restore authenticated session on mount
  useEffect(() => {
    authService.checkCurrentSession().then((user) => {
      if (user) {
        setCurrentUser(user);
        if (user.level) {
          setLevel(user.level as EducationLevel);
        }
      }
    });
    refreshProgress();
  }, []);

  // Dynamically configure document direction and language attribute for RTL/LTR
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    if (lang === 'ar') {
      document.body.classList.add('font-arabic');
    } else {
      document.body.classList.remove('font-arabic');
    }
  }, [lang]);

  // Handle successful login or registration
  const handleLoginSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    if (user.level) {
      setLevel(user.level as EducationLevel);
    }
    refreshProgress();
    setActiveTab('dashboard');
  };

  // Handle logout
  const handleLogout = async () => {
    await authService.logout();
    setCurrentUser(null);
    refreshProgress();
  };

  return (
    <div className="min-h-screen bg-[#07030e] text-slate-100 flex flex-col font-sans pb-20 md:pb-10 transition-colors selection:bg-purple-600 selection:text-white">
      {/* Animated Mind AI PWA Splash Screen */}
      <AnimatePresence>
        {showSplash && (
          <SplashScreen
            onFinish={() => setShowSplash(false)}
            lang={lang}
          />
        )}
      </AnimatePresence>

      {/* Top Header */}
      <Header
        currentLang={lang}
        onLanguageChange={setLang}
        currentLevel={level}
        onLevelChange={setLevel}
        currentUser={currentUser}
        onOpenAuth={() => setActiveTab('profile')}
        onLogout={handleLogout}
        onNavigateHome={() => setActiveTab('dashboard')}
        onOpenDeployment={() => setIsDeploymentOpen(true)}
        onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
      />

      {/* Quick Navigation Ribbon */}
      <Navigation
        activeTab={activeTab}
        onTabChange={setActiveTab}
        lang={lang}
      />

      {/* Main Layout Area with AppSidebar + Dynamic Viewport */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Easy-to-use Sidebar */}
        <AppSidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          lang={lang}
          isOpenMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
        />

        {/* Dynamic Main Workspace */}
        <main className="flex-1 min-w-0 p-3 sm:p-6 lg:p-8">
          {/* 1. Home Dashboard */}
          {activeTab === 'dashboard' && (
            <HomeDashboard
              lang={lang}
              level={level}
              currentUser={currentUser}
              onNavigate={setActiveTab}
              onOpenDeployment={() => setIsDeploymentOpen(true)}
            />
          )}

          {/* 2. Mind AI Comprehensive Multimodal Chat */}
          {activeTab === 'chat' && <MindChat lang={lang} level={level} />}

          {/* 3. Coding Assistant */}
          {activeTab === 'code' && <CodingAssistant lang={lang} level={level} />}

          {/* 4. Idea & Innovation Generator */}
          {activeTab === 'ideas' && <IdeaGenerator lang={lang} level={level} />}

          {/* 5. Content Creator */}
          {activeTab === 'content' && <ContentCreator lang={lang} level={level} />}

          {/* 6. Letter & Email Composer */}
          {activeTab === 'letters' && <LetterComposer lang={lang} level={level} />}

          {/* 7. Moroccan Curriculum Lessons Library */}
          {activeTab === 'lessons' && (
            <LessonsView
              lang={lang}
              level={level}
              onLevelChange={setLevel}
            />
          )}

          {/* 8. Educational Subjects */}
          {activeTab === 'subjects' && (
            <EducationalSubjects
              lang={lang}
              level={level}
              onNavigate={setActiveTab}
            />
          )}

          {/* 9. AI Study Assistant */}
          {activeTab === 'tutor' && (
            <StudyAssistant
              lang={lang}
              level={level}
            />
          )}

          {/* 10. Study Progress */}
          {activeTab === 'progress' && (
            <StudyProgress
              lang={lang}
              level={level}
              currentUser={currentUser}
              onNavigate={setActiveTab}
            />
          )}

          {/* 11. Points and Achievements */}
          {activeTab === 'achievements' && (
            <PointsAchievements
              lang={lang}
              level={level}
              currentUser={currentUser}
              progress={progress}
              onNavigate={setActiveTab}
            />
          )}

          {/* 12. Student Profile (also covers auth) */}
          {(activeTab === 'profile' || activeTab === 'auth') && (
            <StudentProfile
              lang={lang}
              currentLevel={level}
              currentUser={currentUser}
              progress={progress}
              onLoginSuccess={handleLoginSuccess}
              onLogout={handleLogout}
              onLevelChange={setLevel}
              onNavigateHome={() => setActiveTab('dashboard')}
            />
          )}

          {/* 13. Settings */}
          {activeTab === 'settings' && (
            <SettingsView
              lang={lang}
              onLanguageChange={setLang}
              level={level}
              onLevelChange={setLevel}
              onOpenDeployment={() => setIsDeploymentOpen(true)}
            />
          )}

          {/* Specialized Academic Tools */}
          {activeTab === 'solver' && <HomeworkSolver lang={lang} level={level} />}
          {activeTab === 'explainer' && <StepExplainer lang={lang} level={level} />}
          {activeTab === 'summarizer' && <LessonSummarizer lang={lang} level={level} />}
          {activeTab === 'writing' && <WritingCorrector lang={lang} level={level} />}
          {activeTab === 'quiz' && <QuizArena lang={lang} level={level} />}
        </main>
      </div>

      {/* Offline Status Alert */}
      <OfflineIndicator lang={lang} />

      {/* PWA Android Install Banner */}
      <PWAInstallBanner lang={lang} />

      {/* Public Deployment Modal */}
      <DeploymentModal
        isOpen={isDeploymentOpen}
        onClose={() => setIsDeploymentOpen(false)}
        lang={lang}
      />
    </div>
  );
};

export default App;
