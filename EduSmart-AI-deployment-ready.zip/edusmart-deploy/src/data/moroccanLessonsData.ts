import { LessonItem } from '../types';

export const initialMoroccanLessons: LessonItem[] = [
  // =========================================================================
  // 1. الرياضيات (Mathematics) - 2BAC & 1BAC & 3AC
  // =========================================================================
  {
    id: 'math-limites-continuite',
    title: 'النهايات والاتصال (Limites et Continuité)',
    titleFr: 'Limites et Continuité des fonctions numériques',
    subjectId: 'math',
    level: 'high',
    moroccanTrack: 'الثانية باكالوريا - علوم تجريبية ورياضية',
    unit: 'الوحدة الأولى: التحليل ودراسة الدوال',
    estimatedMinutes: 25,
    difficulty: 'hard',
    description: 'دراسة اتصال دالة عددية في نقطة وعلى مجال، مبرهنة القيم الوسيطية، الدالة العكسية وحساب النهايات غير المحددة.',
    simplifiedExplanation: {
      introduction: 'يعتبر درس النهايات والاتصال حجر الأساس في التحليل الرياضي للباكالوريا المغربية، حيث يسمح بفهم السلوك الموضعي والإجمالي للدوال العددية وتحديد مقاربها وفروعها اللانهائية.',
      sections: [
        {
          heading: '1. اتصال دالة في نقطة وعلى مجال',
          content: 'تكون دالة f متصلة في نقطة x₀ إذا وفقط إذا كانت النهاية عند x₀ تساوي صورة x₀، أي: lim (x -> x₀) f(x) = f(x₀). وتكون متصلة على مجال I إذا كانت متصلة في كل نقطة من هذا المجال. جميع الدوال الحدودية والجذرية والمثلثية متصلة على مجالات تعريفها.',
          keyFormulaOrRule: 'f متصلة في x₀ ⟺ lim_{x \\to x₀^+} f(x) = lim_{x \\to x₀^-} f(x) = f(x₀)'
        },
        {
          heading: '2. مبرهنة القيم الوسيطية (T.V.I)',
          content: 'إذا كانت f دالة متصلة ورتيبة قطعا على مجال [a, b]، وكان f(a) × f(b) < 0، فإن المعادلة f(x) = 0 تقبل حلاً وحيداً α ينتمي إلى المجال المفتوح ]a, b[. تفيد هذه المبرهنة في إثبات وجود حلول المعادلات التي يصعب حلها جبرياً.',
          keyFormulaOrRule: 'f([a, b]) = [f(a), f(b)] (إذا كانت تزايدية قطعا) أو [f(b), f(a)] (إذا كانت تناقصية قطعا)'
        },
        {
          heading: '3. إزالة الأشكال غير المحددة (FI)',
          content: 'الأشكال غير المحددة الأربعة هي: 0/0، ∞/∞، 0 × ∞، و (+∞ - ∞). لإزالتها نستعمل: التعميل بالاختزال، الضرب في المرافق (Conjugate)، أو النهايات المرجعية لدوال sin(x)/x و (1 - cos(x))/x² عند الصفر.',
          keyFormulaOrRule: 'lim_{x \\to 0} \\frac{\\sin(x)}{x} = 1 \\quad , \\quad lim_{x \\to 0} \\frac{1 - \\cos(x)}{x^2} = \\frac{1}{2}'
        }
      ],
      conclusion: 'يمنحك إتقان مبرهنة القيم الوسيطية وحساب النهايات القدرة على تأطير حلول المعادلات وبناء جدول التغيرات ورسم المنحنى البياني بدقة في الامتحان الوطني.'
    },
    practicalExamples: [
      {
        id: 'math-ex-1',
        title: 'تطبيق مبرهنة القيم الوسيطية (نموذج الامتحان الوطني)',
        examOrigin: 'الامتحان الوطني الموحد للباكالوريا - مسلك علوم الحياة والأرض والعلوم الفيزيائية',
        problem: 'لتكن f دالة معرفة على ℝ بما يلي: f(x) = x³ + 2x - 4. بين أن المعادلة f(x) = 0 تقبل حلاً وحيداً α في المجال [1, 2].',
        solution: '1) f دالة حدودية، إذن متصلة على ℝ وبالخصوص على المجال [1, 2].\n2) الدالة المشتقة: f\'(x) = 3x² + 2 > 0 قطعا لكل x ∈ [1, 2]، إذن f تزايدية قطعا على [1, 2].\n3) نحسب الصور: f(1) = 1 + 2 - 4 = -1 < 0، و f(2) = 8 + 4 - 4 = 8 > 0. إذن f(1) × f(2) < 0.\nالخلاصة: حسب مبرهنة القيم الوسيطية، المعادلة f(x) = 0 تقبل حلاً وحيداً α في المجال ]1, 2[.',
        tip: 'احرص دائماً على كتابة الشروط الثلاثة: الاتصال، الرتابة القطعية، وجداء الصورتين أصغر من الصفر لضمان النقطة كاملة.'
      }
    ],
    summaryKeyPoints: [
      'f متصلة في a يعني أن نهاية f(x) عندما يؤول x إلى a تساوي f(a).',
      'صورة مجال بدالة متصلة هي مجال من نفس الطبيعة أو قطعة.',
      'مبرهنة القيم الوسيطية تضمن وجود حلول المعادلات من النوع f(x) = k.',
      'الدالة العكسية f⁻¹ معرفة من f(I) نحو I وتكون متصلة ولها نفس رتابة f.'
    ],
    difficultTerms: [
      { term: 'مبرهنة القيم الوسيطية (T.V.I)', definition: 'مبرهنة رياضية تنص على أن كل دالة متصلة تأخذ جميع القيم المحصورة بين صورتي طرفي المجال.' },
      { term: 'الشكل غير المحدد (Forme indéterminée)', definition: 'حالة حساب نهاية لا تسمح القواعد المباشرة بتحديد قيمتها وتتطلب تحويلاً جبرياً كالمرافق أو التعميل.' }
    ],
    quiz: [
      {
        id: 'q-math-1',
        question: 'إذا كانت f دالة متصلة وتزايدية قطعا على [0, 3] مع f(0) = -2 و f(3) = 5، فكم حلاً للمعادلة f(x) = 0 في [0, 3]؟',
        options: ['حلان مختلفان', 'حل وحيد تماماً', 'لا يوجد أي حل', 'عدد لا نهائي من الحلول'],
        correctIndex: 1,
        explanation: 'بما أن f متصلة وتزايدية قطعا و f(0) × f(3) = -10 < 0، فإن حسب T.V.I يوجد حل وحيد α.'
      },
      {
        id: 'q-math-2',
        question: 'ما هي قيمة النهاية lim_{x -> 0} (sin(3x) / x)؟',
        options: ['0', '1', '3', 'غير معرفة'],
        correctIndex: 2,
        explanation: 'نكتب sin(3x)/x على شكل 3 × (sin(3x)/(3x))، وبما أن lim_{X -> 0} sin(X)/X = 1 فإن النتيجة هي 3.'
      }
    ]
  },
  {
    id: 'math-suites-numeriques',
    title: 'المتتاليات العددية (Suites Numériques)',
    titleFr: 'Suites Numériques et convergence',
    subjectId: 'math',
    level: 'high',
    moroccanTrack: 'الثانية والأولى باكالوريا - جميع الشعب العلمية والتقنية',
    unit: 'الوحدة الثانية: المتتاليات العددية والتقارب',
    estimatedMinutes: 20,
    difficulty: 'medium',
    description: 'البرهان بالترجع، المتتاليات الحسابية والهندسية، المتتاليات الرتيبة والمكبورة والمصغورة ومبرهنات التقارب.',
    simplifiedExplanation: {
      introduction: 'المتتالية العددية هي دالة معرفة على مجموعة الأعداد الصحيحة الطبيعية ℕ. تشكل موضوعاً رئيسياً ثابتاً في التمرين الأول من الامتحان الوطني للباكالوريا المغربية.',
      sections: [
        {
          heading: '1. مبدأ البرهان بالترجع (Raisonnement par récurrence)',
          content: 'يتكون من ثلاث خطوات إلزامية:\nأ) التحقق من أجل الحد الأول n₀ (غالباً n=0 أو n=1).\nب) الافتراض: نفترض أن الخاصية P(n) صحيحة من أجل n معين.\nج) الاستنتاج: نبين أن P(n+1) صحيحة، ثم نستنتج أن P(n) صحيحة لكل n ≥ n₀.',
          keyFormulaOrRule: 'P(n₀) \\text{ صحيحة } \\land (P(n) \\implies P(n+1)) \\implies (\\forall n \\ge n₀) P(n)'
        },
        {
          heading: '2. المتتاليات الحسابية والمتتاليات الهندسية',
          content: 'المتتالية الحسابية: u_{n+1} = u_n + r (الحد العام: u_n = u_p + (n-p)r). المتتالية الهندسية: v_{n+1} = q × v_n (الحد العام: v_n = v_p × q^{n-p}).',
          keyFormulaOrRule: 'S_n = \\frac{(n - p + 1)(u_p + u_n)}{2} \\quad , \\quad S_n = v_p \\frac{1 - q^{n - p + 1}}{1 - q}'
        },
        {
          heading: '3. مبرهنات تقارب المتتاليات',
          content: 'كل متتالية تزايدية ومكبورة هي متتالية متقاربة. وكل متتالية تناقصية ومصغورة هي متتالية متقاربة. إذا كانت -1 < q < 1 فإن lim (qⁿ) = 0.',
          keyFormulaOrRule: '(u_n \\text{ تزايدية و مكبورة}) \\implies u_n \\text{ متقاربة (تقبل نهاية منتهية)}'
        }
      ],
      conclusion: 'المتتاليات المساعدة v_n المرتبطة بـ u_n هي المفتاح الكلاسيكي في الامتحانات الوطنية لحساب نهاية u_n والتعبير عنها بدلالة n.'
    },
    practicalExamples: [
      {
        id: 'math-ex-2',
        title: 'حساب نهاية متتالية باستعمال متتالية هندسية مساعدة',
        examOrigin: 'الامتحان الوطني الموحد - الدورة العادية',
        problem: 'لتكن المتتالية (u_n) المعرفة بـ: u₀ = 2 و u_{n+1} = (1/3) u_n + 2. نعتبر المتتالية (v_n) المعرفة بـ: v_n = u_n - 3.\nأ) بين أن (v_n) متتالية هندسية محدداً أساسها وحدها الأول.\nب) اكتب u_n بدلالة n ثم احسب نهاية u_n.',
        solution: 'أ) v_{n+1} = u_{n+1} - 3 = (1/3)u_n + 2 - 3 = (1/3)u_n - 1 = (1/3)(u_n - 3) = (1/3) v_n.\nإذن (v_n) هندسية أساسها q = 1/3 وحدها الأول v₀ = u₀ - 3 = 2 - 3 = -1.\nب) بما أن v_n = v₀ × qⁿ = -(1/3)ⁿ، ولدينا u_n = v_n + 3، إذن u_n = 3 - (1/3)ⁿ.\nبما أن -1 < 1/3 < 1 فإن lim (1/3)ⁿ = 0، وبالتالي lim u_n = 3.',
        tip: 'الأساس q ينحصر بين -1 و 1 دائماً يضمن أن نهاية qⁿ تساوي 0.'
      }
    ],
    summaryKeyPoints: [
      'البرهان بالترجع يستلزم: التحقق، الافتراض، والبرهان على الخطوة التالية.',
      'إذا كانت المتتالية مكبورة بعدد M وتزايدية، فنهايتها l أصغر من أو تساوي M.',
      'نهاية المتتالية الهندسية: إذا كان |q| < 1 فالنهاية 0، وإذا كان q > 1 فالنهاية +∞.'
    ],
    difficultTerms: [
      { term: 'متتالية مكبورة (Suite majorée)', definition: 'متتالية يوجد عدد حقيقي M بحيث كل حدودها u_n أصغر من أو تساوي M لجميع n.' },
      { term: 'تقارب متتالية (Convergence)', definition: 'خاصية تعني أن المتتالية تقترب من عدد حقيقي ثابت ومنتهٍ عندما يؤول n إلى +∞.' }
    ],
    quiz: [
      {
        id: 'q-math-3',
        question: 'إذا كانت v_n متتالية هندسية أساسها q = 0.5 وحدها الأول v₀ = 4، فما هي نهاية v_n عند +∞؟',
        options: ['4', '2', '0', '+∞'],
        correctIndex: 2,
        explanation: 'بما أن القيمة المطلقة للأساس |q| = 0.5 < 1، فإن نهاية v_n عند اللانهاية تكون دائماً 0.'
      }
    ]
  },

  // =========================================================================
  // 2. الفيزياء والكيمياء (Physics & Chemistry)
  // =========================================================================
  {
    id: 'pc-ondes-mecaniques',
    title: 'الموجات الميكانيكية المتوالية (Ondes Mécaniques Progressives)',
    titleFr: 'Les Ondes Mécaniques Progressives',
    subjectId: 'physics_chemistry',
    level: 'high',
    moroccanTrack: 'الثانية باكالوريا - علوم تجريبية ورياضية',
    unit: 'الوحدة الأولى: الموجات (Physique)',
    estimatedMinutes: 20,
    difficulty: 'medium',
    description: 'تعريف الموجة الميكانيكية، الموجة الطولية والمستعرضة، سرعة الانتشار، التأخر الزمني، وظاهرة الحيود.',
    simplifiedExplanation: {
      introduction: 'الموجة الميكانيكية هي ظاهرة انتشار تشوه في وسط مادي مرن مع انتقال للطاقة دون انتقال للمادة. تنقسم إلى طولية ومستعرضة وتعد مدخلاً أساسياً في الفيزياء بالباكالوريا المغربية.',
      sections: [
        {
          heading: '1. تصنيف الموجات: مستعرضة وطولية',
          content: '• الموجة المستعرضة: يكون فيها اتجاه تشوه النقط عمودياً على اتجاه الانتشار (مثال: موجة طول حبل، موجة فوق سطح الماء).\n• الموجة الطولية: يكون فيها اتجاه التشوه موازياً لاتجاه الانتشار (مثال: موجة طول نابض، الموجات الصوتية في الهواء).',
          keyFormulaOrRule: 'v = \\frac{d}{\\Delta t} \\quad (\\text{m/s})'
        },
        {
          heading: '2. التأخر الزمني (Retard temporel θ)',
          content: 'حركة نقطة M من وسط الانتشار تعيد نفس حركة المنبع S بتأخر زمني θ = SM / v. استطالة النقطة M عند اللحظة t هي: y_M(t) = y_S(t - θ).',
          keyFormulaOrRule: '\\theta = \\frac{SM}{v} \\quad \\implies y_M(t) = y_S(t - \\theta)'
        },
        {
          heading: '3. طول الموجة والدورية الزمانية والمكانية',
          content: 'طول الموجة λ هو المسافة المقطوعة خلال دور زمني T واحد بواسطة الموجة المتوالية الجيبية. التردد N = 1/T يقاس بالهرتز (Hz).',
          keyFormulaOrRule: '\\lambda = v \\times T = \\frac{v}{N}'
        }
      ],
      conclusion: 'الموجة لا تنقل المادة إطلاقاً بل تنقل الطاقة فقط، وسرعة انتشارها تتعلق بطبيعة الوسط الفيزيائي (صلابته ودرجة حرارته وكثافته).'
    },
    practicalExamples: [
      {
        id: 'pc-ex-1',
        title: 'حساب سرعة انتشار موجة فوق صوتية في سائل مجهول',
        examOrigin: 'الامتحان الوطني الموحد - مسلك العلوم الرياضية والفيزيائية',
        problem: 'يبعث مجس جهاز فحص بالصدى موجة فوق صوتية ترددها N = 5 MHz تنتشر في نسيج حيوي، فتصل إلى عاكس يبعد بمسافة d = 6 cm وتعود لتلتقط بعد مدة زمنية Δt = 80 µs.\n1. احسب سرعة انتشار الموجة في هذا النسيج.\n2. احسب طول الموجة λ.',
        solution: '1) المسافة المقطوعة ذهاباً وإياباً هي 2d. إذن السرعة: v = 2d / Δt = (2 × 0.06 m) / (80 × 10⁻⁶ s) = 1500 m/s.\n2) طول الموجة: λ = v / N = 1500 / (5 × 10⁶) = 3 × 10⁻⁴ m = 0.3 mm.',
        tip: 'في تجارب الصدى (Écho) انتبه دائماً إلى أن الموجة تقطع المسافة مرتين (ذهاباً وإياباً): D = 2d.'
      }
    ],
    summaryKeyPoints: [
      'الموجة الميكانيكية تحتاج لوسط مادي مرن للانتشار ولا تنتشر في الفراغ.',
      'الصوت موجة ميكانيكية طولية ثلاثية الأبعاد.',
      'سرعة الموجة في الحبل تزداد بزيادة التوتر وتنخفض بزيادة الكتلة الطولية: v = √(T/μ).',
      'ظاهرة الحيود تحدث عندما تصادف الموجة حاجزاً به فتحة عرضها a أصغر من أو يقارب طول الموجة λ.'
    ],
    difficultTerms: [
      { term: 'الموجة المستعرضة (Onde transversale)', definition: 'موجة يكون فيها اتجاه تشويه الوسط متعامداً مع اتجاه انتشار الإشارة.' },
      { term: 'التأخر الزمني (Retard temporel)', definition: 'المدة الزمنية التي تفصل بين وصول مقدمة الموجة إلى نقطتين مختلفتين في وسط الانتشار.' }
    ],
    quiz: [
      {
        id: 'q-pc-1',
        question: 'أي من الموجات التالية لا يمكنها الانتشار في الفراغ؟',
        options: ['الموجات الضوئية', 'الموجات الصوتية', 'موجات الراديو', 'الأشعة السينية'],
        correctIndex: 1,
        explanation: 'الموجات الصوتية ميكانيكية تحتاج بالضرورة إلى وسط مادي ملموس للانتشار، وبالتالي لا تنتشر في الفراغ إطلاقاً.'
      }
    ]
  },
  {
    id: 'pc-circuit-rc',
    title: 'ثنائي القطب RC (Le Dipôle RC)',
    titleFr: 'Réponse d\'un dipôle RC à un échelon de tension',
    subjectId: 'physics_chemistry',
    level: 'high',
    moroccanTrack: 'الثانية باكالوريا - جميع الشعب العلمية والتقنية',
    unit: 'الوحدة الثانية: الكهرباء (Électricité)',
    estimatedMinutes: 25,
    difficulty: 'hard',
    description: 'شحن وتفريغ المكثف، المعادلة التفاضلية لتوتر المكثف، حل المعادلة، ثابتة الزمن τ، والطاقة المخزونة.',
    simplifiedExplanation: {
      introduction: 'المكثف ثنائي قطب قادر على تخزين شحنة كهربائية وطاقة كهرساكنة واسترجاعها بسرعة. يمثل ثنائي القطب RC الدائرة الكلاسيكية الأهم في امتحانات الفيزياء الوطنية.',
      sections: [
        {
          heading: '1. العلاقة بين الشحنة والتوتر وشدة التيار',
          content: 'شحنة المكثف q تتناسب طردياً مع التوتر بين مربطيه u_C: q = C × u_C (حيث C سعة المكثف بالفاراد F). وشدة التيار هي مشتقة الشحنة بالنسبة للزمن: i(t) = dq/dt = C × (du_C/dt).',
          keyFormulaOrRule: 'q(t) = C \\cdot u_C(t) \\quad , \\quad i(t) = C \\frac{du_C}{dt}'
        },
        {
          heading: '2. المعادلة التفاضلية أثناء الشحن وحلها',
          content: 'بتطبيق قانون إضافية التوترات: u_R + u_C = E، وبما أن u_R = R × i = R × C (du_C/dt)، نحصل على: u_C + RC(du_C/dt) = E. حلها يكتب: u_C(t) = E(1 - e^{-t/τ}) مع τ = RC.',
          keyFormulaOrRule: 'u_C(t) + \\tau \\frac{du_C}{dt} = E \\quad \\text{مع } \\tau = RC'
        },
        {
          heading: '3. ثابتة الزمن τ والطاقة المخزونة',
          content: 'ثابتة الزمن τ = RC تمثل المدة التي يصل فيها توتر المكثف إلى 63% من قيمته القصوى E أثناء الشحن. الطاقة الكهرساكنة المخزونة في المكثف هي E_e = 0.5 × C × u_C².',
          keyFormulaOrRule: 'E_e = \\frac{1}{2} C u_C^2 = \\frac{1}{2} \\frac{q^2}{C}'
        }
      ],
      conclusion: 'تحديد τ بيانياً يتم عبر مماس المنحنى عند t=0 وتقاطعه مع المقارب u_C = E، أو بقراءة قيمة u_C عند 0.63 E.'
    },
    practicalExamples: [
      {
        id: 'pc-ex-2',
        title: 'إيجاد سعة مكثف C انطلاقاً من منحنى الشحن',
        examOrigin: 'الامتحان الوطني الموحد - مسلك علوم تجريبية',
        problem: 'ننجز دارة شحن مكثف عبر موصل أومي مقاومته R = 2 kΩ ومولد قوته الكهرومحركة E = 6 V. أظهر راسم التذبذب أن المماس عند الأصل يتقاطع مع المقارب u_C = 6 V عند اللحظة t = 4 ms.\n1. استنتج قيمة ثابتة الزمن τ.\n2. احسب سعة المكثف C والطاقة القصوى المخزونة.',
        solution: '1) بيانياً، نقطة تقاطع المماس عند t=0 مع المقارب الأفقي u_C = E تعطي مباشرة ثابتة الزمن: τ = 4 ms = 4 × 10⁻³ s.\n2) بما أن τ = R × C، فإن C = τ / R = (4 × 10⁻³) / (2 × 10³) = 2 × 10⁻⁶ F = 2 µF.\n3) الطاقة المخزونة القصوى: E_e,max = 0.5 × C × E² = 0.5 × (2 × 10⁻⁶) × 6² = 3.6 × 10⁻⁵ Joules.',
        tip: 'تأكد دائماً من تحويل الوحدات: R بالأوم (Ω)، t بالثانية (s)، والسعة بالفاراد (F).'
      }
    ],
    summaryKeyPoints: [
      'التوتر u_C دالة زمنية متصلة ولا تقبل انقطاعاً لحظياً (لا يقفز فجأة).',
      'عند النظام الدائم (t > 5τ)، المكثف مشحون كلياً ويتصرف كقاطع تيار مفتوح (i = 0).',
      'معادلة الأبعاد تبين أن بعد المقدار RC هو بعد زمني [τ] = T.'
    ],
    difficultTerms: [
      { term: 'سعة المكثف (Capacité)', definition: 'مقدار فيزيائي موجب يعبر عن قدرة المكثف على تخزين الشحنات الكهربائية، ويقاس بالفاراد (F).' },
      { term: 'ثابتة الزمن τ', definition: 'مقدار يعبر عن سرعة استجابة الدارة RC وتساوي الجداء RC وتقاس بالثانية.' }
    ],
    quiz: [
      {
        id: 'q-pc-2',
        question: 'ما هي النسبة المئوية لشحن المكثف عند اللحظة t = τ؟',
        options: ['50%', '63%', '86%', '100%'],
        correctIndex: 1,
        explanation: 'عند t = τ، u_C(τ) = E(1 - e⁻¹) ≈ E(1 - 0.37) = 0.63 E، أي 63% من الشحن الكامل.'
      }
    ]
  },

  // =========================================================================
  // 3. علوم الحياة والأرض (SVT)
  // =========================================================================
  {
    id: 'svt-atp-energie',
    title: 'استهلاك المادة العضوية وتدفق الطاقة (Consommation de la Matière Organique et Flux d\'Énergie)',
    titleFr: 'Consommation de la matière organique et libération de l\'énergie cellulaire',
    subjectId: 'svt',
    level: 'high',
    moroccanTrack: 'الثانية باكالوريا - علوم الحياة والأرض والعلوم الفيزيائية والزراعية',
    unit: 'الوحدة الأولى: استهلاك المادة العضوية وتدفق الطاقة',
    estimatedMinutes: 25,
    difficulty: 'medium',
    description: 'انحلال الجليكوز في الجبلة الشفافة، التنفس الخلوي في الميتوكندري (دورة كريبس وسلسلة التنفس)، التخمر اللبني والكحولي، والحصيلة الطاقية لـ ATP.',
    simplifiedExplanation: {
      introduction: 'تستمد الخلايا الحية طاقتها الضرورية لأنشطتها من هدم المادة العضوية (خصوصاً سكر الجلوكوز) لتركيب جزيئات ATP إما عن طريق مسلك التنفس الهوائي أو مسلك التخمر اللاهوائي.',
      sections: [
        {
          heading: '1. مرحلة انحلال الجليكوز (La Glycolyse)',
          content: 'مرحلة مشتركة بين التنفس والتخمر، تحدث في الجبلة الشفافة (Hyaloplasme) بدون الحاجة للأكسجين O₂. خلالها ينشطر جزيء الجلوكوز (C₆H₁₂O₆) إلى جزيئين من حمض البيروفيك (2 CH₃-CO-COOH) مع إنتاج 2 ATP واختزال 2 NAD⁺ إلى 2 NADH,H⁺.',
          keyFormulaOrRule: 'C_6H_{12}O_6 + 2ADP + 2Pi + 2NAD^+ \\longrightarrow 2CH_3COCOOH + 2ATP + 2NADH,H^+'
        },
        {
          heading: '2. دورة كريبس داخل الماتريس (Cycle de Krebs)',
          content: 'في وسط هوائي، ينفذ حمض البيروفيك إلى الميتوكندري، فيتحول إلى أسيتيل كوانزيم A ثم يدخل دورة كريبس حيث تتم أكسدة تامة مع تحرير غاز CO₂ وإنتاج مركبات ناقلة مختزلة (NADH,H⁺ و FADH₂) وجزيئات ATP.',
          keyFormulaOrRule: 'أكسدة حمض بيروفيك واحد داخل الميتوكندري تنتج: 4 NADH,H^+ + 1 FADH_2 + 1 ATP + 3 CO_2'
        },
        {
          heading: '3. الفسفرة التأكسدية والحصيلة الطاقية',
          content: 'على مستوى الغشاء الداخلي للميتوكندري (السلسلة التنفسية)، تؤكسد النواقل المختزلة وتتدفق الإلكترونات نحو O₂ (المتقبل النهائي)، مما يولد ممالاً للبروتونات H⁺ عبر الكرات ذات شمراخ لفسفرة ADP إلى ATP. الحصيلة الإجمالية لهدم جزيء جلوكوز بالتنفس هي 38 (أو 36) ATP مقابل 2 ATP فقط في التخمر.',
          keyFormulaOrRule: 'المردود الطاقي: التنفس الخلوي (40.5%) مقابل التخمر (2.1%)'
        }
      ],
      conclusion: 'التنفس الخلوي هدم تام للمادة العضوية ينتج حثالة معدنية خالية من الطاقة (CO₂ و H₂O)، بينما التخمر هدم جزئي ينتج حثالة عضوية ما زالت غنية بالطاقة كالحمض اللبني أو الكحول.'
    },
    practicalExamples: [
      {
        id: 'svt-ex-1',
        title: 'مقارنة المجهود العضلي السريع والمجهود المطول',
        examOrigin: 'الامتحان الوطني الموحد - مسلك العلوم الرياضية والتجريبية',
        problem: 'أظهرت تحاليل دم عداء في سباق 100 متر وجود تركيز مرتفع من الحمض اللبني ونقص طفيف في الجلوكوز، بينما عداء الماراثون يستهلك كميات كبيرة من O₂ دون تراكم للحمض اللبني.\nفسر المسلك الاستقلابي المهيمن لدى كل عداء.',
        solution: '• عداء 100 متر: يقوم بمجهود عضلي عنيف وقصير الأمد، تلجأ خلاله الألياف العضلية السريعة (نوع II) إلى مسلك التخمر اللبني اللاهوائي لإنتاج ATP سريعاً وبدون انتظار وصول O₂، ما يؤدي لتراكم الحمض اللبني والتعب العضلي.\n• عداء الماراثون: مجهود عضلي معتدل ومطول، تلجأ الألياف البطيئة (نوع I) الغنية بالميتوكندريات إلى مسلك التنفس الخلوي الهوائي نظراً لغزارة إنتاجه من ATP (38 ATP) مع استهلاك تام للأكسجين وطرح الماء وCO₂ دون إنتاج حمض لبني.',
        tip: 'اربط دائماً نوع النشاط العضلي بالمسلك الاستقلابي (قصير وسريع = تخمر لبني، طويل ومستمر = تنفس هوائي).'
      }
    ],
    summaryKeyPoints: [
      'انحلال الجليكوز يحدث في الجبلة الشفافة وهو لا هوائي ومشترك بين التنفس والتخمر.',
      'الميتوكندري هي العضي الخلوي المسؤول عن التنفس وإنتاج الجزء الأكبر من ATP.',
      'أكسدة جزيء NADH,H⁺ واحد في السلسلة التنفسية تعطي 3 ATP، وجزيء FADH₂ يعطي 2 ATP.',
      'التخمر هدم جزئي مردوده الطاقي ضعيف جداً مقارنة بالتنفس.'
    ],
    difficultTerms: [
      { term: 'كرات ذات شمراخ (Sphères pédonculées)', definition: 'مجمعات أنزيمية (ATP Synthase) توجد في الغشاء الداخلي للميتوكندري مسؤولة عن تركيب ATP عند عودة البروتونات H⁺ للماتريس.' },
      { term: 'الجبلة الشفافة (Hyaloplasme)', definition: 'السائل الخلوي الأساسي بدون العضيات الخلوية وفيه تتم مرحلة انحلال الجليكوز.' }
    ],
    quiz: [
      {
        id: 'q-svt-1',
        question: 'أين تحدث مرحلة انحلال الجليكوز داخل الخلية؟',
        options: ['داخل ماتريس الميتوكندري', 'في الجبلة الشفافة', 'في النواة', 'في الغشاء الهيولي'],
        correctIndex: 1,
        explanation: 'انحلال الجليكوز يتم حصراً في الجبلة الشفافة دون الحاجة لوجود الأكسجين.'
      }
    ]
  },

  // =========================================================================
  // 4. الفلسفة (Philosophie)
  // =========================================================================
  {
    id: 'philo-personne-identite',
    title: 'مفهوم الشخص: الشخص والهوية (La Personne et l\'Identité)',
    titleFr: 'Le concept de la personne: L\'identité personnelle',
    subjectId: 'philosophy',
    level: 'high',
    moroccanTrack: 'الثانية باكالوريا - جميع المسالك والشعب المغربية',
    unit: 'المجزوءة الأولى: الوضع البشري',
    estimatedMinutes: 20,
    difficulty: 'medium',
    description: 'إشكالية هوية الشخص: على ماذا تتأسس هوية الشخص ووحدته وثباته عبر الزمان؟ مواقف ديكارت، جون لوك، شوبنهاور، ولاكان.',
    simplifiedExplanation: {
      introduction: 'يمثل الشخص الكائن الإنساني الواعي المفكر والمسؤول أخلاقياً وقانونياً. تطرح هوية الشخص إشكالاً فلسفياً محورياً: ما الذي يجعل الشخص هو هو، مطابقاً لذاته ومتميزاً عن غيره رغم التحولات الجسدية والنفسية والزمنية؟',
      sections: [
        {
          heading: '1. الموقف العقلاني الديكارتي (رينيه ديكارت)',
          content: 'يرى ديكارت أن هوية الشخص تتأسس على الفكر الخالص ("الكوجيطو: أنا أفكر إذن أنا موجود"). فالشخص جوهر مفكر (Res cogitans) مستقل عن الجسد، والوعي بالذات من خلال الشك والتأمل هو الضامن الوحيد لثبات الهوية.',
          keyFormulaOrRule: 'الأطروحة: الفكر والوعي المجرد هما أساس الهوية الذاتية الثابتة.'
        },
        {
          heading: '2. الموقف التجريبي الحسي (جون لوك)',
          content: 'ينتقد جون لوك فكرة الجوهر الفطري الديكارتي، ويؤكد أن هوية الشخص تتأسس على الشعور المقترن بالذاكرة (Consciousness & Memory). فالإنسان صفحة بيضاء، وإدراكه الحسي المقترن بذاكرته التي تسترجع أفعاله الماضية هو ما يصنع امتداد هويته عبر الزمن.',
          keyFormulaOrRule: 'الأطروحة: الوعي الحسي المقترن بالذاكرة هو ركيزة الهوية الشخصية.'
        },
        {
          heading: '3. موقف فلسفة الإرادة (أرتور شوبنهاور)',
          content: 'يرى شوبنهاور أن الذاكرة والشعور معرضان للنسيان والتلف والمرض، وبالتالي لا يمكنهما تشكيل جوهر ثابت. الهوية الحقيقية للإنسان تكمن في "إرادة الحياة" (La volonté de vivre)، وهي جوهر ميتافيزيقي غريزي ثابت لا يتغير حتى مع تغير الجسد أو فقدان الذاكرة.',
          keyFormulaOrRule: 'الأطروحة: إرادة الحياة هي النواة الباطنية الثابتة لهوية الشخص.'
        }
      ],
      conclusion: 'هوية الشخص ليست معطى جاهزاً أو أحادي البعد، بل هي بناء ديناميكي يتشابك فيه العقل والذاكرة والإرادة والبعد الوجودي للإنسان.'
    },
    practicalExamples: [
      {
        id: 'philo-ex-1',
        title: 'صياغة المفارقة وتحليل السؤال الفلسفي في الامتحان الوطني',
        examOrigin: 'الامتحان الوطني الموحد للباكالوريا - الدورة العادية (مادة الفلسفة)',
        problem: 'حلل وناقش القولة التالية: "هل تتوقف هوية الشخص على ما يتذكره فقط؟"',
        solution: 'المطلب الأول (الفهم): إبراز مجال الوضع البشري ومفهوم الشخص وإشكالية أساس الهوية بين الذاكرة وعناصر أخرى كالإرادة والفكر.\nالمطلب الثاني (التحليل): بسط أطروحة جون لوك التي تجعل الذاكرة شرطاً حاسماً للوعي بالذات وتماسكها عبر استحضار الماضي.\nالمطلب الثالث (المناقشة): إبراز حدود موقف لوك باستحضار شوبنهاور (الذاكرة عرضة للزهايمر والحوادث دون أن يفقد الإنسان هويته الإنسانية)، واستحضار ديكارت (العقل الفطري).\nالمطلب الرابع (التركيب): خلاصة تركيبية تبرز تكامل أبعاد الشخص الجسدية والواعية والإرادية.',
        tip: 'في منهجية القولة والسؤال، ركز على بناء "المفارقة" الفلسفية (Paradoxe) في المقدمة لتنال 4/4 في الفهم.'
      }
    ],
    summaryKeyPoints: [
      'ديكارت: أساس الهوية هو الفكر المجرد (الكوجيطو).',
      'جون لوك: أساس الهوية هو الاقتران بين الإدراك الحسي والذاكرة.',
      'شوبنهاور: أساس الهوية هو إرادة الحياة لأنها عصية على النسيان والتلاشي.',
      'فرويد: الشخص محكوم بصراع بين الهو والأنا والأنا الأعلى.'
    ],
    difficultTerms: [
      { term: 'الهوية الشخصية (Identité personnelle)', definition: 'خاصية مطابقة الشخص لذاته وثباته ككائن مفرد ومتميز عن غيره عبر مختلف الأزمنة والظروف.' },
      { term: 'الكوجيطو (Cogito)', definition: 'المبدأ الفلسفي الديكارتي القائم على انطلاق اليقين من فعل الشك والتفكير ("Je pense donc je suis").' }
    ],
    quiz: [
      {
        id: 'q-philo-1',
        question: 'من هو الفيلسوف الذي اعتبر الذاكرة المقترنة بالإدراك الحسي أساس هوية الشخص؟',
        options: ['رينيه ديكارت', 'جون لوك', 'باروخ سبينوزا', 'أرتور شوبنهاور'],
        correctIndex: 1,
        explanation: 'جون لوك، رائد الفلسفة التجريبية، هو من أقر بأن استمرار الوعي عبر الذاكرة هو ما يؤسس الهوية الشخصية.'
      }
    ]
  },

  // =========================================================================
  // 5. اللغة العربية (Langue Arabe)
  // =========================================================================
  {
    id: 'arabic-ehyaa-namoudaj',
    title: 'مكون النصوص: خطاب إحياء النموذج (البعث والإحياء)',
    titleFr: 'Le mouvement de la renaissance poétique (Ihyaa An-namoudaj)',
    subjectId: 'arabic',
    level: 'high',
    moroccanTrack: 'الثانية باكالوريا - مسلك الآداب والعلوم الإنسانية والعلوم التجريبية',
    unit: 'الوحدة الأولى: من إحياء النموذج إلى سؤال الذات',
    estimatedMinutes: 20,
    difficulty: 'medium',
    description: 'السياق التاريخي لظهور حركة البعث والإحياء، خصائصها المضمونية والشكلية (المعجم التراثي، الإيقاع الخليلي، والصور البيانية التقليدية)، وروادها.',
    simplifiedExplanation: {
      introduction: 'ظهرت حركة إحياء النموذج في نهاية القرن التاسع عشر وبداية القرن العشرين كرد فعل على عصر الانحطاط والركود، مستهدفة استعادة بهاء القصيدة العربية القديمة في عصور ازدهارها (الجاهلي، العباسي، والأندلسي).',
      sections: [
        {
          heading: '1. السياق التاريخي وعوامل الظهور',
          content: 'تضافرت عدة عوامل أفرزت الحركة: حملة نابليون، حركة الترجمة والطباعة، البعثات التعليمية، والشعور بضرورة النهضة والتحرر القومي والعودة للذات العربية الأصيلة من خلال التراث الشعري المتين.',
          keyFormulaOrRule: 'الهدف: محاكاة فحول الشعراء القدامى لانتشال الشعر العربي من عقم عصر الانحطاط والمحسنات البديعية المتكلفة.'
        },
        {
          heading: '2. الخصائص الفنية والمضمونية',
          content: '• المضمون: تعدد الأغراض (المديح، الفخر، الرثاء، الغزل)، والافتتاح بالمقدمة الطللية أو الغزلية، مع حضور النفحة الوطنية.\n• المعجم: لغة تراثية فصيحة، جزلة، ومتينة تنهل من معجم الشعر العباسي والجاهلي.\n• الإيقاع: الالتزام الصارم بالبحور الخليلية التامة، وحدة القافية والروي، وظاهرة التصريع في المطلع.\n• الصورة الشعرية: صور بيانية حسية تقليدية (تشبيه، استعارة، كناية) تؤدي وظيفة تزيينية وجمالية.',
          keyFormulaOrRule: 'النموذج الخليلي: شطران متناظران (صدر وعجز) + وحدة الوزن والقافية والروي + التصريع.'
        },
        {
          heading: '3. أبرز رواد الحركة بالمغرب والمشرق',
          content: 'بالمشرق: محمود سامي البارودي (رائد الحركة)، أحمد شوقي (أمير الشعراء)، وحافظ إبراهيم. وبالمغرب: علال الفاسي، محمد بن إبراهيم (شاعر الحمراء)، ومحمد الحلوي.',
          keyFormulaOrRule: 'الرواد: البارودي، شوقي، حافظ إبراهيم، علال الفاسي.'
        }
      ],
      conclusion: 'نجحت حركة إحياء النموذج في إعادة الهيبة والمتانة للغة والشعر العربي، ممهدة الطريق لحركات التجديد اللاحقة كسؤال الذات وتكسير البنية.'
    },
    practicalExamples: [
      {
        id: 'arabic-ex-1',
        title: 'تحليل نص شعري إحيائي في الامتحان الوطني الموحد',
        examOrigin: 'الامتحان الوطني الموحد - مسلك الآداب والعلوم الإنسانية',
        problem: 'قال الشاعر محمود سامي البارودي:\nأَبَى الدَّهْرُ إِلَّا أَنْ يَسُودَ وَضِيعُهُ ... وَيَمْلِكَ أَعْنَاقَ الْمَطَالِبِ كَاتِعُهُ\nفَحَتَّامَ أَسْرِي فِي دَيَاجِيرِ مِحْنَةٍ ... يُضِيقُ بِهَا عَنْ رَحْبِهِ الْمَرْءُ ذَرْعُهُ\nالمطلوب: حدد معالم إحياء النموذج من خلال المعجم والإيقاع الخارجي للبيتين.',
        solution: '1) المعجم: وظف الشاعر معجماً تراثياً جزلاً تبرز فيه مفردات تراثية فصيحة ("كاتعه"، "دياجير"، "يسود وسيعه") الدالة على الألم والمحن في سياق غربة الشاعر.\n2) الإيقاع الخارجي: نظم الشاعر القصيدة على بحر الطويل (فعولن مفاعيلن فعولن مفاعلن) التام، والتزم بوحدة القافية والروي المضموم (العين المضمومة المشبعة بالواو)، مما يعكس بوضوح استلهام هيكل القصيدة العربية القديمة.',
        tip: 'في تحليل النص الشعري، لا تنس تفكيك المستويات الثلاثة: الدلالي (الأفكار والمعجم)، الإيقاعي (الداخلي والخارجي)، والبلاغي (الصور ووظيفتها التزيينية).'
      }
    ],
    summaryKeyPoints: [
      'إحياء النموذج حركة بعث وإحياء للقصيدة العربية القديمة شكلًا ومضمونًا.',
      'التزام تام بنظام الشطرين ووحدة الوزن والقافية والروي والبناء الطللي.',
      'المعجم يتسم بالجزالة والفصاحة واستدعاء القاموس التراثي القديم.',
      'الصورة الشعرية حسية بيانية تهدف إلى الزخرفة والتزيين والمحاكاة.'
    ],
    difficultTerms: [
      { term: 'التصريع', definition: 'اتفاق نهاية الشطر الأول (الصدر) مع نهاية الشطر الثاني (العجز) في الوزن والروي والقافية في البيت الأول من القصيدة.' },
      { term: 'الجزالة اللغوية', definition: 'قوة الألفاظ وفصاحتها ومتانة تراكيبها المستقاة من اللغة التراثية العربية القديمة.' }
    ],
    quiz: [
      {
        id: 'q-ar-1',
        question: 'من يعتبر رائد حركة إحياء النموذج في الشعر العربي الحديث؟',
        options: ['أحمد عبد المعطي حجازي', 'محمود سامي البارودي', 'أدونيس', 'نازك الملائكة'],
        correctIndex: 1,
        explanation: 'محمود سامي البارودي الملقب برب السيف والقلم هو رائد مدرسة البعث والإحياء بلا منازع.'
      }
    ]
  },

  // =========================================================================
  // 6. اللغة الفرنسية (Français)
  // =========================================================================
  {
    id: 'french-boite-merveilles',
    title: 'Étude d\'œuvre: La Boîte à Merveilles (Ahmed Sefrioui)',
    titleFr: 'La Boîte à Merveilles d\'Ahmed Sefrioui (Roman autobiographique)',
    subjectId: 'french',
    level: 'high',
    moroccanTrack: 'الأولى باكالوريا - الامتحان الجهوي الموحد (Toutes filières)',
    unit: 'Module 1: Le Roman Autobiographique marocain',
    estimatedMinutes: 25,
    difficulty: 'medium',
    description: 'Analyse du roman autobiographique d\'Ahmed Sefrioui: thèmes majeurs, personnages (Sidi Mohammed, Lalla Zoubida, Maâlem Abdeslam), la boîte et le regard de l\'enfant.',
    simplifiedExplanation: {
      introduction: 'Publié en 1954, "La Boîte à Merveilles" d\'Ahmed Sefrioui est considéré comme le premier roman marocain d\'expression française. C\'est l\'œuvre incontournable de l\'examen régional du 1BAC au Maroc.',
      sections: [
        {
          heading: '1. Fiche de lecture et caractéristiques',
          content: '• Auteur: Ahmed Sefrioui (1915-2004, Fès).\n• Genre: Roman autobiographique (l\'auteur adulte raconte les souvenirs de ses six ans).\n• Cadre spatio-temporel: La médina de Fès (Dar Chouafa, le Msid, les ruelles, Sidi Ali Boughaleb) dans les années 1920.\n• Narrateur-personnage: Sidi Mohammed (enfant rêveur, solitaire et observateur).',
          keyFormulaOrRule: 'Pacte autobiographique: Narrateur = Personnage principal (Sidi Mohammed), mais distinct de l\'Auteur dans le temps.'
        },
        {
          heading: '2. La boîte à merveilles: Symbole et fonction',
          content: 'La boîte contient des objets hétéroclites sans valeur marchande (clous, billes, boutons, perles en verre, chaînette de cuivre). Pour l\'enfant, c\'est un refuge magique qui le console de sa solitude et le transporte dans un univers féerique loin de la réalité bruyante des adultes.',
          keyFormulaOrRule: 'La boîte = Antidote contre la solitude (refuge de l\'imaginaire face à l\'ennui).'
        },
        {
          heading: '3. Les thèmes centraux et les figures de style',
          content: '• Thèmes: La solitude, la solidarité et les disputes de voisinage, les rituels et la superstition (visites des marabouts, la Chouafa Kenza).\n• Les figures de style récurrentes: Métaphore ("un grand oiseau noir"), hyperbole ("des torrents de larmes"), comparaison, personnification des objets.',
          keyFormulaOrRule: 'Événement perturbateur: La ruine du père Maâlem Abdeslam qui perd son capital dans le souk des bijoutiers.'
        }
      ],
      conclusion: 'Le roman se termine par le retour du père, la joie de la famille et la réouverture de la boîte à merveilles, soulignant l\'éternelle solitude de l\'enfant poète.'
    },
    practicalExamples: [
      {
        id: 'fr-ex-1',
        title: 'Question d\'examen régional sur la situation du passage',
        examOrigin: 'Examen Régional Unifié - Académie Casablanca-Settat / Rabat-Salé-Kénitra',
        problem: 'Consigne: "Situez le passage où le père Maâlem Abdeslam annonce qu\'il doit partir travailler aux environs de Fès pour rembourser ses dettes."\nRappelez les événements qui ont précédé cette décision.',
        solution: 'Éléments de réponse type pour l\'examen régional:\n1) Contexte général: Cet extrait se situe dans le chapitre IX de La Boîte à Merveilles d\'Ahmed Sefrioui.\n2) Événements antérieurs: Lors de la visite au souk des bijoutiers avec sa femme et son fils, Maâlem Abdeslam s\'est querellé violemment avec le courtier (dellal). Plus tard, il a perdu tout son argent (son capital) dans la cohue du souk.\n3) Conséquence: Ne pouvant plus acheter de fil pour son métier de tisserand, le père décide de partir aux moissons dans les environs de Fès pour une durée d\'un mois afin de ramasser de l\'argent pour réinstaller son atelier.',
        tip: 'Pour situer un passage, mentionnez toujours l\'auteur, le titre, le chapitre ou l\'événement juste avant et ce qui va en découler.'
      }
    ],
    summaryKeyPoints: [
      'Narrateur: Sidi Mohammed (6 ans), double focalisation (regard d\'enfant / recul de l\'adulte).',
      'Lieu principal: Dar Chouafa (maison de la voyante Kenza partagée par plusieurs familles).',
      'Événements clés: Visite de Sidi Ali Boughaleb, dispute de Lalla Zoubida avec Rahma, disparition de Zineb, ruine du père.',
      'Dénouement heureux: Le retour triomphal du père et la délivrance de la famille.'
    ],
    difficultTerms: [
      { term: 'Roman autobiographique', definition: 'Récit de fiction inspiré de la vie réelle de l\'auteur où le narrateur et le personnage principal partagent la même identité.' },
      { term: 'Msid', definition: 'École coranique traditionnelle où les enfants apprennent le Coran sous la direction du fqih.' }
    ],
    quiz: [
      {
        id: 'q-fr-1',
        question: 'Quel métier exerce le père de Sidi Mohammed (Maâlem Abdeslam) ?',
        options: ['Menuisier', 'Tisserand', 'Forgeron', 'Bijoutier'],
        correctIndex: 1,
        explanation: 'Maâlem Abdeslam est un maître tisserand respecté fabriquant des haïks et des djellabas.'
      }
    ]
  },

  // =========================================================================
  // 7. اللغة الإنجليزية (English)
  // =========================================================================
  {
    id: 'english-passive-voice',
    title: 'Grammar & Writing: The Passive Voice (All Tenses)',
    titleFr: 'The Passive Voice in the Moroccan National Curriculum',
    subjectId: 'english',
    level: 'high',
    moroccanTrack: 'الثانية باكالوريا - جميع الشعب والمسالك المغربية',
    unit: 'Grammar Unit: Formal Communication & Scientific Reports',
    estimatedMinutes: 20,
    difficulty: 'medium',
    description: 'Master the passive voice transformations for Simple Present, Past, Present Perfect, Modals, and continuous tenses with Moroccan national exam exercises.',
    simplifiedExplanation: {
      introduction: 'The passive voice is a compulsory grammar question tested every year in the Moroccan National Baccalaureate Examination. It shifts the focus from the doer of the action (agent) to the receiver or the action itself.',
      sections: [
        {
          heading: '1. Golden Rule of Passive Transformation',
          content: 'To transform an active sentence into passive:\n1. The Object of the active sentence becomes the Subject of the passive sentence.\n2. Use the auxiliary verb "to be" in the same tense as the active main verb.\n3. Turn the main verb into the Past Participle (V3).\n4. Optionally add "by + agent".',
          keyFormulaOrRule: 'Object + BE (in active tense) + Past Participle (V3) (+ by Subject)'
        },
        {
          heading: '2. Tense-by-Tense Conversion Table',
          content: '• Simple Present: am / is / are + V3 (e.g., "The teacher explains the lesson" -> "The lesson is explained").\n• Simple Past: was / were + V3 (e.g., "Morocco organized the summit" -> "The summit was organized").\n• Present Perfect: has / have + been + V3.\n• Future (will): will be + V3.\n• Modal verbs (can, must, should): modal + be + V3.',
          keyFormulaOrRule: 'Modals: Subject + Modal + BE + Past Participle (e.g. "must be solved")'
        },
        {
          heading: '3. When and why to use the Passive Voice in Writing',
          content: 'Used extensively in formal essays, scientific reports, and news headlines when the doer is unknown, obvious, or less important than the result.',
          keyFormulaOrRule: 'Active: "They built the university in 1975" -> Passive: "The university was built in 1975"'
        }
      ],
      conclusion: 'Remember that only transitive verbs (verbs that take a direct object) can be transformed into the passive voice.'
    },
    practicalExamples: [
      {
        id: 'eng-ex-1',
        title: 'Moroccan National Baccalaureate Exam Practice',
        examOrigin: 'Moroccan National Exam - Science, Tech & Humanities Tracks',
        problem: 'Rewrite the sentences starting with the words given:\n1. "The government has built three new hospitals in rural areas."\n-> Three new hospitals ...\n2. "Students must submit the final project before Friday."\n-> The final project ...',
        solution: '1. "Three new hospitals have been built by the government in rural areas."\n(Tense is Present Perfect -> has/have + been + Past Participle. "hospitals" is plural, so we use "have been").\n\n2. "The final project must be submitted before Friday."\n(Modal "must" + "be" + Past Participle "submitted").',
        tip: 'Always check if the new subject is singular or plural! A common mistake is writing "Three new hospitals has been built" instead of "have been built".'
      }
    ],
    summaryKeyPoints: [
      'The object becomes the subject: S + V + O  -->  O + BE + V3.',
      'The verb "TO BE" must match the original tense and agree in number with the new subject.',
      'Present continuous becomes: is/are being + V3.',
      'Modals become: modal + be + V3.'
    ],
    difficultTerms: [
      { term: 'Transitive verb', definition: 'A verb that requires one or more direct objects to complete its meaning.' },
      { term: 'Past Participle (V3)', definition: 'The third form of the verb (e.g., done, written, seen, discovered).' }
    ],
    quiz: [
      {
        id: 'q-eng-1',
        question: 'What is the correct passive form of: "The mechanic repaired my car yesterday"?',
        options: [
          'My car is repaired by the mechanic yesterday.',
          'My car was repaired yesterday.',
          'My car has been repaired yesterday.',
          'My car had repaired yesterday.'
        ],
        correctIndex: 1,
        explanation: '"repaired" is in the Simple Past, so we use "was repaired" for singular "my car".'
      }
    ]
  }
];
