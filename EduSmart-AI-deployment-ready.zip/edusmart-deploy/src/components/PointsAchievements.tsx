import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Award, Star, Zap, Shield, Sparkles, CheckCircle2, Lock } from 'lucide-react';
import { Language, EducationLevel, ActiveTab, UserProfile, UserProgressData, AchievementItem } from '../types';
import { translations } from '../i18n/translations';

interface PointsAchievementsProps {
  lang: Language;
  level: EducationLevel;
  currentUser: UserProfile | null;
  progress: UserProgressData;
  onNavigate: (tab: ActiveTab) => void;
}

export const PointsAchievements: React.FC<PointsAchievementsProps> = ({
  lang,
  level,
  currentUser,
  progress,
  onNavigate,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';

  // Calculate dynamic XP
  const solvedXp = progress.solvedCount * 25;
  const quizXp = progress.quizzesTaken * 50;
  const baseAccountXp = 100;
  const totalXp = solvedXp + quizXp + baseAccountXp;

  // Rank calculation
  let rankName = isRtl ? 'باحث أكاديمي مبتدئ' : 'Academic Inquirer';
  let rankTier = 1;
  let nextRankXp = 250;
  let rankBadge = '🥉';

  if (totalXp >= 1000) {
    rankName = isRtl ? 'عالم متعدد التخصصات (Master Polymath)' : 'Grand Master Polymath';
    rankTier = 5;
    nextRankXp = 1500;
    rankBadge = '👑';
  } else if (totalXp >= 600) {
    rankName = isRtl ? 'باحث متميز ومبدع (Advanced Scholar)' : 'Advanced Laureate';
    rankTier = 4;
    nextRankXp = 1000;
    rankBadge = '💎';
  } else if (totalXp >= 350) {
    rankName = isRtl ? 'طالب متفوق (Honor Scholar)' : 'Honor Scholar';
    rankTier = 3;
    nextRankXp = 600;
    rankBadge = '🥇';
  } else if (totalXp >= 150) {
    rankName = isRtl ? 'دارس مثابر (Active Inquirer)' : 'Active Inquirer';
    rankTier = 2;
    nextRankXp = 350;
    rankBadge = '🥈';
  }

  const progressPercent = Math.min(100, Math.round((totalXp / nextRankXp) * 100));

  // Academic Achievement Badges (Zero challenges)
  const badges: AchievementItem[] = [
    {
      id: 'math_pioneer',
      title: isRtl ? 'رائد الرياضيات' : 'Math Pioneer',
      description: isRtl ? 'حل 3 مسائل رياضية مع استيعاب خطوات الحل' : 'Solve 3 math problems with full steps',
      icon: '📐',
      xpReward: 50,
      category: 'academic',
      unlocked: progress.solvedCount >= 3,
      progressPercent: Math.min(100, Math.round((progress.solvedCount / 3) * 100)),
    },
    {
      id: 'quiz_master',
      title: isRtl ? 'بطل الاختبارات' : 'Quiz Champion',
      description: isRtl ? 'اجتياز اختبارين بنسبة نجاح تفوق 80%' : 'Complete 2 quizzes with over 80% score',
      icon: '🎯',
      xpReward: 75,
      category: 'quiz',
      unlocked: progress.quizzesTaken >= 2,
      progressPercent: Math.min(100, Math.round((progress.quizzesTaken / 2) * 100)),
    },
    {
      id: 'speed_summarizer',
      title: isRtl ? 'ملخص الدروس الذكي' : 'Synthesis Master',
      description: isRtl ? 'توليد بطاقات تلخيص مركزة للمقررات' : 'Generate concise lesson revision sheets',
      icon: '📑',
      xpReward: 40,
      category: 'academic',
      unlocked: progress.history.some((h) => h.type === 'summary'),
      progressPercent: progress.history.some((h) => h.type === 'summary') ? 100 : 30,
    },
    {
      id: 'polyglot_scribe',
      title: isRtl ? 'فصاحة اللغات' : 'Polyglot Stylist',
      description: isRtl ? 'تدقيق وصياغة نصوص أكاديمية وترجمتها' : 'Proofread & translate academic texts',
      icon: '✍️',
      xpReward: 45,
      category: 'exploration',
      unlocked: true,
      progressPercent: 100,
    },
    {
      id: 'curious_mind',
      title: isRtl ? 'العقل الفضولي' : 'Curious Inquirer',
      description: isRtl ? 'طرح استفسارات تفاعلية على المساعد الدراسي' : 'Engage with the AI Study Assistant',
      icon: '💬',
      xpReward: 35,
      category: 'consistency',
      unlocked: true,
      progressPercent: 100,
    },
    {
      id: 'grand_scholar',
      title: isRtl ? 'وسام التفوق الشامل' : 'Grand Scholar Honor',
      description: isRtl ? 'تجاوز 300 نقطة خبرة دراسية' : 'Accumulate over 300 total study XP',
      icon: '🏆',
      xpReward: 100,
      category: 'academic',
      unlocked: totalXp >= 300,
      progressPercent: Math.min(100, Math.round((totalXp / 300) * 100)),
    },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Hero Showcase Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#160c2b] to-[#0a0714] border border-purple-800/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 end-0 w-80 h-80 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 start-0 w-60 h-60 bg-violet-600/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          {/* Left / Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/40 border border-purple-500/30 text-purple-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>{t.achievements.title}</span>
            </div>

            <div>
              <div className="flex items-center gap-3">
                <span className="text-3xl">{rankBadge}</span>
                <div>
                  <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                    {rankName}
                  </h2>
                  <p className="text-xs text-purple-300/80 font-medium">
                    {translations[lang].levels[level]} • Level {rankTier} Scholar
                  </p>
                </div>
              </div>
            </div>

            {/* XP Progression Bar */}
            <div className="space-y-2 max-w-md pt-2">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-purple-200">
                  {t.achievements.xpProgress}: <strong className="text-white">{totalXp} XP</strong>
                </span>
                <span className="text-purple-400">{nextRankXp} XP</span>
              </div>
              <div className="h-3 w-full bg-purple-950/80 rounded-full overflow-hidden p-0.5 border border-purple-800/40">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ duration: 0.8 }}
                  className="h-full rounded-full bg-gradient-to-r from-purple-600 via-violet-400 to-fuchsia-400 shadow-md"
                />
              </div>
              <span className="text-[11px] text-purple-300/60 block">
                {isRtl ? `تبقى ${Math.max(0, nextRankXp - totalXp)} نقطة XP للوصول إلى الرتبة التالية` : `${Math.max(0, nextRankXp - totalXp)} XP needed for next milestone`}
              </span>
            </div>
          </div>

          {/* Right Trophy Artwork */}
          <div className="flex justify-center md:justify-end">
            <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-3xl overflow-hidden border border-purple-500/30 shadow-2xl purple-glow">
              <img
                src="/src/assets/images/achievement_trophy_purple_1794356528026.jpg"
                alt="Amethyst Achievement Trophy"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end justify-center p-3">
                <span className="text-xs font-black text-purple-200 tracking-wider uppercase">
                  {totalXp} XP Earned
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Badges & Medals Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-purple-400" />
            <h3 className="text-lg sm:text-xl font-bold text-white">
              {t.achievements.badgesTitle}
            </h3>
          </div>
          <span className="text-xs font-semibold px-3 py-1 rounded-xl bg-purple-950/70 text-purple-300 border border-purple-800/40">
            {badges.filter((b) => b.unlocked).length} / {badges.length} {isRtl ? 'أوسمة مكتملة' : 'Unlocked'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {badges.map((badge, idx) => (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.05 }}
              className={`p-5 rounded-3xl border transition-all ${
                badge.unlocked
                  ? 'bg-[#140c26] border-purple-700/40 hover:border-purple-500/60 shadow-xl'
                  : 'bg-[#0f091c]/80 border-purple-950/40 opacity-75'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="w-12 h-12 rounded-2xl bg-purple-950/90 border border-purple-600/30 flex items-center justify-center text-2xl shadow-inner">
                  {badge.icon}
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-purple-900/50 text-purple-300 border border-purple-700/30">
                    +{badge.xpReward} XP
                  </span>
                  {badge.unlocked ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Lock className="w-3.5 h-3.5 text-purple-400/50" />
                  )}
                </div>
              </div>

              <h4 className="text-sm sm:text-base font-bold text-white mb-1">
                {badge.title}
              </h4>
              <p className="text-xs text-purple-200/70 leading-relaxed mb-3">
                {badge.description}
              </p>

              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-semibold text-purple-300/80">
                  <span>{badge.unlocked ? t.achievements.unlocked : t.achievements.locked}</span>
                  <span>{badge.progressPercent}%</span>
                </div>
                <div className="h-1.5 w-full bg-purple-950 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      badge.unlocked
                        ? 'bg-gradient-to-r from-purple-500 to-emerald-400'
                        : 'bg-purple-800'
                    }`}
                    style={{ width: `${badge.progressPercent}%` }}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* How to Earn Points Guide */}
      <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-white font-bold text-base">
          <Zap className="w-5 h-5 text-amber-400" />
          <span>{t.achievements.howToEarn}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 rounded-2xl bg-black/40 border border-purple-900/30 space-y-1">
            <span className="font-black text-purple-400 text-sm block">+25 XP</span>
            <p className="text-purple-200/80">{t.achievements.ruleSolve}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-black/40 border border-purple-900/30 space-y-1">
            <span className="font-black text-violet-400 text-sm block">+50 XP</span>
            <p className="text-purple-200/80">{t.achievements.ruleQuiz}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-black/40 border border-purple-900/30 space-y-1">
            <span className="font-black text-fuchsia-400 text-sm block">+20 XP</span>
            <p className="text-purple-200/80">{t.achievements.ruleSummary}</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-black/40 border border-purple-900/30 space-y-1">
            <span className="font-black text-pink-400 text-sm block">+15 XP</span>
            <p className="text-purple-200/80">{t.achievements.ruleExplain}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
