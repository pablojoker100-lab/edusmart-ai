import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language, EducationLevel, UserProfile } from '../types';
import { translations } from '../i18n/translations';
import { authService } from '../services/authService';

interface AuthPageProps {
  lang: Language;
  currentLevel: EducationLevel;
  currentUser: UserProfile | null;
  onLoginSuccess: (user: UserProfile) => void;
  onLogout: () => void;
  onNavigateHome: () => void;
}

type AuthMode = 'login' | 'register' | 'forgot' | 'reset';

export const AuthPage: React.FC<AuthPageProps> = ({
  lang,
  currentLevel,
  currentUser,
  onLoginSuccess,
  onLogout,
  onNavigateHome,
}) => {
  const t = translations[lang].auth;
  const tLevels = translations[lang].levels;
  const isRtl = lang === 'ar';

  const [mode, setMode] = useState<AuthMode>('login');

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [name, setName] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<EducationLevel>(currentLevel);
  const [resetCode, setResetCode] = useState('');

  // UI state
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [demoResetCodeNotice, setDemoResetCodeNotice] = useState<string | null>(null);

  // Clear messages when switching modes
  const switchMode = (newMode: AuthMode) => {
    setMode(newMode);
    setErrorMessage(null);
    setSuccessMessage(null);
    setDemoResetCodeNotice(null);
  };

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) return;

    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    const res = await authService.login(email.trim(), password);
    setIsLoading(false);

    if (res.success && res.user) {
      setSuccessMessage(t.successLogin);
      setTimeout(() => {
        onLoginSuccess(res.user!);
      }, 1000);
    } else {
      setErrorMessage(res.message || 'فشل تسجيل الدخول. تحقق من بياناتك.');
    }
  };

  // Handle Registration
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) return;

    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    const res = await authService.register(email.trim(), password, name.trim(), selectedLevel);
    setIsLoading(false);

    if (res.success && res.user) {
      setSuccessMessage(t.successRegister);
      setTimeout(() => {
        onLoginSuccess(res.user!);
      }, 1000);
    } else {
      setErrorMessage(res.message || 'فشل إنشاء الحساب.');
    }
  };

  // Handle Forgot Password
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsLoading(true);
    setErrorMessage(null);

    const res = await authService.forgotPassword(email.trim());
    setIsLoading(false);

    if (res.success) {
      if (res.resetCode) {
        setDemoResetCodeNotice(res.resetCode);
        setResetCode(res.resetCode);
      }
      setSuccessMessage(res.message || 'تم إرسال رمز الاستعادة بنجاح.');
      // Transition to reset password view
      setTimeout(() => {
        setMode('reset');
      }, 1500);
    } else {
      setErrorMessage(res.message || 'حدث خطأ أثناء معالجة الطلب.');
    }
  };

  // Handle Reset Password
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !resetCode.trim() || !newPassword) return;

    setIsLoading(true);
    setErrorMessage(null);

    const res = await authService.resetPassword(email.trim(), resetCode.trim(), newPassword);
    setIsLoading(false);

    if (res.success) {
      setSuccessMessage(res.message || t.successReset);
      setPassword(newPassword);
      setTimeout(() => {
        setMode('login');
        setSuccessMessage(null);
      }, 2000);
    } else {
      setErrorMessage(res.message || 'فشل إعادة تعيين كلمة المرور.');
    }
  };

  // Handle Google Sign-In (Firebase Auth / Google Account)
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    const googleEmail = email.trim() && email.includes('@') ? email.trim() : 'student@gmail.com';
    const googleName = name.trim() || (isRtl ? 'طالب متميز (Google)' : 'Distinguished Student');
    const res = await authService.loginWithGoogle(googleEmail, googleName, undefined, selectedLevel);
    setIsLoading(false);

    if (res.success && res.user) {
      setSuccessMessage(isRtl ? 'تم تسجيل الدخول بحساب Google بنجاح! جاري التوجيه...' : 'Signed in with Google! Redirecting...');
      setTimeout(() => {
        onLoginSuccess(res.user!);
      }, 1000);
    } else {
      setErrorMessage(res.message || 'فشل تسجيل الدخول بواسطة Google');
    }
  };

  // If already logged in, show User Profile Card
  if (currentUser) {
    return (
      <div className="max-w-2xl mx-auto py-6 sm:py-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-3xl p-6 sm:p-10 shadow-lg border border-slate-200/90 text-center space-y-6"
        >
          {/* Avatar */}
          <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-cyan-500 text-white flex items-center justify-center text-4xl font-extrabold shadow-lg shadow-indigo-200">
            {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : '🎓'}
          </div>

          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full text-xs font-semibold mb-3">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{t.sessionActive}</span>
            </div>

            <h2 className="text-2xl font-bold text-slate-900">{currentUser.name}</h2>
            <p className="text-sm text-slate-500 font-medium mt-1">{currentUser.email}</p>
          </div>

          {/* User details badge */}
          <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto text-xs">
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-slate-700">
              <span className="text-[11px] text-slate-400 block mb-0.5">{t.levelLabel}</span>
              <span className="font-bold text-indigo-700">
                {tLevels[currentUser.level as EducationLevel] || currentUser.level}
              </span>
            </div>
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-slate-700">
              <span className="text-[11px] text-slate-400 block mb-0.5">{isRtl ? 'حالة التشفير' : 'Encryption'}</span>
              <span className="font-bold text-emerald-700">Scrypt 256-bit</span>
            </div>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center max-w-sm mx-auto">
            <button
              onClick={onNavigateHome}
              className="flex-1 px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold transition-all shadow-md shadow-indigo-100 cursor-pointer"
            >
              {isRtl ? 'الذهاب إلى الرئيسية 🏠' : 'Go to Dashboard 🏠'}
            </button>
            <button
              onClick={onLogout}
              className="px-6 py-3 rounded-2xl bg-red-50 hover:bg-red-100 text-red-700 text-sm font-semibold transition-colors border border-red-200 cursor-pointer"
            >
              {t.logoutBtn}
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto py-4 sm:py-8">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-slate-200/90 relative overflow-hidden"
      >
        {/* Decorative Top Gradient Line */}
        <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-500" />

        {/* Brand Header */}
        <div className="text-center mb-7">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-cyan-500 text-white flex items-center justify-center text-2xl font-bold shadow-md shadow-indigo-100 mb-3">
            🎓
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {mode === 'login' && t.loginTitle}
            {mode === 'register' && t.registerTitle}
            {mode === 'forgot' && t.forgotTitle}
            {mode === 'reset' && t.resetTitle}
          </h2>

          <p className="text-xs sm:text-sm text-slate-500 mt-1.5">
            {mode === 'login' && t.loginSubtitle}
            {mode === 'register' && t.registerSubtitle}
            {mode === 'forgot' && t.forgotSubtitle}
            {mode === 'reset' && t.resetSubtitle}
          </p>
        </div>

        {/* Mode Selector Tabs (Login / Register) */}
        {(mode === 'login' || mode === 'register') && (
          <div className="flex bg-slate-100/90 p-1 rounded-2xl mb-6 border border-slate-200">
            <button
              type="button"
              onClick={() => switchMode('login')}
              className={`flex-1 py-2.5 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'login'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.loginBtn}
            </button>
            <button
              type="button"
              onClick={() => switchMode('register')}
              className={`flex-1 py-2.5 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'register'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.registerBtn}
            </button>
          </div>
        )}

        {/* Notifications */}
        <AnimatePresence>
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="p-4 mb-5 bg-red-50 text-red-700 rounded-2xl text-xs sm:text-sm border border-red-200 flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <span>⚠️</span>
                <span>{errorMessage}</span>
              </div>
              <button
                type="button"
                onClick={() => setErrorMessage(null)}
                className="text-xs font-bold text-red-800"
              >
                ✕
              </button>
            </motion.div>
          )}

          {successMessage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="p-4 mb-5 bg-emerald-50 text-emerald-800 rounded-2xl text-xs sm:text-sm border border-emerald-200 flex items-center gap-2"
            >
              <span>✅</span>
              <span>{successMessage}</span>
            </motion.div>
          )}

          {demoResetCodeNotice && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 mb-5 bg-blue-50 text-blue-900 rounded-2xl text-xs border border-blue-200 flex items-center justify-between"
            >
              <div>
                <strong className="block font-bold">
                  {isRtl ? 'رمز استعادة كلمة المرور المولد:' : 'Recovery Code:'}
                </strong>
                <span className="font-mono text-base font-extrabold text-indigo-700 tracking-wider">
                  {demoResetCodeNotice}
                </span>
              </div>
              <span className="text-[11px] text-blue-600">
                {isRtl ? 'صالح لمدة 15 دقيقة' : 'Valid 15m'}
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Google Sign-In Button (Firebase Auth / Google SSO) */}
        {(mode === 'login' || mode === 'register') && (
          <div className="mb-6">
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full py-3 px-4 bg-white hover:bg-slate-50 border border-slate-300 rounded-2xl text-slate-700 text-xs sm:text-sm font-bold flex items-center justify-center gap-3 transition-all shadow-xs hover:shadow-md cursor-pointer"
            >
              <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
              <span>
                {isRtl ? 'المتابعة باستخدام حساب Google (Firebase Auth)' : 'Continue with Google Account'}
              </span>
            </button>

            {/* Divider */}
            <div className="flex items-center gap-3 my-4">
              <div className="flex-1 h-px bg-slate-200" />
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                {isRtl ? 'أو بالبريد الإلكتروني' : 'Or with Email'}
              </span>
              <div className="flex-1 h-px bg-slate-200" />
            </div>
          </div>
        )}

        {/* FORM 1: LOGIN */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {t.emailLabel}
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={t.emailPlaceholder}
                  className="w-full rounded-2xl border border-slate-300 p-3.5 pe-10 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                />
                <span className="absolute inset-y-0 end-3.5 flex items-center pointer-events-none text-slate-400">
                  ✉️
                </span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-700">{t.passwordLabel}</label>
                <button
                  type="button"
                  onClick={() => switchMode('forgot')}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors"
                >
                  {t.forgotLink}
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.passwordPlaceholder}
                  className="w-full rounded-2xl border border-slate-300 p-3.5 pe-12 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 end-3 flex items-center text-xs text-slate-500 hover:text-slate-800 px-1.5 transition-colors cursor-pointer"
                  title={showPassword ? t.hidePassword : t.showPassword}
                >
                  {showPassword ? '👁️‍🗨️' : '👁️'}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || !email.trim() || !password}
              className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs sm:text-sm font-bold transition-all shadow-md shadow-indigo-100 flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  <span>{isRtl ? 'جاري التحقق...' : 'Authenticating...'}</span>
                </>
              ) : (
                <span>{t.loginBtn}</span>
              )}
            </button>
          </form>
        )}

        {/* FORM 2: REGISTER */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">{t.nameLabel}</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.namePlaceholder}
                className="w-full rounded-2xl border border-slate-300 p-3.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {t.emailLabel}
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                className="w-full rounded-2xl border border-slate-300 p-3.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">{t.levelLabel}</label>
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value as EducationLevel)}
                className="w-full rounded-2xl border border-slate-300 p-3.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium bg-white cursor-pointer"
              >
                <option value="primary">🎒 {tLevels.primary}</option>
                <option value="middle">📐 {tLevels.middle}</option>
                <option value="high">🎓 {tLevels.high}</option>
                <option value="university">🏛️ {tLevels.university}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">{t.passwordLabel}</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.passwordPlaceholder}
                  className="w-full rounded-2xl border border-slate-300 p-3.5 pe-12 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 end-3 flex items-center text-xs text-slate-500 hover:text-slate-800 px-1.5 transition-colors cursor-pointer"
                  title={showPassword ? t.hidePassword : t.showPassword}
                >
                  {showPassword ? '👁️‍🗨️' : '👁️'}
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {isRtl ? 'تشفير قوي بواسطة scrypt لحماية كلمة المرور' : 'Securely hashed with scrypt salt'}
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading || !email.trim() || !password}
              className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs sm:text-sm font-bold transition-all shadow-md shadow-indigo-100 flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  <span>{isRtl ? 'جاري إنشاء الحساب...' : 'Creating Account...'}</span>
                </>
              ) : (
                <span>{t.registerBtn}</span>
              )}
            </button>
          </form>
        )}

        {/* FORM 3: FORGOT PASSWORD */}
        {mode === 'forgot' && (
          <form onSubmit={handleForgotPassword} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {t.emailLabel}
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                className="w-full rounded-2xl border border-slate-300 p-3.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || !email.trim()}
              className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs sm:text-sm font-bold transition-all shadow-md shadow-indigo-100 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isLoading ? (
                <span>{isRtl ? 'جاري الإرسال...' : 'Sending...'}</span>
              ) : (
                <span>{t.forgotBtn}</span>
              )}
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => switchMode('login')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors"
              >
                ← {t.backToLogin}
              </button>
            </div>
          </form>
        )}

        {/* FORM 4: RESET PASSWORD */}
        {mode === 'reset' && (
          <form onSubmit={handleResetPassword} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {t.verificationCode}
              </label>
              <input
                type="text"
                required
                maxLength={6}
                value={resetCode}
                onChange={(e) => setResetCode(e.target.value)}
                placeholder={t.codePlaceholder}
                className="w-full rounded-2xl border border-slate-300 p-3.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono tracking-widest text-center"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {t.newPasswordLabel}
              </label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder={t.newPasswordPlaceholder}
                  className="w-full rounded-2xl border border-slate-300 p-3.5 pe-12 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute inset-y-0 end-3 flex items-center text-xs text-slate-500 hover:text-slate-800 px-1.5 transition-colors cursor-pointer"
                  title={showNewPassword ? t.hidePassword : t.showPassword}
                >
                  {showNewPassword ? '👁️‍🗨️' : '👁️'}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || !resetCode.trim() || !newPassword}
              className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs sm:text-sm font-bold transition-all shadow-md shadow-indigo-100 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isLoading ? (
                <span>{isRtl ? 'جاري الحفظ...' : 'Saving...'}</span>
              ) : (
                <span>{t.resetBtn}</span>
              )}
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => switchMode('login')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors"
              >
                ← {t.backToLogin}
              </button>
            </div>
          </form>
        )}

        {/* Bottom Switcher */}
        <div className="mt-8 pt-5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>
            {mode === 'login' ? t.noAccount : t.hasAccount}
          </span>
          <button
            type="button"
            onClick={() => switchMode(mode === 'login' ? 'register' : 'login')}
            className="font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer"
          >
            {mode === 'login' ? t.registerBtn : t.loginBtn}
          </button>
        </div>
      </motion.div>
    </div>
  );
};
