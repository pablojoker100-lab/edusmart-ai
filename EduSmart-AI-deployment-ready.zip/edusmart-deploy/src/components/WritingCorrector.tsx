import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Copy, Check, RotateCcw, AlertTriangle, CheckCircle2, Globe, FileText } from 'lucide-react';
import { Language, EducationLevel, CorrectionResponse } from '../types';
import { translations } from '../i18n/translations';
import { aiService } from '../services/aiService';

export const WritingCorrector: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang, level }) => {
  const t = translations[lang].writing;
  const common = translations[lang].common;
  const isAr = lang === 'ar';

  const [inputContent, setInputContent] = useState('');
  const [targetTranslation, setTargetTranslation] = useState<Language | 'none'>('none');
  const [isLoading, setIsLoading] = useState(false);
  const [report, setReport] = useState<CorrectionResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const sampleInputs = {
    ar: 'في هذا البحث سوف اتكلم عن التغير المناخي والاسباب التي تجعله يهدد الكرة الارضية ونقص الموارد المائية في المستقبل.',
    fr: 'Dans ce devoir je vais parler sur les causes de la pollution et comment ont peux reduire les emissions des gazs a effet de serre.',
    en: 'In this essay i will discuss about how global warming effects animals and why we should do more actions to prevent it.',
  };

  const handleCorrect = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputContent.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    try {
      const data = await aiService.correctAndTranslate(inputContent, targetTranslation, lang);
      setReport(data);
    } catch (err: any) {
      setError(err?.message || common.error);
    } finally {
      setIsLoading(false);
    }
  };

  const copyCorrected = () => {
    if (!report) return;
    navigator.clipboard.writeText(report.correctedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Input Box */}
      <div className="bg-[#120b24] rounded-3xl p-5 sm:p-7 shadow-xl border border-purple-900/40 relative">
        <div className="flex items-start justify-between flex-wrap gap-2 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">✍️</span>
              <h2 className="text-xl sm:text-2xl font-bold text-white">{t.title}</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                Turbo Flash ⚡
              </span>
            </div>
            <p className="text-xs sm:text-sm text-purple-300/70 mt-1">{t.subtitle}</p>
          </div>
          <span className="px-3 py-1 bg-purple-950 text-purple-300 border border-purple-800/40 text-xs font-semibold rounded-full">
            {translations[lang].levels[level]}
          </span>
        </div>

        <div className="mb-4">
          <button
            type="button"
            onClick={() => setInputContent(sampleInputs[lang])}
            className="text-xs font-medium text-purple-300 hover:text-white bg-purple-950/60 hover:bg-purple-900/60 px-3.5 py-1.5 rounded-xl border border-purple-800/30 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isAr ? 'تحميل نص تجريبي به أخطاء شائعة' : 'Load draft with typical errors'}</span>
          </button>
        </div>

        <form onSubmit={handleCorrect} className="space-y-4">
          <textarea
            value={inputContent}
            onChange={(e) => setInputContent(e.target.value)}
            placeholder={t.inputPlaceholder}
            disabled={isLoading}
            rows={4}
            className="w-full rounded-2xl bg-[#0d071a] border border-purple-900/50 p-4 text-xs sm:text-sm text-purple-100 placeholder:text-purple-400/40 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 leading-relaxed transition-all"
          />

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-purple-400" />
              <label className="text-xs font-semibold text-purple-200">{t.targetLang}:</label>
              <select
                value={targetTranslation}
                onChange={(e) => setTargetTranslation(e.target.value as Language | 'none')}
                disabled={isLoading}
                className="bg-[#180e33] border border-purple-800/40 text-purple-200 rounded-xl px-3 py-2 text-xs font-semibold focus:border-purple-500 outline-none cursor-pointer"
              >
                <option value="none">{t.none}</option>
                <option value="en">English (EN)</option>
                <option value="fr">Français (FR)</option>
                <option value="ar">العربية (AR)</option>
              </select>
            </div>

            <div className="flex gap-2 w-full sm:w-auto">
              <button
                type="submit"
                disabled={isLoading || !inputContent.trim()}
                className="flex-1 sm:flex-none px-7 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:from-purple-950 disabled:to-purple-950 disabled:text-purple-600/50 text-white font-semibold text-xs sm:text-sm transition-all shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                    </svg>
                    <span>{isAr ? 'جاري التدقيق اللغوي السريع...' : common.loading}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>{t.analyzeBtn}</span>
                  </>
                )}
              </button>

              {inputContent && !isLoading && (
                <button
                  type="button"
                  onClick={() => {
                    setInputContent('');
                    setReport(null);
                    setError(null);
                  }}
                  className="px-4 py-3 rounded-2xl bg-purple-950/40 hover:bg-purple-900/30 text-purple-300 text-xs font-semibold border border-purple-900/30 cursor-pointer"
                >
                  {common.clear}
                </button>
              )}
            </div>
          </div>
        </form>
      </div>

      {/* Error Card with Preserved Input and Retry */}
      {error && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 bg-red-950/40 text-red-200 rounded-3xl border border-red-500/40 flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-red-400 shrink-0" />
            <div>
              <p className="font-semibold text-sm">{error}</p>
              <p className="text-xs text-red-300/70 mt-0.5">
                {isAr ? 'تم الاحتفاظ بنص المسودة، يمكنك الضغط على إعادة المحاولة مباشرة.' : 'Draft text preserved. Click retry below.'}
              </p>
            </div>
          </div>
          <button
            onClick={() => handleCorrect()}
            className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl flex items-center gap-1.5 shrink-0 transition-colors shadow-lg shadow-red-600/30 cursor-pointer text-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
          </button>
        </motion.div>
      )}

      {/* Report Results */}
      {report && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#120b24] rounded-3xl p-5 sm:p-7 shadow-2xl border border-purple-900/40 space-y-6"
        >
          <div className="flex items-center justify-between flex-wrap gap-2 border-b border-purple-900/30 pb-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <h3 className="text-lg font-bold text-white">{t.correctedText}</h3>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold px-3.5 py-1 bg-emerald-950/60 text-emerald-300 border border-emerald-500/30 rounded-full">
                {t.fluency}: {report.fluencyScore}%
              </span>
              <button
                onClick={copyCorrected}
                className="px-3.5 py-1.5 rounded-xl border border-purple-800/40 bg-[#180e33] hover:bg-purple-900/40 text-xs font-semibold text-purple-200 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">{isAr ? 'تم النسخ' : 'Copied'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{isAr ? 'نسخ النص المصحح' : 'Copy'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Corrected Text Box */}
          <div className="p-5 bg-emerald-950/30 rounded-2xl border border-emerald-500/30 text-xs sm:text-sm text-purple-100 leading-relaxed font-medium select-all">
            {report.correctedText}
          </div>

          {/* Translation Box */}
          {report.translatedText && (
            <div className="p-5 bg-indigo-950/30 rounded-2xl border border-indigo-500/30 text-xs sm:text-sm text-purple-100 leading-relaxed">
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-300 uppercase tracking-wider mb-2">
                <Globe className="w-3.5 h-3.5 text-indigo-400" />
                <span>الترجمة الأكاديمية المعتمدة ({targetTranslation.toUpperCase()})</span>
              </div>
              <p className="font-medium text-purple-200/90 leading-relaxed select-all">{report.translatedText}</p>
            </div>
          )}

          {/* Detailed Linguistic Feedback */}
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-purple-300 uppercase tracking-wider mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>{t.improvements}</span>
            </h4>
            <div className="space-y-3">
              {report.improvements.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-[#180e33] rounded-2xl border border-purple-900/30 text-xs sm:text-sm space-y-1.5"
                >
                  <span className="font-bold text-red-400 block">⚠️ {item.issue}</span>
                  <p className="text-emerald-300 font-semibold">✓ {item.fix}</p>
                  <p className="text-purple-300/70 italic text-xs leading-relaxed">{item.reason}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};
