import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lightbulb, Sparkles, Copy, Check, ArrowRight, Target, TrendingUp, Compass, RotateCcw } from 'lucide-react';
import { Language, EducationLevel, IdeaItem } from '../types';
import { aiService } from '../services/aiService';

export const IdeaGenerator: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang }) => {
  const isAr = lang === 'ar';

  const categories = [
    { id: 'startup', label: isAr ? 'مشاريع وشركات ناشئة' : 'Startups & Ventures' },
    { id: 'academic', label: isAr ? 'أبحاث ودراسات أكاديمية' : 'Academic Research' },
    { id: 'content', label: isAr ? 'صناعة المحتوى والإعلام' : 'Media & Content' },
    { id: 'tech', label: isAr ? 'حلول تقنية وبرمجية' : 'Tech & AI Solutions' },
  ];

  const presets = [
    isAr ? 'مشروع تطبيق ذكي لمساعدة الطلاب في اجتياز امتحانات الباكالوريا' : 'Smart EdTech app for high school exam prep',
    isAr ? 'أفكار لمحتوى يوتيوب تقني وتعليمي يجذب آلاف المشاهدات' : 'Tech YouTube channel concepts that scale',
    isAr ? 'حلول تسويقية ذكية لمتجر إلكتروني محلي بميزانية منخفضة' : 'Low-budget growth marketing for local e-commerce',
    isAr ? 'مبادرة مجتمعية رقمية للتشجيع على القراءة والبحث العلمي' : 'Community reading initiative powered by micro-challenges',
  ];

  const [selectedCat, setSelectedCat] = useState('startup');
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [ideas, setIdeas] = useState<IdeaItem[] | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const res = await aiService.generateIdeas({
        topic: topic.trim(),
        category: selectedCat,
        lang,
      });
      setIdeas(res);
    } catch {
      setError(isAr ? 'تعذر توليد الأفكار حالياً. يرجى إعادة المحاولة.' : 'Failed to generate ideas. Please retry.');
    } finally {
      setIsLoading(false);
    }
  };

  const copyIdea = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header Form Card */}
      <div className="bg-[#120b24] rounded-3xl p-6 sm:p-8 border border-purple-900/40 shadow-xl relative overflow-hidden">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-lg shadow-amber-900/40">
            <Lightbulb className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isAr ? 'مولّد الأفكار والابتكار الذكي' : 'Idea & Innovation Generator'}
            </h2>
            <p className="text-xs sm:text-sm text-purple-300/70 mt-0.5">
              {isAr
                ? 'توليد أفكار مشاريع استثنائية، مواضيع أبحاث، ومبادرات إبداعية مع خطط تنفيذ واقعية'
                : 'Generate high-impact concepts, startup ideas, and research topics with clear execution roadmaps'}
            </p>
          </div>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 pt-4">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCat(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedCat === cat.id
                  ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-md'
                  : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 border border-purple-900/30'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Quick Presets */}
        <div className="pt-4">
          <span className="text-[11px] font-bold text-purple-400/80 block mb-2">
            {isAr ? 'أمثلة سريعة للاستلهام:' : 'Sample Inquiries:'}
          </span>
          <div className="flex flex-wrap gap-2">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setTopic(preset)}
                className="text-xs bg-[#190f33] hover:bg-purple-900/50 text-purple-200 px-3 py-1.5 rounded-xl border border-purple-800/30 text-start cursor-pointer transition-all"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Input */}
        <form onSubmit={handleGenerate} className="mt-5 space-y-4">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            disabled={isLoading}
            placeholder={
              isAr
                ? 'اكتب المجال أو التحدي الذي تبحث عن أفكار مبتكرة له (مثال: التجارة الإلكترونية، دراسة الرياضيات، قنوات يوتيوب)...'
                : 'Enter a topic, industry, or challenge to brainstorm high-value ideas for...'
            }
            className="w-full bg-[#0a0515] border border-purple-900/50 focus:border-amber-500 rounded-2xl px-4 py-3.5 text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none focus:ring-1 focus:ring-amber-500 transition-all font-medium"
          />

          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={!topic.trim() || isLoading}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-600 to-pink-500 hover:from-amber-400 hover:to-pink-400 disabled:opacity-40 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-amber-950/60 flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isLoading ? (isAr ? 'جاري عصر الأفكار والابتكار...' : 'Brainstorming Ideas...') : (isAr ? 'توليد الأفكار الآن' : 'Generate Ideas')}</span>
            </button>

            {topic && !isLoading && (
              <button
                type="button"
                onClick={() => {
                  setTopic('');
                  setIdeas(null);
                  setError(null);
                }}
                className="px-4 py-3 rounded-2xl bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 text-xs font-semibold cursor-pointer"
              >
                {isAr ? 'مسح' : 'Clear'}
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 bg-red-950/40 border border-red-500/40 rounded-2xl flex items-center justify-between text-xs text-red-200">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => handleGenerate()}
            className="px-3 py-1 bg-red-600 text-white rounded-xl font-bold flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
          </button>
        </div>
      )}

      {/* Ideas Grid */}
      {ideas && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ideas.map((idea, index) => {
            const formattedCopy = `${idea.title}\n\n${idea.description}\n\nخطوات التنفيذ:\n${idea.keySteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}`;

            return (
              <motion.div
                key={idea.id || index}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-[#120b24] rounded-3xl p-6 border border-purple-900/40 shadow-xl flex flex-col justify-between space-y-4 hover:border-amber-500/40 transition-all group"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="px-3 py-1 rounded-full bg-amber-950/60 border border-amber-500/30 text-amber-300 text-[10px] font-bold">
                      {idea.category}
                    </span>
                    <button
                      type="button"
                      onClick={() => copyIdea(idea.id, formattedCopy)}
                      className="text-xs text-purple-400 hover:text-white p-1.5 rounded-lg hover:bg-purple-900/40 transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      {copiedId === idea.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 text-[10px]">{isAr ? 'تم النسخ' : 'Copied'}</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span className="text-[10px]">{isAr ? 'نسخ الفكرة' : 'Copy'}</span>
                        </>
                      )}
                    </button>
                  </div>

                  <h3 className="text-base font-black text-white leading-snug group-hover:text-amber-200 transition-colors">
                    {idea.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-purple-200/80 mt-2 leading-relaxed">
                    {idea.description}
                  </p>

                  {/* Target Audience & Impact */}
                  <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-purple-900/30 text-[11px]">
                    {idea.targetAudience && (
                      <div className="space-y-0.5">
                        <span className="text-purple-400/70 font-semibold block flex items-center gap-1">
                          <Target className="w-3 h-3 text-cyan-400" />
                          {isAr ? 'الجمهور المستهدف:' : 'Target:'}
                        </span>
                        <span className="text-purple-200 font-medium">{idea.targetAudience}</span>
                      </div>
                    )}
                    {idea.potentialImpact && (
                      <div className="space-y-0.5">
                        <span className="text-purple-400/70 font-semibold block flex items-center gap-1">
                          <TrendingUp className="w-3 h-3 text-emerald-400" />
                          {isAr ? 'الأثر المتوقع:' : 'Impact:'}
                        </span>
                        <span className="text-emerald-300 font-medium">{idea.potentialImpact}</span>
                      </div>
                    )}
                  </div>

                  {/* Steps */}
                  <div className="mt-4 pt-3 border-t border-purple-900/30">
                    <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wider block mb-2 flex items-center gap-1.5">
                      <Compass className="w-3.5 h-3.5" />
                      {isAr ? 'خارطة طريق التنفيذ العملي:' : 'Actionable Execution Steps:'}
                    </span>
                    <ul className="space-y-1.5 text-xs text-purple-200/90">
                      {idea.keySteps.map((step, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <span>{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};
