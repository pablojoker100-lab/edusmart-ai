import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, BookOpen, Bot, TrendingUp, Trophy, ArrowRight, CheckCircle2, Share2, Copy, Check, Calculator, Atom, Dna, Languages, Cpu, Clock, Target, BarChart3, ChevronRight, GraduationCap, MessageSquare, Code2, Lightbulb, FileText, Mail } from 'lucide-react';
import { ActiveTab, EducationLevel, Language, UserProfile, UserProgressData } from '../types';
import { translations } from '../i18n/translations';
import { authService } from '../services/authService';

interface DashboardProps {
  lang: Language;
  level: EducationLevel;
  currentUser?: UserProfile | null;
  onNavigate: (tab: ActiveTab) => void;
  onOpenDeployment?: () => void;
}

export const HomeDashboard: React.FC<DashboardProps> = ({
  lang,
  level,
  currentUser,
  onNavigate,
  onOpenDeployment,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const deploymentUrl = authService.getDeploymentUrl();

  const [progress, setProgress] = useState<UserProgressData>({
    solvedCount: 0,
    quizzesTaken: 0,
    averageScore: 100,
    history: [],
  });
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    authService.getUserProgress().then(setProgress);
  }, [currentUser]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(deploymentUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Dynamic XP
  const totalXp = (progress.solvedCount * 25) + (progress.quizzesTaken * 50) + 120;

  // Subjects quick cards
  const subjectsHighlight = [
    { id: 'math', name: t.subjects.math, icon: <Calculator className="w-5 h-5 text-purple-300" />, desc: 'Calculus, Algebra, Geometry' },
    { id: 'physics', name: t.subjects.physics, icon: <Atom className="w-5 h-5 text-violet-300" />, desc: 'Mechanics, Optics, Thermodynamics' },
    { id: 'biology', name: t.subjects.biology, icon: <Dna className="w-5 h-5 text-fuchsia-300" />, desc: 'Genetics, Cell Biology, Physiology' },
    { id: 'cs', name: t.subjects.cs, icon: <Cpu className="w-5 h-5 text-pink-300" />, desc: 'Algorithms, Python, Logic Gates' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Hero Welcome Banner in Purple & Black */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#130b26] to-[#080512] border border-purple-800/40 text-white p-6 sm:p-10 shadow-2xl">
        {/* Subtle background glow */}
        <div className="absolute top-0 end-0 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 start-0 w-80 h-80 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-8 space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>{isRtl ? 'عقلك الذكي نحو مستقبل أفضل.' : 'Your intelligent mind towards a brighter future.'}</span>
              </span>

              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/40 border border-purple-800/40 text-purple-300 text-xs font-semibold">
                <Trophy className="w-3.5 h-3.5 text-amber-400" />
                <span>{totalXp} XP</span>
              </span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight">
              {currentUser
                ? (isRtl ? `مرحباً بك، ${currentUser.name.split(' ')[0]} 👋` : `Welcome back, ${currentUser.name.split(' ')[0]} 👋`)
                : t.dashboard.welcome}
            </h2>

            <p className="text-purple-200/80 text-xs sm:text-sm leading-relaxed max-w-xl">
              {t.dashboard.welcomeSubtitle}{' '}
              <strong className="text-purple-300 underline decoration-purple-500 decoration-2 underline-offset-4">
                {t.levels[level]}
              </strong>
              . {t.levelsDesc[level]}
            </p>

            {/* Quick Action Launchers */}
            <div className="pt-3 flex flex-wrap gap-2.5">
              <button
                type="button"
                onClick={() => onNavigate('chat')}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 hover:from-cyan-400 hover:to-pink-400 text-white text-xs sm:text-sm font-bold flex items-center gap-2 transition-all shadow-lg shadow-purple-900/60 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{isRtl ? 'المحادثة الذكية والرؤية' : 'Mind AI Chat'}</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('code')}
                className="px-4 py-2.5 rounded-xl bg-[#1a0f35] hover:bg-[#25154d] text-cyan-300 hover:text-white text-xs sm:text-sm font-bold border border-cyan-500/30 flex items-center gap-2 transition-all cursor-pointer shadow-md"
              >
                <Code2 className="w-4 h-4 text-cyan-400" />
                <span>{isRtl ? 'مساعد البرمجة' : 'Coding Assistant'}</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('solver')}
                className="px-4 py-2.5 rounded-xl bg-black/40 hover:bg-purple-950/60 text-purple-300 hover:text-white text-xs sm:text-sm font-bold border border-purple-900/40 flex items-center gap-2 transition-all cursor-pointer"
              >
                <span>📷</span>
                <span>{t.nav.solver}</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('ideas')}
                className="px-4 py-2.5 rounded-xl bg-[#1b1030] hover:bg-purple-900/50 text-amber-300 hover:text-white text-xs sm:text-sm font-bold border border-amber-500/30 flex items-center gap-2 transition-all cursor-pointer"
              >
                <Lightbulb className="w-4 h-4 text-amber-400" />
                <span>{isRtl ? 'مولّد الأفكار' : 'Ideas'}</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('lessons')}
                className="px-4 py-2.5 rounded-xl bg-purple-950/70 hover:bg-purple-900/70 text-purple-200 text-xs sm:text-sm font-bold border border-purple-800/40 flex items-center gap-2 transition-all cursor-pointer"
              >
                <GraduationCap className="w-4 h-4 text-emerald-400" />
                <span>{t.nav.lessons || 'الدروس'}</span>
              </button>
            </div>
          </div>

          {/* Hero Decorative Visual Box */}
          <div className="lg:col-span-4 hidden lg:flex justify-end">
            <div className="relative w-56 h-56 rounded-3xl overflow-hidden border border-purple-500/30 shadow-2xl purple-glow">
              <img
                src="/src/assets/images/hero_purple_dark_edusmart_1794356525826.jpg"
                alt="Mind AI Holographic Dashboard"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-3">
                <span className="text-[11px] font-bold text-purple-200">
                  {t.dashboard.systemStatus}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Counters in Purple & Black */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-[#120b24] p-4 sm:p-5 rounded-3xl border border-purple-900/30 shadow-xl space-y-1">
          <div className="flex items-center justify-between text-purple-400">
            <Target className="w-4 h-4" />
            <span className="text-[10px] font-mono text-purple-400/60 uppercase">Solved</span>
          </div>
          <span className="text-2xl sm:text-3xl font-black text-white block">
            {progress.solvedCount > 0 ? progress.solvedCount : '0'}
          </span>
          <span className="text-[11px] sm:text-xs text-purple-300/70 font-semibold block">
            {t.dashboard.statsSolved}
          </span>
        </div>

        <div className="bg-[#120b24] p-4 sm:p-5 rounded-3xl border border-purple-900/30 shadow-xl space-y-1">
          <div className="flex items-center justify-between text-violet-400">
            <CheckCircle2 className="w-4 h-4" />
            <span className="text-[10px] font-mono text-violet-400/60 uppercase">Quizzes</span>
          </div>
          <span className="text-2xl sm:text-3xl font-black text-white block">
            {progress.quizzesTaken > 0 ? progress.quizzesTaken : '0'}
          </span>
          <span className="text-[11px] sm:text-xs text-purple-300/70 font-semibold block">
            {t.dashboard.statsQuizzes}
          </span>
        </div>

        <div className="bg-[#120b24] p-4 sm:p-5 rounded-3xl border border-purple-900/30 shadow-xl space-y-1">
          <div className="flex items-center justify-between text-fuchsia-400">
            <BarChart3 className="w-4 h-4" />
            <span className="text-[10px] font-mono text-fuchsia-400/60 uppercase">Mastery</span>
          </div>
          <span className="text-2xl sm:text-3xl font-black text-white block">
            {progress.quizzesTaken > 0 ? `${progress.averageScore}%` : '96%'}
          </span>
          <span className="text-[11px] sm:text-xs text-purple-300/70 font-semibold block">
            {t.dashboard.statsAvgScore}
          </span>
        </div>

        <div className="bg-[#120b24] p-4 sm:p-5 rounded-3xl border border-purple-900/30 shadow-xl space-y-1">
          <div className="flex items-center justify-between text-amber-400">
            <Trophy className="w-4 h-4" />
            <span className="text-[10px] font-mono text-amber-400/60 uppercase">Points</span>
          </div>
          <span className="text-2xl sm:text-3xl font-black text-purple-400 block">
            {totalXp} XP
          </span>
          <span className="text-[11px] sm:text-xs text-purple-300/70 font-semibold block">
            {t.achievements.totalPoints}
          </span>
        </div>
      </div>

      {/* Mind AI Power Suite Showcase */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg sm:text-xl font-bold text-white">
              {isRtl ? 'منصة وأدوات Mind AI المتعددة' : 'Mind AI Multi-Tool Platform'}
            </h3>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('chat')}
            className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
          >
            <span>{isRtl ? 'فتح المحادثة الشاملة' : 'Launch Full AI Chat'}</span>
            <ChevronRight className="w-4 h-4 rtl:rotate-180" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
          {/* 1. Chat & Vision */}
          <div
            onClick={() => onNavigate('chat')}
            className="p-5 rounded-3xl bg-gradient-to-b from-[#180a30] to-[#0f0621] hover:from-[#210d42] hover:to-[#14082c] border border-cyan-500/30 hover:border-cyan-400/60 shadow-xl transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-300 group-hover:scale-110 transition-transform">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="text-sm sm:text-base font-black text-white group-hover:text-cyan-300 transition-colors">
                    {isRtl ? 'المحادثة والرؤية' : 'Smart Chat & Vision'}
                  </h4>
                  <span className="px-1.5 py-0.2 rounded-md bg-cyan-950 text-cyan-300 text-[9px] font-black border border-cyan-500/40">AI</span>
                </div>
                <p className="text-xs text-purple-300/70 mt-1 leading-snug">
                  {isRtl ? 'إجابات ذكية، تحليل الصور المرفوعة، وترجمة ونصوص فورية' : 'Intelligent chat with multimodal image understanding'}
                </p>
              </div>
            </div>
            <div className="mt-4 pt-2.5 border-t border-purple-900/30 flex items-center justify-between text-xs font-bold text-cyan-400">
              <span>{isRtl ? 'بدء المحادثة' : 'Chat Now'}</span>
              <span className="group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">→</span>
            </div>
          </div>

          {/* 2. Coding Assistant */}
          <div
            onClick={() => onNavigate('code')}
            className="p-5 rounded-3xl bg-[#120b24] hover:bg-[#180e30] border border-blue-500/30 hover:border-blue-400/60 shadow-xl transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-300 group-hover:scale-110 transition-transform">
                <Code2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm sm:text-base font-black text-white group-hover:text-blue-300 transition-colors">
                  {isRtl ? 'مساعد البرمجة' : 'Coding Assistant'}
                </h4>
                <p className="text-xs text-purple-300/70 mt-1 leading-snug">
                  {isRtl ? 'كتابة وتصحيح الأكواد بـ Python, JS, C++ مع تحليل التعقيد O(n)' : 'Generate, debug and explain code with complexity analysis'}
                </p>
              </div>
            </div>
            <div className="mt-4 pt-2.5 border-t border-purple-900/30 flex items-center justify-between text-xs font-bold text-blue-400">
              <span>{isRtl ? 'فتح المحرر' : 'Open Code'}</span>
              <span className="group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">→</span>
            </div>
          </div>

          {/* 3. Idea Generator */}
          <div
            onClick={() => onNavigate('ideas')}
            className="p-5 rounded-3xl bg-[#120b24] hover:bg-[#180e30] border border-amber-500/30 hover:border-amber-400/60 shadow-xl transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300 group-hover:scale-110 transition-transform">
                <Lightbulb className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm sm:text-base font-black text-white group-hover:text-amber-300 transition-colors">
                  {isRtl ? 'مولّد الأفكار' : 'Idea Generator'}
                </h4>
                <p className="text-xs text-purple-300/70 mt-1 leading-snug">
                  {isRtl ? 'ابتكار مشاريع، مواضيع أبحاث، وخطط تنفيذ واقعية' : 'Brainstorm startup ideas, projects and research topics'}
                </p>
              </div>
            </div>
            <div className="mt-4 pt-2.5 border-t border-purple-900/30 flex items-center justify-between text-xs font-bold text-amber-400">
              <span>{isRtl ? 'توليد أفكار' : 'Brainstorm'}</span>
              <span className="group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">→</span>
            </div>
          </div>

          {/* 4. Content Creator */}
          <div
            onClick={() => onNavigate('content')}
            className="p-5 rounded-3xl bg-[#120b24] hover:bg-[#180e30] border border-pink-500/30 hover:border-pink-400/60 shadow-xl transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-pink-500/20 border border-pink-400/30 flex items-center justify-center text-pink-300 group-hover:scale-110 transition-transform">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm sm:text-base font-black text-white group-hover:text-pink-300 transition-colors">
                  {isRtl ? 'إنشاء المحتوى' : 'Content Creator'}
                </h4>
                <p className="text-xs text-purple-300/70 mt-1 leading-snug">
                  {isRtl ? 'مقالات، منشورات تواصل، وسيناريوهات فيديو ملفتة' : 'Articles, viral social posts, and video scripts'}
                </p>
              </div>
            </div>
            <div className="mt-4 pt-2.5 border-t border-purple-900/30 flex items-center justify-between text-xs font-bold text-pink-400">
              <span>{isRtl ? 'صياغة المحتوى' : 'Write Copy'}</span>
              <span className="group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">→</span>
            </div>
          </div>

          {/* 5. Letter Composer */}
          <div
            onClick={() => onNavigate('letters')}
            className="p-5 rounded-3xl bg-[#120b24] hover:bg-[#180e30] border border-indigo-500/30 hover:border-indigo-400/60 shadow-xl transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300 group-hover:scale-110 transition-transform">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm sm:text-base font-black text-white group-hover:text-indigo-300 transition-colors">
                  {isRtl ? 'كتابة الرسائل' : 'Letter Composer'}
                </h4>
                <p className="text-xs text-purple-300/70 mt-1 leading-snug">
                  {isRtl ? 'رسائل وإيميلات أكاديمية ورسمية بأرقى الأساليب' : 'Formal emails, academic requests, and business letters'}
                </p>
              </div>
            </div>
            <div className="mt-4 pt-2.5 border-t border-purple-900/30 flex items-center justify-between text-xs font-bold text-indigo-400">
              <span>{isRtl ? 'صياغة رسالة' : 'Compose'}</span>
              <span className="group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">→</span>
            </div>
          </div>
        </div>
      </div>

      {/* Educational Subjects Section Spotlight */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-purple-400" />
            <h3 className="text-lg sm:text-xl font-bold text-white">
              {t.nav.subjects}
            </h3>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('subjects')}
            className="text-xs font-bold text-purple-400 hover:text-purple-300 flex items-center gap-1 cursor-pointer"
          >
            <span>{isRtl ? 'عرض كل المواد' : 'View All Subjects'}</span>
            <ChevronRight className="w-4 h-4 rtl:rotate-180" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {subjectsHighlight.map((sub) => (
            <div
              key={sub.id}
              onClick={() => onNavigate('subjects')}
              className="p-5 rounded-3xl bg-[#120b24] hover:bg-[#180e30] border border-purple-900/30 hover:border-purple-600/50 shadow-xl transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-2xl bg-purple-950/80 border border-purple-700/30 flex items-center justify-center group-hover:scale-105 transition-transform">
                  {sub.icon}
                </div>
                <div>
                  <h4 className="text-sm sm:text-base font-bold text-white group-hover:text-purple-300 transition-colors">
                    {sub.name}
                  </h4>
                  <p className="text-xs text-purple-300/70 mt-1 line-clamp-1">
                    {sub.desc}
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-purple-900/30 flex items-center justify-between text-xs font-bold text-purple-400">
                <span>{t.dashboard.quickAction}</span>
                <span className="group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">→</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI Study Assistant Spotlight Card */}
      <div className="rounded-3xl bg-gradient-to-r from-purple-950/90 via-[#160c2b] to-[#0d071b] border border-purple-800/40 p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-purple-900/40 text-purple-300 text-xs font-bold border border-purple-700/30">
              <Bot className="w-3.5 h-3.5 text-purple-400" />
              <span>{t.dashboard.tutorBanner}</span>
            </div>
            <h3 className="text-lg sm:text-2xl font-black text-white">
              {isRtl ? 'رفيقك الدراسي الذكي لحل وشرح المفاهيم المعقدة' : 'Your 24/7 AI Multi-Discipline Study Companion'}
            </h3>
            <p className="text-xs sm:text-sm text-purple-200/80 leading-relaxed">
              {t.dashboard.tutorBannerDesc}
            </p>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('tutor')}
            className="px-6 py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shadow-lg shadow-purple-900/50 cursor-pointer flex-shrink-0"
          >
            <Bot className="w-4 h-4" />
            <span>{isRtl ? 'بدء محادثة دراسية' : 'Start Study Session'}</span>
          </button>
        </div>
      </div>

      {/* Live Public Deployment Card */}
      <div className="bg-gradient-to-r from-purple-950 via-[#150a2c] to-[#080512] rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-purple-800/40 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-purple-900/50 text-purple-300 border border-purple-500/40 rounded-full text-xs font-bold inline-flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{isRtl ? 'التطبيق منشور ومتاح للعامة أونلاين' : 'Live Public Deployment Active'}</span>
            </span>
            <span className="text-xs text-purple-300/60 hidden sm:inline">
              Google Cloud Run • Web, Android & PC
            </span>
          </div>

          <div>
            <h3 className="text-lg sm:text-2xl font-black tracking-tight text-white">
              {isRtl ? 'رابط النشر الفعلي ومشاركة التطبيق للطلاب' : 'Public Deployment Link & Student Access'}
            </h3>
            <p className="text-xs sm:text-sm text-purple-200/80 mt-1 leading-relaxed">
              {isRtl
                ? 'تطبيقك منشور وجاهز للاستخدام من أي متصفح أو تثبيته كتطبيق مستقل على هواتف الأندرويد والآيفون والكمبيوتر.'
                : 'Your app is live in production! Share this real URL with students or install it as a PWA on Android and desktop.'}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
            <input
              type="text"
              readOnly
              value={deploymentUrl}
              className="flex-1 bg-black/50 border border-purple-800/40 rounded-xl px-3.5 py-2.5 text-xs font-mono text-purple-300 font-semibold select-all focus:outline-none"
            />
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopyLink}
                className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md shadow-purple-900/40"
              >
                <span>{copiedLink ? '✅' : '📋'}</span>
                <span>{copiedLink ? (isRtl ? 'تم النسخ!' : 'Copied!') : (isRtl ? 'نسخ الرابط' : 'Copy Link')}</span>
              </button>
              {onOpenDeployment && (
                <button
                  type="button"
                  onClick={onOpenDeployment}
                  className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-purple-950 hover:bg-purple-900 text-purple-200 text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 border border-purple-700/40 transition-colors cursor-pointer"
                >
                  <Share2 className="w-4 h-4" />
                  <span>{isRtl ? 'مشاركة وتفاصيل التثبيت' : 'Share & Install Guide'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Saved Learning History Section */}
      <div className="bg-[#120b24] rounded-3xl p-6 sm:p-8 border border-purple-900/30 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <Clock className="w-5 h-5 text-purple-400" />
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                {isRtl ? 'سجل الدراسة والنتائج المحفوظة' : 'Saved Study History & Quiz Results'}
              </h3>
              <p className="text-xs text-purple-300/70">
                {currentUser
                  ? (isRtl ? `تم حفظ تقدم الطالب: ${currentUser.name}` : `Saved learning activities for ${currentUser.name}`)
                  : (isRtl ? 'يتم حفظ أنشطتك الدراسية ونتائج اختباراتك تلقائياً' : 'Your learning activities and quiz scores are automatically saved')}
              </p>
            </div>
          </div>
          {progress.history.length > 0 && (
            <button
              type="button"
              onClick={() => onNavigate('progress')}
              className="text-xs font-bold text-purple-400 hover:text-purple-300 flex items-center gap-1 cursor-pointer"
            >
              <span>{isRtl ? 'عرض كل السجل' : 'View Analytics'}</span>
              <ChevronRight className="w-4 h-4 rtl:rotate-180" />
            </button>
          )}
        </div>

        {progress.history.length === 0 ? (
          <div className="text-center py-8 px-4 bg-black/30 rounded-2xl border border-dashed border-purple-900/40">
            <span className="text-3xl block mb-2">📚</span>
            <p className="text-xs sm:text-sm font-bold text-white">
              {isRtl ? 'لا توجد أنشطة مسجلة بعد' : 'No recorded study activities yet'}
            </p>
            <p className="text-xs text-purple-300/60 mt-1 max-w-md mx-auto">
              {isRtl
                ? 'ابدأ بحل مسألة في "حل الواجبات" أو أجب على أسئلة "الاختبار التدريبي" وسيتم حفظ تقدمك تلقائياً هنا.'
                : 'Solve homework or take a quiz to start building your academic history and progress.'}
            </p>
            <div className="mt-4 flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => onNavigate('solver')}
                className="px-4 py-2 bg-purple-600 text-white rounded-xl text-xs font-bold hover:bg-purple-500 transition-colors cursor-pointer shadow-md shadow-purple-900/40"
              >
                📷 {t.nav.solver}
              </button>
              <button
                type="button"
                onClick={() => onNavigate('quiz')}
                className="px-4 py-2 bg-purple-950 text-purple-200 border border-purple-700/40 rounded-xl text-xs font-bold hover:bg-purple-900 transition-colors cursor-pointer"
              >
                🎯 {t.nav.quiz}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-2.5">
            {progress.history.slice(0, 5).map((item) => (
              <div
                key={item.id}
                className="p-3.5 sm:p-4 rounded-2xl bg-black/40 hover:bg-purple-950/40 border border-purple-900/30 transition-colors flex items-center justify-between gap-3 text-xs sm:text-sm"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="text-xl flex-shrink-0">
                    {item.type === 'solve' ? '📷' : item.type === 'quiz' ? '🎯' : item.type === 'summary' ? '📑' : '💡'}
                  </span>
                  <div className="min-w-0">
                    <p className="font-bold text-white truncate">{item.title}</p>
                    <div className="flex items-center gap-2 mt-0.5 text-[11px] text-purple-300/60">
                      <span>{new Date(item.timestamp || item.date || Date.now()).toLocaleDateString(isRtl ? 'ar-EG' : 'en-US')}</span>
                      {item.subject && (
                        <span className="px-2 py-0.5 bg-purple-900/40 text-purple-300 rounded font-medium">
                          {item.subject}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {item.score && (
                  <span className="flex-shrink-0 px-2.5 py-1 bg-purple-950/90 text-purple-300 font-extrabold rounded-xl border border-purple-500/40 text-xs sm:text-sm">
                    {item.score}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
