import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Sparkles, Copy, Check, Send, RotateCcw, User, Shield } from 'lucide-react';
import { Language, EducationLevel, LetterResponse } from '../types';
import { aiService } from '../services/aiService';

export const LetterComposer: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang }) => {
  const isAr = lang === 'ar';

  const tones = [
    { id: 'formal', label: isAr ? 'رسمي ومهني' : 'Formal & Professional' },
    { id: 'academic', label: isAr ? 'أكاديمي للجامعة والمدرسة' : 'Academic & Educational' },
    { id: 'courteous', label: isAr ? 'مهذب ودبلوماسي' : 'Diplomatic & Polite' },
    { id: 'friendly', label: isAr ? 'ودي وشخصي' : 'Warm & Friendly' },
  ];

  const presets = [
    {
      purpose: isAr ? 'طلب إعادة تصحيح ورقة امتحان أو مراجعة نقطة' : 'Request for exam paper re-evaluation',
      recipient: isAr ? 'الأستاذ المشرف / إدارة المؤسسة التعليمية' : 'Head of Academic Department',
    },
    {
      purpose: isAr ? 'طلب تدريب مهني أو منحة دراسية' : 'Application for internship / academic scholarship',
      recipient: isAr ? 'مدير الموارد البشرية / لجنة القبول' : 'HR Manager / Admissions Board',
    },
    {
      purpose: isAr ? 'اعتذار رسمي عن الغياب لظرف طارئ' : 'Formal excuse letter for emergency absence',
      recipient: isAr ? 'إدارة المؤسسة أو مدير المدرسة' : 'School Administration',
    },
    {
      purpose: isAr ? 'طلب شهادة مدرسية أو تدريبية رسمية' : 'Request for school certificate or enrollment proof',
      recipient: isAr ? 'مصلحة الشؤون الطلابية' : 'Student Affairs Office',
    },
  ];

  const [purpose, setPurpose] = useState('');
  const [recipient, setRecipient] = useState('');
  const [senderName, setSenderName] = useState('');
  const [selectedTone, setSelectedTone] = useState('formal');
  const [isLoading, setIsLoading] = useState(false);
  const [letter, setLetter] = useState<LetterResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCompose = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!purpose.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const res = await aiService.generateLetter({
        purpose: purpose.trim(),
        recipient: recipient.trim() || undefined,
        tone: selectedTone,
        senderName: senderName.trim() || undefined,
        lang,
      });
      setLetter(res);
    } catch {
      setError(isAr ? 'تعذر إنشاء الرسالة. يرجى إعادة المحاولة.' : 'Failed to draft letter. Please retry.');
    } finally {
      setIsLoading(false);
    }
  };

  const copyLetterText = () => {
    if (!letter) return;
    const full = `${letter.subject}\n\n${letter.salutation}\n\n${letter.opening}\n\n${letter.bodyParagraphs.join('\n\n')}\n\n${letter.closing}\n\n${letter.signOff}`;
    navigator.clipboard.writeText(full);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Form Card */}
      <div className="bg-[#120b24] rounded-3xl p-6 sm:p-8 border border-purple-900/40 shadow-xl relative overflow-hidden">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-900/40">
            <Mail className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isAr ? 'مساعد كتابة الرسائل والإيميلات الرسمية' : 'Letter & Professional Email Composer'}
            </h2>
            <p className="text-xs sm:text-sm text-purple-300/70 mt-0.5">
              {isAr
                ? 'صياغة رسائل وإيميلات أكاديمية ومهنية متقنة الصياغة وبأرقى الأساليب التعبيرية'
                : 'Draft polished academic emails, formal requests, and official business letters with elegant phrasing'}
            </p>
          </div>
        </div>

        {/* Tone Selector */}
        <div className="flex flex-wrap gap-2 pt-4">
          {tones.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSelectedTone(t.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedTone === t.id
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                  : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 border border-purple-900/30'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Presets */}
        <div className="pt-4">
          <span className="text-[11px] font-bold text-purple-400/80 block mb-2">
            {isAr ? 'نماذج رسائل شائعة جاهزة:' : 'Common Letter Templates:'}
          </span>
          <div className="flex flex-wrap gap-2">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setPurpose(preset.purpose);
                  setRecipient(preset.recipient);
                }}
                className="text-xs bg-[#190f33] hover:bg-purple-900/50 text-purple-200 px-3 py-1.5 rounded-xl border border-purple-800/30 text-start cursor-pointer transition-all"
              >
                📝 {preset.purpose}
              </button>
            ))}
          </div>
        </div>

        {/* Form Inputs */}
        <form onSubmit={handleCompose} className="mt-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-purple-200">
                {isAr ? 'المرسل إليه (المسمى أو الشخص):' : 'Recipient Name / Title:'}
              </label>
              <input
                type="text"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder={isAr ? 'مثال: الأستاذ المشرف، عميد الكلية، إدارة الموارد البشرية' : 'e.g., Professor, Admissions Officer'}
                className="w-full bg-[#0a0515] border border-purple-900/50 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-purple-200">
                {isAr ? 'اسمك أو صفتك (المرسل):' : 'Your Name / Designation:'}
              </label>
              <input
                type="text"
                value={senderName}
                onChange={(e) => setSenderName(e.target.value)}
                placeholder={isAr ? 'مثال: أحمد المرابط - طالب بالسنة الثانية' : 'e.g., Jane Doe - Student'}
                className="w-full bg-[#0a0515] border border-purple-900/50 focus:border-cyan-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-purple-200">
              {isAr ? 'موضوع أو هدف الرسالة المطلوب صياغتها:' : 'Purpose or Goal of the Letter:'}
            </label>
            <textarea
              rows={3}
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder={
                isAr
                  ? 'صف بدقة ما تود طلبه أو توضيحه في الرسالة (مثال: طلب تأجيل موعد تسليم مشروع بحثي بسبب ظروف صحية)...'
                  : 'Describe what you need to request or explain in the message...'
              }
              className="w-full bg-[#0a0515] border border-purple-900/50 focus:border-cyan-500 rounded-2xl p-4 text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none focus:ring-1 focus:ring-cyan-500 transition-all font-medium leading-relaxed"
            />
          </div>

          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={!purpose.trim() || isLoading}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 disabled:opacity-40 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-blue-950/60 flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isLoading ? (isAr ? 'جاري صياغة الرسالة بدقة...' : 'Composing Letter...') : (isAr ? 'صياغة الرسالة فوراً' : 'Compose Letter')}</span>
            </button>

            {purpose && !isLoading && (
              <button
                type="button"
                onClick={() => {
                  setPurpose('');
                  setLetter(null);
                  setError(null);
                }}
                className="px-4 py-3 rounded-2xl bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 text-xs font-semibold cursor-pointer"
              >
                {isAr ? 'مسح' : 'Clear'}
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 bg-red-950/40 border border-red-500/40 rounded-2xl flex items-center justify-between text-xs text-red-200">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => handleCompose()}
            className="px-3 py-1 bg-red-600 text-white rounded-xl font-bold flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
          </button>
        </div>
      )}

      {/* Letter Result */}
      {letter && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#120b24] rounded-3xl p-6 sm:p-8 border border-purple-900/40 shadow-2xl space-y-6"
        >
          {/* Header Action */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-purple-900/30">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-3 py-1 rounded-full">
                {letter.tone} Letter
              </span>
              <h3 className="text-base sm:text-lg font-black text-white mt-2">{letter.subject}</h3>
            </div>

            <button
              type="button"
              onClick={copyLetterText}
              className="px-4 py-2 rounded-xl bg-purple-900/60 hover:bg-purple-800/60 border border-purple-700/40 text-purple-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">{isAr ? 'تم نسخ نص الرسالة' : 'Copied!'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isAr ? 'نسخ الرسالة بالكامل' : 'Copy Full Letter'}</span>
                </>
              )}
            </button>
          </div>

          {/* Letter Sheet */}
          <div className="p-6 sm:p-8 rounded-2xl bg-[#080410] border border-purple-800/30 text-xs sm:text-sm text-purple-100 font-sans space-y-4 leading-relaxed select-all shadow-inner">
            <div className="text-purple-300 font-bold border-b border-purple-900/40 pb-3">
              {letter.subject}
            </div>

            <p className="font-bold text-white">{letter.salutation}</p>
            <p className="text-purple-200">{letter.opening}</p>

            {letter.bodyParagraphs.map((para, idx) => (
              <p key={idx} className="text-purple-100">
                {para}
              </p>
            ))}

            <p className="text-purple-200 pt-2">{letter.closing}</p>
            <p className="font-bold text-white pt-1">{letter.signOff}</p>
          </div>
        </motion.div>
      )}
    </div>
  );
};
