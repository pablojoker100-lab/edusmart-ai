import React, { useState } from 'react';
import { Language, EducationLevel, QuizQuestion } from '../types';
import { translations } from '../i18n/translations';
import { aiService } from '../services/aiService';
import { authService } from '../services/authService';

export const QuizArena: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang, level }) => {
  const t = translations[lang].quiz;
  const common = translations[lang].common;

  const [topic, setTopic] = useState('');
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [isFinished, setIsFinished] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const topicSuggestions = [
    lang === 'ar' ? 'التمثيل الضوئي والتنفس الخلوي' : 'Photosynthesis & Cellular Respiration',
    lang === 'ar' ? 'قوانين نيوتن في الحركة والجاذبية' : 'Newtonian Mechanics & Gravity',
    lang === 'ar' ? 'المعادلات التربيعية والتفاضل' : 'Quadratic Functions & Calculus',
    lang === 'ar' ? 'الثورة الصناعية والتاريخ الحديث' : 'Industrial Revolution & Modern History',
  ];

  const startQuiz = async (chosenTopic?: string) => {
    const finalTopic = chosenTopic || topic;
    setIsLoading(true);
    setError(null);
    setQuestions([]);
    setCurrentIndex(0);
    setSelectedAnswers([]);
    setIsFinished(false);

    try {
      const generated = await aiService.generateQuiz(finalTopic, level, lang);
      if (generated && generated.length > 0) {
        setQuestions(generated);
      } else {
        throw new Error('No questions generated');
      }
    } catch (err: any) {
      setError(err?.message || common.error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectOption = (optionIndex: number) => {
    const updated = [...selectedAnswers];
    updated[currentIndex] = optionIndex;
    setSelectedAnswers(updated);
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setIsFinished(true);
      const earned = calculateScore();
      const total = questions.length;
      authService
        .recordActivity({
          type: 'quiz',
          title: topic || (lang === 'ar' ? 'اختبار مراجعة دراسي' : 'Academic Quiz'),
          score: `${earned}/${total}`,
          details: { earned, total, percentage: Math.round((earned / total) * 100) },
        })
        .catch(() => {});
    }
  };

  const calculateScore = () => {
    return questions.reduce((acc, q, idx) => {
      return acc + (selectedAnswers[idx] === q.correctIndex ? 1 : 0);
    }, 0);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-sm border border-slate-200">
        <div className="flex items-start justify-between flex-wrap gap-2 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">🎯</span>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">{t.title}</h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">{t.subtitle}</p>
          </div>
          <span className="px-3 py-1 bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold rounded-full">
            {translations[lang].levels[level]}
          </span>
        </div>

        {/* Topic suggestions */}
        <div className="mb-4">
          <p className="text-xs font-semibold text-slate-500 mb-2">
            {lang === 'ar' ? 'مواضيع مقترحة للاختبار السريع:' : 'Suggested topics:'}
          </p>
          <div className="flex flex-wrap gap-1.5">
            {topicSuggestions.map((sug, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setTopic(sug);
                  startQuiz(sug);
                }}
                className="text-xs bg-slate-50 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200 transition-colors cursor-pointer"
              >
                🎯 {sug}
              </button>
            ))}
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            startQuiz();
          }}
          className="flex flex-col sm:flex-row gap-2.5"
        >
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder={t.topicPlaceholder}
            className="flex-1 rounded-2xl border border-slate-300 px-4 py-3 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
          />
          <button
            type="submit"
            disabled={isLoading}
            className="px-7 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-semibold text-xs sm:text-sm transition-all shadow-md shadow-indigo-100 flex items-center justify-center gap-2 cursor-pointer"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                </svg>
                <span>{common.loading}</span>
              </>
            ) : (
              <span>{t.generateBtn}</span>
            )}
          </button>
        </form>
      </div>

      {error && <div className="p-4 bg-red-50 text-red-700 rounded-2xl text-sm border border-red-200">{error}</div>}

      {/* Quiz Screen */}
      {questions.length > 0 && !isFinished && (
        <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-sm border border-slate-200 space-y-6">
          {/* Progress Bar */}
          <div>
            <div className="flex justify-between items-center text-xs text-slate-500 font-semibold mb-2">
              <span>
                {lang === 'ar'
                  ? `السؤال ${currentIndex + 1} من ${questions.length}`
                  : `Question ${currentIndex + 1} of ${questions.length}`}
              </span>
              <span className="text-indigo-600 font-bold">
                {Math.round(((currentIndex + 1) / questions.length) * 100)}%
              </span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo-600 transition-all duration-300 rounded-full"
                style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
              />
            </div>
          </div>

          <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
            {questions[currentIndex].question}
          </h3>

          <div className="space-y-3">
            {questions[currentIndex].options.map((opt, i) => {
              const isSelected = selectedAnswers[currentIndex] === i;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSelectOption(i)}
                  className={`w-full text-start p-4 rounded-2xl text-xs sm:text-sm border font-medium transition-all cursor-pointer flex items-center gap-3 ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/80 text-indigo-950 ring-2 ring-indigo-500/80 shadow-sm'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-800'
                  }`}
                >
                  <span
                    className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                      isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="flex-1">{opt}</span>
                </button>
              );
            })}
          </div>

          <div className="flex justify-between items-center pt-2">
            <span className="text-xs text-slate-400">
              {selectedAnswers[currentIndex] === undefined ? 'Choose an option to continue' : 'Option selected'}
            </span>
            <button
              type="button"
              disabled={selectedAnswers[currentIndex] === undefined}
              onClick={handleNext}
              className="px-7 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs sm:text-sm font-semibold transition-all shadow-md shadow-indigo-100 cursor-pointer"
            >
              {currentIndex === questions.length - 1 ? t.finish : t.next}
            </button>
          </div>
        </div>
      )}

      {/* Quiz Result View */}
      {isFinished && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 space-y-6 text-center">
          <div className="w-20 h-20 rounded-3xl bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto text-4xl shadow-sm">
            🏆
          </div>

          <div>
            <h3 className="text-xl sm:text-2xl font-bold text-slate-900">{t.score}</h3>
            <p className="text-4xl sm:text-5xl font-extrabold text-indigo-600 mt-2">
              {calculateScore()} / {questions.length}
            </p>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 font-medium">
              {Math.round((calculateScore() / questions.length) * 100)}% Mastery Level
            </p>
          </div>

          {/* Breakdown for each question */}
          <div className="space-y-4 text-start mt-6">
            {questions.map((q, idx) => {
              const userPick = selectedAnswers[idx];
              const isCorrect = userPick === q.correctIndex;
              return (
                <div
                  key={q.id || idx}
                  className={`p-4 sm:p-5 rounded-2xl border text-xs sm:text-sm ${
                    isCorrect
                      ? 'bg-emerald-50/50 border-emerald-200'
                      : 'bg-red-50/40 border-red-200'
                  }`}
                >
                  <div className="flex items-start gap-2.5 mb-2">
                    <span className="text-base mt-0.5">{isCorrect ? '✅' : '❌'}</span>
                    <div>
                      <strong className="text-slate-900 block leading-snug">{q.question}</strong>
                      <div className="mt-1.5 text-xs">
                        <span className="text-slate-500 font-medium">Your answer: </span>
                        <span className={isCorrect ? 'text-emerald-700 font-bold' : 'text-red-700 font-bold'}>
                          {userPick !== undefined ? q.options[userPick] : 'No answer'}
                        </span>
                        {!isCorrect && (
                          <div className="text-emerald-700 font-bold mt-0.5">
                            Correct answer: {q.options[q.correctIndex]}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="mt-2.5 p-3 bg-white rounded-xl border border-slate-200/80 text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900">💡 {t.explanation}:</strong> {q.explanation}
                  </div>
                </div>
              );
            })}
          </div>

          <button
            onClick={() => {
              setQuestions([]);
              setIsFinished(false);
              setTopic('');
            }}
            className="px-8 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm transition-all shadow-md shadow-indigo-200 cursor-pointer"
          >
            🔄 {t.tryAgain}
          </button>
        </div>
      )}
    </div>
  );
};
