import React, { useEffect, useState } from 'react';
import { WifiOff, Wifi } from 'lucide-react';
import { Language } from '../types';

export const OfflineIndicator: React.FC<{ lang: Language }> = ({ lang }) => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [showReconnected, setShowReconnected] = useState(false);
  const isRtl = lang === 'ar';

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowReconnected(true);
      setTimeout(() => setShowReconnected(false), 3000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowReconnected(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline && !showReconnected) {
    return null;
  }

  return (
    <div className="fixed top-14 start-4 end-4 md:start-auto md:end-6 md:max-w-sm z-50 animate-in fade-in slide-in-from-top-2 duration-200">
      {!isOnline ? (
        <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-amber-950/90 border border-amber-600/50 text-amber-200 shadow-xl backdrop-blur-md text-xs font-semibold">
          <WifiOff className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>
            {isRtl
              ? 'وضع عدم الاتصال: يمكنك تصفح الدروس والمفاهيم المحفوظة محلياً.'
              : 'Offline Mode: You can browse locally cached lessons and concepts.'}
          </span>
        </div>
      ) : (
        <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-emerald-950/90 border border-emerald-600/50 text-emerald-200 shadow-xl backdrop-blur-md text-xs font-semibold">
          <Wifi className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>
            {isRtl ? 'تمت استعادة الاتصال بالإنترنت بنجاح!' : 'Internet connection restored!'}
          </span>
        </div>
      )}
    </div>
  );
};
