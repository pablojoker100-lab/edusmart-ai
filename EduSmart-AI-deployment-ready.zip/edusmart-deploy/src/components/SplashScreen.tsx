import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Language } from '../types';
import { MindLogo } from './MindLogo';

interface SplashScreenProps {
  onFinish: () => void;
  lang: Language;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish, lang }) => {
  const [progress, setProgress] = useState(15);
  const isRtl = lang === 'ar';

  useEffect(() => {
    const timer1 = setTimeout(() => setProgress(55), 350);
    const timer2 = setTimeout(() => setProgress(90), 800);
    const timer3 = setTimeout(() => setProgress(100), 1250);
    const timer4 = setTimeout(() => onFinish(), 1600);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [onFinish]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.45, ease: 'easeInOut' } }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-between p-8 bg-[#07040e] text-white selection:bg-purple-600 select-none overflow-hidden"
    >
      {/* Background Radial Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] bg-gradient-to-tr from-cyan-600/15 via-purple-700/20 to-pink-600/15 rounded-full blur-[130px] pointer-events-none" />

      {/* Top Tag */}
      <div className="relative z-10 pt-4">
        <span className="text-[11px] font-bold px-3.5 py-1 rounded-full bg-purple-950/70 border border-purple-700/50 text-purple-200 shadow-lg">
          Mind AI • Web & Android PWA
        </span>
      </div>

      {/* Center Logo & Branding */}
      <div className="relative z-10 flex flex-col items-center text-center space-y-6 max-w-sm">
        {/* Animated Brand Emblem */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="relative"
        >
          <MindLogo size="xl" showText={false} lang={lang} />
        </motion.div>

        {/* Title & Official Slogan */}
        <motion.div
          initial={{ y: 15, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="space-y-2"
        >
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            Mind <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">AI</span>
          </h1>
          <p className="text-sm sm:text-base text-purple-200/90 font-bold max-w-xs mx-auto">
            {isRtl
              ? 'عقلك الذكي نحو مستقبل أفضل.'
              : 'Your intelligent mind towards a brighter future.'}
          </p>
        </motion.div>

        {/* Progress Bar */}
        <div className="w-52 space-y-2 pt-2">
          <div className="h-1.5 w-full bg-purple-950/90 rounded-full overflow-hidden p-0.5 border border-purple-800/40">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-400"
              initial={{ width: '15%' }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.4 }}
            />
          </div>
          <span className="text-[11px] text-purple-300 font-mono block">
            {isRtl ? 'جاري تشغيل محرك Mind AI الفائق...' : 'Initializing Mind AI Engine...'}
          </span>
        </div>
      </div>

      {/* Bottom Footer & Skip */}
      <div className="relative z-10 pb-4 text-center">
        <button
          type="button"
          onClick={onFinish}
          className="text-xs text-purple-400/80 hover:text-white px-4 py-1.5 rounded-full hover:bg-purple-950/40 transition-colors cursor-pointer"
        >
          {isRtl ? 'تخطي' : 'Skip'}
        </button>
      </div>
    </motion.div>
  );
};
