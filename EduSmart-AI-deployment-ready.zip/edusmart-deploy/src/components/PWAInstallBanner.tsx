import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, Smartphone, X, Check, Share, PlusSquare, Sparkles } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Language } from '../types';

interface PWAInstallBannerProps {
  lang: Language;
}

export const PWAInstallBanner: React.FC<PWAInstallBannerProps> = ({ lang }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [isDismissed, setIsDismissed] = useState(false);
  const [showIOSModal, setShowIOSModal] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  const isRtl = lang === 'ar';

  // Do not render if app is already running in standalone mode (installed), or dismissed
  if (isInstalled || isDismissed) {
    return null;
  }

  // If on desktop/mobile and not installable yet, show guided banner only on mobile devices
  const canShowBanner = isInstallable || isIOS || isAndroid;
  if (!canShowBanner) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      setIsInstalling(true);
      await install();
      setIsInstalling(false);
    } else if (isIOS) {
      setShowIOSModal(true);
    } else {
      // Fallback for Android when prompt event is pending: inform user
      alert(
        isRtl
          ? 'لتثبيت التطبيق على هاتفك: اضغط على زر القائمة (⋮) أعلى المتصفح، ثم اختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".'
          : 'To install on your phone: Tap browser menu (⋮) and select "Install app" or "Add to Home screen".'
      );
    }
  };

  return (
    <>
      {/* Floating In-App Install Prompt Banner */}
      <AnimatePresence>
        {!isDismissed && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="fixed bottom-20 md:bottom-6 start-4 end-4 md:start-auto md:end-6 md:max-w-md z-40"
          >
            <div className="bg-[#120b24]/95 backdrop-blur-xl border border-purple-500/40 rounded-3xl p-4 shadow-2xl purple-glow relative overflow-hidden">
              {/* Top ambient highlight */}
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-purple-500 via-fuchsia-500 to-violet-400" />

              <div className="flex items-center justify-between gap-3">
                {/* Icon & Title */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500/20 via-purple-600/30 to-pink-500/20 p-0.5 shadow-lg flex-shrink-0 border border-purple-500/40 flex items-center justify-center">
                    <img
                      src="/icons/icon-192x192.png"
                      alt="Mind AI"
                      className="w-full h-full object-cover rounded-[14px]"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/favicon.svg';
                      }}
                    />
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-black text-white truncate">Mind AI</h4>
                      <span className="px-1.5 py-0.2 rounded-md bg-purple-900/60 text-purple-300 text-[10px] font-bold border border-purple-700/40">
                        PWA
                      </span>
                    </div>
                    <p className="text-[11px] text-purple-200/80 mt-0.5 leading-snug truncate">
                      {isRtl
                        ? 'تثبيت التطبيق على هاتفك للوصول السريع'
                        : 'Install app on your device for fast access'}
                    </p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    type="button"
                    onClick={handleInstallClick}
                    disabled={isInstalling}
                    className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center gap-1.5 transition-all shadow-md shadow-purple-900/50 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>
                      {isInstalling
                        ? (isRtl ? 'جاري التثبيت...' : 'Installing...')
                        : (isRtl ? 'تثبيت الآن' : 'Install')}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsDismissed(true)}
                    className="w-8 h-8 rounded-xl bg-purple-950/60 hover:bg-purple-900 text-purple-300/70 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                    aria-label="Dismiss"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* iOS Installation Guided Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-sm rounded-3xl bg-[#130b24] border border-purple-800/60 p-6 text-white shadow-2xl relative"
          >
            <button
              onClick={() => setShowIOSModal(false)}
              className="absolute top-4 end-4 text-purple-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-12 h-12 rounded-2xl bg-purple-950 border border-purple-500/40 flex items-center justify-center text-purple-300 mb-4">
              <Smartphone className="w-6 h-6" />
            </div>

            <h3 className="text-base sm:text-lg font-black text-white">
              {isRtl ? 'تثبيت التطبيق على iPhone / iPad' : 'Install on iPhone / iPad'}
            </h3>

            <div className="mt-4 space-y-3 text-xs text-purple-200/90 leading-relaxed">
              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-black/40 border border-purple-900/40">
                <Share className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                <span>
                  {isRtl
                    ? '1. اضغط على زر المشاركة (Share) في شريط أدوات Safari بالأسفل.'
                    : '1. Tap the Share button in the Safari toolbar.'}
                </span>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-black/40 border border-purple-900/40">
                <PlusSquare className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                <span>
                  {isRtl
                    ? '2. مرر للأسفل واختر "إضافة إلى الشاشة الرئيسية" (Add to Home Screen).'
                    : '2. Scroll down and tap "Add to Home Screen".'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowIOSModal(false)}
              className="mt-5 w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 font-bold text-xs text-white transition-colors"
            >
              {isRtl ? 'حسناً، فهمت' : 'Got it'}
            </button>
          </motion.div>
        </div>
      )}
    </>
  );
};
