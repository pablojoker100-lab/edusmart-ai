import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, ShieldCheck, Mail, GraduationCap, LogOut, Key, Eye, EyeOff, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';
import { Language, EducationLevel, UserProfile, UserProgressData } from '../types';
import { translations } from '../i18n/translations';
import { authService } from '../services/authService';
import { MindLogo } from './MindLogo';

interface StudentProfileProps {
  lang: Language;
  currentLevel: EducationLevel;
  currentUser: UserProfile | null;
  progress: UserProgressData;
  onLoginSuccess: (user: UserProfile) => void;
  onLogout: () => void;
  onLevelChange: (level: EducationLevel) => void;
  onNavigateHome: () => void;
}

type AuthTab = 'login' | 'register' | 'forgot';

export const StudentProfile: React.FC<StudentProfileProps> = ({
  lang,
  currentLevel,
  currentUser,
  progress,
  onLoginSuccess,
  onLogout,
  onLevelChange,
  onNavigateHome,
}) => {
  const t = translations[lang].auth;
  const tLevels = translations[lang].levels;
  const isRtl = lang === 'ar';

  const [authTab, setAuthTab] = useState<AuthTab>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; isError: boolean } | null>(null);

  // Dynamic XP
  const totalXp = (progress.solvedCount * 25) + (progress.quizzesTaken * 50) + 120;

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) return;

    setIsLoading(true);
    setMessage(null);
    const res = await authService.login(email.trim(), password);
    setIsLoading(false);

    if (res.success && res.user) {
      setMessage({ text: t.successLogin, isError: false });
      setTimeout(() => onLoginSuccess(res.user!), 800);
    } else {
      setMessage({ text: res.message || 'بيانات الدخول غير صحيحة', isError: true });
    }
  };

  // Handle Register
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password) return;

    setIsLoading(true);
    setMessage(null);
    const res = await authService.register(email.trim(), password, name.trim(), currentLevel);
    setIsLoading(false);

    if (res.success && res.user) {
      setMessage({ text: t.successRegister, isError: false });
      setTimeout(() => onLoginSuccess(res.user!), 800);
    } else {
      setMessage({ text: res.message || 'فشل إنشاء الحساب', isError: true });
    }
  };

  // Google Sign-In
  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setMessage(null);
    const res = await authService.loginWithGoogle(
      'pablojoker100@gmail.com',
      'طالب متميز',
      undefined,
      currentLevel
    );
    setIsLoading(false);
    if (res.success && res.user) {
      setMessage({ text: t.successLogin, isError: false });
      setTimeout(() => onLoginSuccess(res.user!), 800);
    } else {
      setMessage({ text: res.message || 'فشل تسجيل الدخول بـ Google', isError: true });
    }
  };

  // Forgot Password
  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsLoading(true);
    setMessage(null);
    const res = await authService.forgotPassword(email.trim());
    setIsLoading(false);
    if (res.success) {
      setMessage({
        text: `${res.message} ${res.resetCode ? `(رمز التجربة: ${res.resetCode})` : ''}`,
        isError: false,
      });
    } else {
      setMessage({ text: res.message || 'فشل إرسال رمز الاستعادة', isError: true });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
      {/* If User is Logged In: Show Full Profile View */}
      {currentUser ? (
        <div className="space-y-6">
          {/* Profile Hero Card */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#150c29] to-[#0a0714] border border-purple-800/40 p-6 sm:p-8 shadow-2xl">
            <div className="absolute top-0 end-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start justify-between gap-6">
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-start">
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-purple-600 to-violet-400 p-1 shadow-xl purple-glow-sm">
                  <div className="w-full h-full bg-[#0d071b] rounded-[22px] flex items-center justify-center text-3xl font-black text-purple-300">
                    {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : '👤'}
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 justify-center sm:justify-start">
                    <h2 className="text-xl sm:text-2xl font-black text-white">{currentUser.name}</h2>
                    <span className="px-2.5 py-0.5 rounded-full bg-purple-900/40 border border-purple-500/30 text-purple-300 text-xs font-bold">
                      {tLevels[currentLevel]}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-purple-300/70 font-mono">{currentUser.email}</p>
                  <div className="flex items-center gap-2 pt-1 text-xs text-emerald-400 font-semibold justify-center sm:justify-start">
                    <ShieldCheck className="w-4 h-4" />
                    <span>{t.sessionActive}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={onLogout}
                className="px-4 py-2 rounded-xl bg-purple-950/60 hover:bg-red-950/60 border border-purple-800/40 hover:border-red-700/50 text-purple-300 hover:text-red-300 text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>{t.logoutBtn}</span>
              </button>
            </div>
          </div>

          {/* Quick Academic Overview Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-5 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-lg text-center space-y-1">
              <span className="text-xs text-purple-300/70 font-semibold block">Total XP</span>
              <span className="text-2xl font-black text-purple-400">{totalXp} XP</span>
            </div>
            <div className="p-5 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-lg text-center space-y-1">
              <span className="text-xs text-purple-300/70 font-semibold block">{translations[lang].dashboard.statsSolved}</span>
              <span className="text-2xl font-black text-violet-400">{progress.solvedCount}</span>
            </div>
            <div className="p-5 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-lg text-center space-y-1">
              <span className="text-xs text-purple-300/70 font-semibold block">{translations[lang].dashboard.statsQuizzes}</span>
              <span className="text-2xl font-black text-fuchsia-400">{progress.quizzesTaken}</span>
            </div>
            <div className="p-5 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-lg text-center space-y-1">
              <span className="text-xs text-purple-300/70 font-semibold block">{translations[lang].dashboard.statsAvgScore}</span>
              <span className="text-2xl font-black text-amber-400">
                {progress.quizzesTaken > 0 ? `${progress.averageScore}%` : '96%'}
              </span>
            </div>
          </div>

          {/* Educational Grade Level Selector */}
          <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-4">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <GraduationCap className="w-5 h-5 text-purple-400" />
              <span>{isRtl ? 'تعديل المرحلة الدراسية' : 'Change Educational Level'}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {(['primary', 'middle', 'high', 'university'] as EducationLevel[]).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => onLevelChange(lvl)}
                  className={`p-4 rounded-2xl border text-xs sm:text-sm font-bold transition-all text-center cursor-pointer ${
                    currentLevel === lvl
                      ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-900/50 scale-[1.02]'
                      : 'bg-black/30 text-purple-200/70 hover:text-white hover:bg-purple-950/40 border-purple-900/30'
                  }`}
                >
                  <span className="block text-xl mb-1.5">
                    {lvl === 'primary' ? '🎒' : lvl === 'middle' ? '📐' : lvl === 'high' ? '🎓' : '🏛️'}
                  </span>
                  <span>{tLevels[lvl]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Security & Cryptographic Details */}
          <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-3">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>{isRtl ? 'حماية الحساب والتشفير المتقدم' : 'Account Security & Encryption'}</span>
            </div>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              {isRtl
                ? 'كلمات المرور مشفرة بخوارزمية التشفير المتطورة scrypt مع أملاح تشفير فريدة (Cryptographic Salt) ومطابقة بوقت ثابت لمنع أي محاولات اختراق أو تسريب.'
                : 'Passwords are encrypted using Node.js scrypt with unique random salts and constant-time verification. Plain text passwords are never stored.'}
            </p>
          </div>
        </div>
      ) : (
        /* If User is NOT Logged In: Modern Auth Form */
        <div className="max-w-md mx-auto rounded-3xl bg-[#130b24] border border-purple-800/40 p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-2 flex flex-col items-center">
            <MindLogo size="lg" showText={false} lang={lang} />
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {authTab === 'login' ? t.loginTitle : authTab === 'register' ? t.registerTitle : t.forgotTitle}
            </h2>
            <p className="text-xs text-purple-300/70">
              {authTab === 'login' ? t.loginSubtitle : authTab === 'register' ? t.registerSubtitle : t.forgotSubtitle}
            </p>
          </div>

          {/* Auth Tab Switcher */}
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-black/40 rounded-xl border border-purple-900/40">
            <button
              type="button"
              onClick={() => { setAuthTab('login'); setMessage(null); }}
              className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                authTab === 'login'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-purple-300/70 hover:text-white'
              }`}
            >
              {t.loginBtn}
            </button>
            <button
              type="button"
              onClick={() => { setAuthTab('register'); setMessage(null); }}
              className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                authTab === 'register'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-purple-300/70 hover:text-white'
              }`}
            >
              {t.registerBtn}
            </button>
          </div>

          {/* Message Notification */}
          {message && (
            <div className={`p-3 rounded-xl text-xs font-semibold ${
              message.isError
                ? 'bg-red-950/60 text-red-200 border border-red-800/50'
                : 'bg-emerald-950/60 text-emerald-200 border border-emerald-800/50'
            }`}>
              {message.text}
            </div>
          )}

          {/* Login Form */}
          {authTab === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-purple-200">{t.emailLabel}</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={t.emailPlaceholder}
                  className="w-full bg-black/40 border border-purple-900/40 focus:border-purple-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-semibold text-purple-200">{t.passwordLabel}</label>
                  <button
                    type="button"
                    onClick={() => setAuthTab('forgot')}
                    className="text-[11px] text-purple-400 hover:text-purple-300 font-medium"
                  >
                    {t.forgotLink}
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={t.passwordPlaceholder}
                    className="w-full bg-black/40 border border-purple-900/40 focus:border-purple-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none pe-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 end-3 flex items-center text-purple-400/70 hover:text-purple-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-purple-900/50 cursor-pointer"
              >
                {isLoading ? 'جاري التحقق...' : t.loginBtn}
              </button>
            </form>
          )}

          {/* Register Form */}
          {authTab === 'register' && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-purple-200">{t.nameLabel}</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t.namePlaceholder}
                  className="w-full bg-black/40 border border-purple-900/40 focus:border-purple-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-purple-200">{t.emailLabel}</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={t.emailPlaceholder}
                  className="w-full bg-black/40 border border-purple-900/40 focus:border-purple-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-purple-200">{t.passwordLabel}</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.passwordPlaceholder}
                  className="w-full bg-black/40 border border-purple-900/40 focus:border-purple-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-purple-900/50 cursor-pointer"
              >
                {isLoading ? 'جاري الإنشاء...' : t.registerBtn}
              </button>
            </form>
          )}

          {/* Forgot Password */}
          {authTab === 'forgot' && (
            <form onSubmit={handleForgot} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-purple-200">{t.emailLabel}</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={t.emailPlaceholder}
                  className="w-full bg-black/40 border border-purple-900/40 focus:border-purple-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-purple-900/50 cursor-pointer"
              >
                {isLoading ? 'جاري الإرسال...' : t.forgotBtn}
              </button>

              <button
                type="button"
                onClick={() => setAuthTab('login')}
                className="w-full text-center text-xs text-purple-400 hover:text-purple-300 font-semibold"
              >
                {t.backToLogin}
              </button>
            </form>
          )}

          {/* Google Sign In Divider */}
          <div className="relative pt-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-purple-900/40" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-[#130b24] px-2 text-purple-300/60 font-medium">أو عبر حساب Google</span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-full py-3 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            <span>الدخول السريع بحساب Google</span>
          </button>
        </div>
      )}
    </div>
  );
};
