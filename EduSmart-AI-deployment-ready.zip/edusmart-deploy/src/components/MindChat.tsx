import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Send,
  Camera,
  Image as ImageIcon,
  X,
  RotateCcw,
  Copy,
  Check,
  Plus,
  Trash2,
  Sparkles,
  MessageSquare,
  Bot,
  User,
  Code2,
  Lightbulb,
  FileText,
  Languages,
  BookOpen
} from 'lucide-react';
import { Language, EducationLevel, ChatMessage, ChatConversation } from '../types';
import { translations } from '../i18n/translations';
import { aiService } from '../services/aiService';
import { MindLogo } from './MindLogo';

interface MindChatProps {
  lang: Language;
  level: EducationLevel;
}

export const MindChat: React.FC<MindChatProps> = ({ lang, level }) => {
  const isAr = lang === 'ar';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Available conversation specialized modes
  const modes = [
    { id: 'general', label: isAr ? 'محادثة عامة' : 'General Chat', icon: MessageSquare, color: 'from-purple-600 to-indigo-600' },
    { id: 'writing', label: isAr ? 'كتابة ومقالات' : 'Essay & Writing', icon: FileText, color: 'from-fuchsia-600 to-purple-600' },
    { id: 'translate', label: isAr ? 'ترجمة فورية' : 'Translation', icon: Languages, color: 'from-cyan-600 to-blue-600' },
    { id: 'study', label: isAr ? 'شرح ودراسة' : 'Study & Lessons', icon: BookOpen, color: 'from-emerald-600 to-teal-600' },
    { id: 'code', label: isAr ? 'مساعد البرمجة' : 'Coding Assistant', icon: Code2, color: 'from-blue-600 to-indigo-600' },
    { id: 'ideas', label: isAr ? 'توليد الأفكار' : 'Idea Generator', icon: Lightbulb, color: 'from-amber-600 to-orange-600' },
  ];

  const [activeMode, setActiveMode] = useState<string>('general');
  const [conversations, setConversations] = useState<ChatConversation[]>(() => {
    try {
      const saved = localStorage.getItem('mind_ai_conversations');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return [
      {
        id: 'conv-1',
        title: isAr ? 'محادثة ترحيبية' : 'Welcome Conversation',
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mode: 'general',
        messages: [
          {
            id: 'init-msg',
            sender: 'ai',
            text: isAr
              ? 'مرحباً بك في Mind AI — عقلك الذكي نحو مستقبل أفضل.\n\nأنا منصتك الذكية متعددة الوظائف، جاهز لمساعدتك في:\n• الإجابة عن كافة التساؤلات الأكاديمية والمهنية.\n• كتابة المقالات، الرسائل، والمحتوى الإبداعي.\n• شرح الدروس وحل التمارين وتحليل الصور.\n• كتابة وتصحيح الأكواد البرمجية.\n• الترجمة والتدقيق وتلخيص النصوص الطويلة.\n\nكيف يمكنني مساعدتك الآن؟'
              : 'Welcome to Mind AI — Your intelligent mind towards a brighter future.\n\nI am your comprehensive multi-functional AI platform, ready to assist with:\n• Answers to academic and professional questions\n• Writing essays, emails, and creative content\n• Solving homework with photo understanding\n• Software engineering and coding\n• Accurate translation and summarization\n\nHow can I help you today?',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ],
      },
    ];
  });

  const [activeConvId, setActiveConvId] = useState<string>(() => conversations[0]?.id || 'conv-1');
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [thinkingStep, setThinkingStep] = useState(0);
  const [failedMessage, setFailedMessage] = useState<{ text: string; image?: string | null } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const activeConversation = conversations.find((c) => c.id === activeConvId) || conversations[0];

  // Progressive thinking status
  const thinkingMessages = isAr
    ? [
        'تحليل المدخلات والسياق المطلوب...',
        'استحضار المعارف والمصادر المتخصصة...',
        'صياغة الإجابة والتحقق من جودتها وسرعتها...',
      ]
    : [
        'Analyzing query and prompt requirements...',
        'Recalling specialized knowledge bases...',
        'Synthesizing refined and precise output...',
      ];

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('mind_ai_conversations', JSON.stringify(conversations));
    } catch {
      // ignore
    }
  }, [conversations]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeConversation?.messages, isTyping]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isTyping) {
      setThinkingStep(0);
      timer = setInterval(() => {
        setThinkingStep((prev) => (prev < thinkingMessages.length - 1 ? prev + 1 : prev));
      }, 1500);
    }
    return () => clearInterval(timer);
  }, [isTyping]);

  // Image selection with automatic compression
  const handleImagePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const raw = reader.result as string;
        const compressed = await aiService.compressImageForUpload(raw, 1200, 0.85);
        setSelectedImage(compressed);
      } catch {
        setSelectedImage(reader.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // Start a new conversation
  const handleNewChat = () => {
    const newConv: ChatConversation = {
      id: `conv-${Date.now()}`,
      title: isAr ? `محادثة جديدة ${conversations.length + 1}` : `New Chat ${conversations.length + 1}`,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      mode: activeMode,
      messages: [
        {
          id: `msg-${Date.now()}`,
          sender: 'ai',
          text: isAr
            ? `أهلاً بك في جلسة جديدة! اختر النمط المناسب واطرح سؤالك أو ارفع صورة المسألة وسأجيبك فوراً.`
            : `New session started! Pick your preferred mode and ask away, or attach an image.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ],
    };
    setConversations((prev) => [newConv, ...prev]);
    setActiveConvId(newConv.id);
    setInputText('');
    setSelectedImage(null);
    setFailedMessage(null);
  };

  // Delete conversation
  const handleDeleteConv = (convId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (conversations.length <= 1) {
      handleNewChat();
      return;
    }
    const filtered = conversations.filter((c) => c.id !== convId);
    setConversations(filtered);
    if (activeConvId === convId) {
      setActiveConvId(filtered[0]?.id || 'conv-1');
    }
  };

  // Send message
  const handleSend = async (overrideText?: string, overrideImage?: string | null) => {
    const textToSend = (overrideText !== undefined ? overrideText : inputText).trim();
    const imageToSend = overrideImage !== undefined ? overrideImage : selectedImage;

    if ((!textToSend && !imageToSend) || isTyping) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      imagePreview: imageToSend || undefined,
      mode: activeMode,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // Update conversation with user message & auto-generate title if first message
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === activeConvId) {
          const isFirstUserMsg = c.messages.filter((m) => m.sender === 'user').length === 0;
          const updatedTitle = isFirstUserMsg && textToSend ? textToSend.slice(0, 26) + '...' : c.title;
          return {
            ...c,
            title: updatedTitle,
            messages: [...c.messages, userMessage],
          };
        }
        return c;
      })
    );

    setInputText('');
    setSelectedImage(null);
    setFailedMessage(null);
    setIsTyping(true);

    try {
      const res = await aiService.chatWithAi({
        message: textToSend,
        imageBase64: imageToSend,
        mode: activeMode,
        lang,
        history: activeConversation?.messages || [],
      });

      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setConversations((prev) =>
        prev.map((c) => (c.id === activeConvId ? { ...c, messages: [...c.messages, aiMessage] } : c))
      );
    } catch {
      setFailedMessage({ text: textToSend, image: imageToSend });
      const errorMessage: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'ai',
        text: isAr
          ? 'تعذر الوصول المؤقت إلى الخادم. تم الاحتفاظ بسؤالك وصورتك لمنع ضياعهما، يمكنك الضغط على إعادة المحاولة الآن.'
          : 'Temporary network delay. Your prompt and image are saved. Click Retry below.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setConversations((prev) =>
        prev.map((c) => (c.id === activeConvId ? { ...c, messages: [...c.messages, errorMessage] } : c))
      );
    } finally {
      setIsTyping(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto h-[calc(100vh-170px)] min-h-[620px] flex flex-col md:flex-row bg-[#0c0717] rounded-3xl border border-purple-900/40 shadow-2xl overflow-hidden relative backdrop-blur-md">
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImagePick}
        className="hidden"
      />

      {/* Left / Desktop Sessions Sidebar */}
      <div className="w-full md:w-72 bg-[#090412]/95 border-b md:border-b-0 md:border-e border-purple-900/40 p-4 flex flex-col shrink-0">
        <div className="flex items-center justify-between gap-2 mb-3">
          <button
            type="button"
            onClick={handleNewChat}
            className="flex-1 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 hover:from-cyan-400 hover:to-pink-400 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-purple-950/60 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'محادثة جديدة' : 'New Chat'}</span>
          </button>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto space-y-1.5 scrollbar-none pe-1">
          <span className="text-[10px] font-bold text-purple-400/60 uppercase tracking-wider block px-2 mb-1">
            {isAr ? 'سجل المحادثات' : 'Chat History'}
          </span>
          {conversations.map((conv) => {
            const isActive = conv.id === activeConvId;
            return (
              <div
                key={conv.id}
                onClick={() => setActiveConvId(conv.id)}
                className={`flex items-center justify-between p-2.5 rounded-2xl text-xs font-semibold cursor-pointer transition-all group ${
                  isActive
                    ? 'bg-purple-950/80 text-white border border-purple-600/50 shadow-md'
                    : 'text-purple-300/70 hover:bg-purple-950/40 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-cyan-400' : 'text-purple-400/60'}`} />
                  <span className="truncate">{conv.title}</span>
                </div>
                <button
                  type="button"
                  onClick={(e) => handleDeleteConv(conv.id, e)}
                  title={isAr ? 'حذف المحادثة' : 'Delete chat'}
                  className="opacity-0 group-hover:opacity-100 hover:text-red-400 p-1 rounded-lg transition-opacity"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Chat Workspace */}
      <div className="flex-1 flex flex-col bg-[#0e071c] relative min-w-0">
        {/* Top Mode Selector Bar */}
        <div className="px-4 py-2.5 bg-[#120824]/90 border-b border-purple-900/30 flex items-center justify-between gap-3 overflow-x-auto scrollbar-none z-10">
          <div className="flex items-center gap-2">
            <MindLogo size="sm" showText={false} lang={lang} />
            <span className="text-xs font-black text-white hidden sm:inline">Mind AI</span>
          </div>

          <div className="flex items-center gap-1.5">
            {modes.map((m) => {
              const Icon = m.icon;
              const isActive = activeMode === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setActiveMode(m.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                    isActive
                      ? `bg-gradient-to-r ${m.color} text-white shadow-md`
                      : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300/80 border border-purple-900/30'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-gradient-to-b from-[#0e071c] via-[#090412] to-[#05020a]">
          {activeConversation?.messages.map((m) => {
            const isAi = m.sender === 'ai';
            return (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className={`flex ${isAi ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[90%] sm:max-w-[80%] rounded-3xl p-4 sm:p-5 text-xs sm:text-sm shadow-xl leading-relaxed relative group ${
                    isAi
                      ? 'bg-[#150a2b] text-purple-100 border border-purple-800/40 rounded-tl-none rtl:rounded-tr-none rtl:rounded-tl-3xl'
                      : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-600 text-white rounded-tr-none rtl:rounded-tl-none rtl:rounded-tr-3xl shadow-purple-900/30'
                  }`}
                >
                  {/* Sender Header */}
                  <div className="flex items-center justify-between gap-3 mb-2 opacity-75 text-[11px] font-semibold">
                    <div className="flex items-center gap-1.5">
                      {isAi ? (
                        <>
                          <Bot className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Mind AI</span>
                        </>
                      ) : (
                        <>
                          <User className="w-3.5 h-3.5 text-purple-200" />
                          <span>{isAr ? 'أنت' : 'You'}</span>
                        </>
                      )}
                      <span>•</span>
                      <span>{m.timestamp}</span>
                    </div>

                    {isAi && (
                      <button
                        type="button"
                        onClick={() => copyToClipboard(m.text, m.id)}
                        className="opacity-0 group-hover:opacity-100 hover:text-white transition-opacity text-[11px] flex items-center gap-1 cursor-pointer bg-purple-900/50 px-2 py-0.5 rounded-lg"
                      >
                        {copiedId === m.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">{isAr ? 'تم النسخ' : 'Copied'}</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>{isAr ? 'نسخ' : 'Copy'}</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  {/* Attached Image Preview if any */}
                  {m.imagePreview && (
                    <div className="mb-3 rounded-2xl overflow-hidden border border-purple-700/40 max-w-sm max-h-60 bg-black/50">
                      <img src={m.imagePreview} alt="User upload" className="w-full h-full object-contain" />
                    </div>
                  )}

                  {/* Body Text */}
                  <p className="whitespace-pre-line leading-relaxed select-text">{m.text}</p>
                </div>
              </motion.div>
            );
          })}

          {/* Thinking / Waiting Indicator */}
          {isTyping && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="flex justify-start">
              <div className="bg-[#150a2b] border border-cyan-500/30 rounded-2xl p-4 shadow-xl max-w-sm w-full space-y-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center shrink-0">
                    <Sparkles className="w-4 h-4 text-cyan-300 animate-spin" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center text-xs font-bold text-cyan-200 mb-1">
                      <span>{thinkingMessages[thinkingStep]}</span>
                      <span className="text-[10px] font-mono text-cyan-400">
                        {Math.round(((thinkingStep + 1) / thinkingMessages.length) * 100)}%
                      </span>
                    </div>
                    <div className="w-full bg-purple-950 rounded-full h-1.5 overflow-hidden">
                      <motion.div
                        className="bg-gradient-to-r from-cyan-400 to-purple-500 h-full rounded-full"
                        initial={{ width: '20%' }}
                        animate={{ width: `${((thinkingStep + 1) / thinkingMessages.length) * 100}%` }}
                        transition={{ duration: 0.5 }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Failed Message Retry Banner */}
          {failedMessage && (
            <div className="p-3.5 bg-amber-950/40 border border-amber-500/40 rounded-2xl flex items-center justify-between gap-3 text-xs text-amber-200">
              <span>{isAr ? 'تم حفظ سؤالك، يمكنك إعادة المحاولة فوراً:' : 'Query saved. You can retry now:'}</span>
              <button
                type="button"
                onClick={() => handleSend(failedMessage.text, failedMessage.image)}
                className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
              </button>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Image Preview Thumbnail Before Sending */}
        {selectedImage && (
          <div className="px-4 py-2 bg-[#120824] border-t border-purple-900/40 flex items-center gap-3">
            <div className="relative w-16 h-16 rounded-xl overflow-hidden border border-cyan-400/50 bg-black/60 shrink-0">
              <img src={selectedImage} alt="Selected" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => setSelectedImage(null)}
                className="absolute top-1 end-1 bg-black/80 hover:bg-red-600 text-white p-0.5 rounded-full"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <span className="text-xs text-purple-300 font-medium">
              {isAr ? 'تم إرفاق الصورة، سيقوم Mind AI بتحليلها.' : 'Image attached for Mind AI multimodal analysis.'}
            </span>
          </div>
        )}

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 sm:p-4 bg-[#120824]/95 border-t border-purple-900/30 flex items-center gap-2 z-10"
        >
          {/* Camera / Image Upload Button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title={isAr ? 'إرفاق صورة أو تصوير مسألة' : 'Attach image / camera'}
            disabled={isTyping}
            className="p-3 rounded-2xl bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 hover:text-white border border-purple-800/40 transition-colors cursor-pointer shrink-0"
          >
            <Camera className="w-5 h-5 text-cyan-400" />
          </button>

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              isAr
                ? 'اسأل Mind AI في أي موضوع، أو اطلب كتابة، تلخيص، ترجمة، أو برمجة...'
                : 'Ask Mind AI anything, or request writing, coding, translation...'
            }
            disabled={isTyping}
            className="flex-1 bg-[#07030e] border border-purple-900/50 focus:border-cyan-500 rounded-2xl px-4 py-3 text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none focus:ring-1 focus:ring-cyan-500 transition-all disabled:opacity-60"
          />

          <button
            type="submit"
            disabled={(!inputText.trim() && !selectedImage) || isTyping}
            className="px-5 sm:px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 hover:from-cyan-400 hover:to-pink-400 disabled:opacity-40 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-purple-900/50 flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed shrink-0"
          >
            <span className="hidden sm:inline">{isAr ? 'إرسال' : 'Send'}</span>
            <Send className="w-4 h-4 rtl:rotate-180" />
          </button>
        </form>
      </div>
    </div>
  );
};
