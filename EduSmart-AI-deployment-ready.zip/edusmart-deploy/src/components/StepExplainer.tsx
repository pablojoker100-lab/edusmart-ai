import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, RotateCcw, AlertTriangle, CheckCircle2, ChevronRight, Copy, Check } from 'lucide-react';
import { Language, EducationLevel, SolverResponse } from '../types';
import { translations } from '../i18n/translations';
import { aiService } from '../services/aiService';

export const StepExplainer: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang, level }) => {
  const t = translations[lang].explainer;
  const common = translations[lang].common;
  const isAr = lang === 'ar';

  const [discipline, setDiscipline] = useState<'math' | 'physics'>('math');
  const [equationQuery, setEquationQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [solution, setSolution] = useState<SolverResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedFormula, setCopiedFormula] = useState<string | null>(null);

  const presets = {
    math: [
      isAr ? 'حل المعادلة التفاضلية y\' + 2y = 4' : 'Derive derivative of f(x) = x³ · sin(x)',
      isAr ? 'تكامل بالتعويض للدالة ∫ 2x·e^(x²) dx' : 'Solve system: 2x + 3y = 12 and 4x - y = 10',
      isAr ? 'دراسة إشارة ونهايات الدالة f(x) = (x² - 4)/(x - 2)' : 'Factor polynomial: 3x² - 10x + 8 = 0',
      isAr ? 'حساب المتتاليات العددية: Un+1 = 2Un + 3' : 'Limits: lim (x→0) sin(x)/x',
    ],
    physics: [
      isAr ? 'حساب طاقة الوضع وحفظ الطاقة الميكانيكية' : 'Derive v² = u² + 2as under constant acceleration',
      isAr ? 'قانون كولوم والشحنات الكهربائية النقطية' : 'Calculate pressure at 15m depth in water (P = ρgh)',
      isAr ? 'معادلة التناقص الإشعاعي N(t) = N₀ · e^(-λt)' : 'Half-life decay equation N(t) = N₀ · e^(-λt)',
      isAr ? 'قوانين نيوتن وحركة جسم على مستوى مائل' : 'RLC Circuit differential equations',
    ],
  };

  const thinkingStages = isAr
    ? [
        'تحليل المعادلة أو المسألة الرياضية/الفيزيائية...',
        'استحضار القواعد الأكاديمية والمنهجية المعتمدة...',
        'تفكيك خطوات الحل مع الصيغ الحسابية الدقيقة...',
        'التحقق النهائي من الأبعاد الرياضية والوحدات...',
      ]
    : [
        'Analyzing mathematical/physical formulation...',
        'Recalling governing academic principles and formulas...',
        'Deriving step-by-step resolution phases...',
        'Verifying dimensional accuracy and final value...',
      ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isLoading) {
      setLoadingStep(0);
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev < thinkingStages.length - 1 ? prev + 1 : prev));
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  const handleExplain = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!equationQuery.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);
    try {
      const res = await aiService.explainMathPhysics(equationQuery, discipline, level, lang);
      setSolution(res);
    } catch (err: any) {
      setError(err?.message || common.error);
    } finally {
      setIsLoading(false);
    }
  };

  const copyFormulaText = (formula: string) => {
    navigator.clipboard.writeText(formula);
    setCopiedFormula(formula);
    setTimeout(() => setCopiedFormula(null), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Input Card */}
      <div className="bg-[#120b24] rounded-3xl p-5 sm:p-7 shadow-xl border border-purple-900/40 relative overflow-hidden">
        <div className="flex items-start justify-between flex-wrap gap-2 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">📐</span>
              <h2 className="text-xl sm:text-2xl font-bold text-white">{t.title}</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                Turbo Flash ⚡
              </span>
            </div>
            <p className="text-xs sm:text-sm text-purple-300/70 mt-1">{t.subtitle}</p>
          </div>
          <span className="px-3 py-1 bg-purple-950 text-purple-300 border border-purple-800/40 text-xs font-semibold rounded-full">
            {translations[lang].levels[level]}
          </span>
        </div>

        {/* Discipline Selection */}
        <div className="flex gap-2.5 mt-4">
          <button
            type="button"
            onClick={() => setDiscipline('math')}
            className={`px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
              discipline === 'math'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-600/30'
                : 'bg-purple-950/40 text-purple-300 border border-purple-900/30 hover:bg-purple-900/30'
            }`}
          >
            <span>📐</span>
            <span>{t.math}</span>
          </button>
          <button
            type="button"
            onClick={() => setDiscipline('physics')}
            className={`px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
              discipline === 'physics'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-600/30'
                : 'bg-purple-950/40 text-purple-300 border border-purple-900/30 hover:bg-purple-900/30'
            }`}
          >
            <span>⚡</span>
            <span>{t.physics}</span>
          </button>
        </div>

        {/* Preset Pills */}
        <div className="mt-5">
          <p className="text-xs font-semibold text-purple-400 mb-2">{t.sampleFormulas}</p>
          <div className="flex flex-wrap gap-2">
            {presets[discipline].map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setEquationQuery(preset)}
                className="text-xs bg-[#180e33] hover:bg-purple-900/40 text-purple-200 px-3.5 py-1.5 rounded-xl border border-purple-800/30 transition-all text-start cursor-pointer hover:border-purple-500/50"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleExplain} className="mt-5 space-y-4">
          <input
            type="text"
            value={equationQuery}
            onChange={(e) => setEquationQuery(e.target.value)}
            placeholder={t.inputPlaceholder}
            disabled={isLoading}
            className="w-full rounded-2xl bg-[#0d071a] border border-purple-900/50 p-4 text-purple-100 placeholder:text-purple-400/40 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-sm font-medium transition-all"
          />

          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={isLoading || !equationQuery.trim()}
              className="px-7 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:from-purple-950 disabled:to-purple-950 disabled:text-purple-600/50 text-white font-semibold text-sm transition-all shadow-lg shadow-purple-600/30 flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isLoading ? t.explaining : t.explainBtn}</span>
            </button>

            {equationQuery && !isLoading && (
              <button
                type="button"
                onClick={() => {
                  setEquationQuery('');
                  setSolution(null);
                  setError(null);
                }}
                className="px-4 py-3.5 rounded-2xl bg-purple-950/40 hover:bg-purple-900/30 text-purple-300 text-xs font-semibold border border-purple-900/30 cursor-pointer"
              >
                {common.clear}
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Progressive Processing Indicator */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-[#120b24] border border-purple-500/40 rounded-3xl p-6 shadow-2xl relative overflow-hidden"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white">
                    {thinkingStages[loadingStep]}
                  </h4>
                  <span className="text-xs font-mono text-purple-400">
                    {Math.round(((loadingStep + 1) / thinkingStages.length) * 100)}%
                  </span>
                </div>
                <div className="w-full bg-purple-950 rounded-full h-2 mt-2 overflow-hidden">
                  <motion.div
                    className="bg-gradient-to-r from-purple-500 via-indigo-500 to-emerald-400 h-full rounded-full"
                    initial={{ width: '15%' }}
                    animate={{ width: `${((loadingStep + 1) / thinkingStages.length) * 100}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-4 pt-3 border-t border-purple-900/30">
              {thinkingStages.map((stage, idx) => (
                <div
                  key={idx}
                  className={`flex items-center gap-2 text-xs p-2 rounded-xl transition-all ${
                    idx <= loadingStep
                      ? 'bg-purple-950/50 text-purple-200 border border-purple-700/40'
                      : 'text-purple-400/40'
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] shrink-0 font-bold ${
                      idx < loadingStep
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : idx === loadingStep
                        ? 'bg-purple-500 text-white animate-pulse'
                        : 'bg-purple-950 text-purple-600'
                    }`}
                  >
                    {idx < loadingStep ? '✓' : idx + 1}
                  </span>
                  <span className="truncate">{stage}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Error Card with Preserved Input and Retry */}
      {error && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 bg-red-950/40 text-red-200 rounded-3xl border border-red-500/40 flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-red-400 shrink-0" />
            <div>
              <p className="font-semibold text-sm">{error}</p>
              <p className="text-xs text-red-300/70 mt-0.5">
                {isAr ? 'تم الاحتفاظ بنص المعادلة، يمكنك إعادة المحاولة مباشرة دون إعادة الكتابة.' : 'Input preserved. Click retry below.'}
              </p>
            </div>
          </div>
          <button
            onClick={() => handleExplain()}
            className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl flex items-center gap-1.5 shrink-0 transition-colors shadow-lg shadow-red-600/30 cursor-pointer text-xs"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
          </button>
        </motion.div>
      )}

      {/* Solution Presentation */}
      {solution && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#120b24] rounded-3xl p-5 sm:p-7 shadow-2xl border border-purple-900/40 space-y-6"
        >
          <div className="border-b border-purple-900/30 pb-4 flex items-center justify-between flex-wrap gap-2">
            <div>
              <span className="text-xs font-bold px-3 py-1 rounded-full bg-purple-950 text-purple-300 border border-purple-800/40">
                {solution.subject || (discipline === 'physics' ? 'Physics' : 'Mathematics')}
              </span>
              <h3 className="text-xl font-bold text-white mt-2">{solution.problemSummary}</h3>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1 rounded-full">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isAr ? 'مكتمل بالتحليل الدقيق' : 'Completed with derivation'}</span>
            </div>
          </div>

          {/* Sequential Phases */}
          <div className="space-y-4">
            {solution.steps.map((st, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: isAr ? 16 : -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.12 }}
                className="p-5 rounded-2xl border-l-4 rtl:border-l-0 rtl:border-r-4 border-purple-500 bg-[#190f33] border-t border-b border-r rtl:border-r-0 rtl:border-l border-purple-900/30 relative"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-bold text-purple-400 uppercase tracking-wider block">
                    {isAr ? `المرحلة ${i + 1}` : `Phase ${i + 1}`}
                  </span>
                </div>
                <h4 className="font-bold text-white text-sm sm:text-base">{st.title}</h4>
                <p className="text-xs sm:text-sm text-purple-200/90 mt-2 leading-relaxed">{st.detail}</p>
                {st.formula && (
                  <div className="mt-3 p-3 bg-[#0c0719] border border-purple-800/40 rounded-xl font-mono text-xs sm:text-sm text-purple-300 flex items-center justify-between gap-2 overflow-x-auto">
                    <span className="select-all">{st.formula}</span>
                    <button
                      type="button"
                      onClick={() => copyFormulaText(st.formula!)}
                      className="px-2 py-1 rounded-lg bg-purple-950/80 hover:bg-purple-800/50 text-purple-300 text-xs flex items-center gap-1 shrink-0 cursor-pointer"
                    >
                      {copiedFormula === st.formula ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400 text-[10px]">{isAr ? 'تم النسخ' : 'Copied'}</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span className="text-[10px]">{isAr ? 'نسخ' : 'Copy'}</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </motion.div>
            ))}
          </div>

          {/* Final Answer Banner */}
          <div className="p-5 bg-gradient-to-r from-emerald-950/60 via-teal-950/40 to-purple-950/40 rounded-2xl border border-emerald-500/40 shadow-xl">
            <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider block">
              {isAr ? 'الخلاصة والنتيجة النهائية' : 'Final Result & Conclusion'}
            </span>
            <p className="text-lg sm:text-xl font-extrabold text-white mt-1.5 select-all">{solution.finalAnswer}</p>
          </div>

          {/* Key Academic Concept Tip */}
          {solution.conceptTip && (
            <div className="p-4 sm:p-5 bg-amber-950/30 rounded-2xl border border-amber-500/40 text-xs sm:text-sm text-amber-200">
              <div className="flex items-center gap-2 font-bold mb-1 text-amber-300">
                <span>💡</span>
                <span>{translations[lang].solver.takeaway}</span>
              </div>
              <p className="leading-relaxed">{solution.conceptTip}</p>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};
