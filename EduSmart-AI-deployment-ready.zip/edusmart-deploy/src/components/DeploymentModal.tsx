import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Share2, Copy, Check, X, Smartphone, Globe, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { authService, DEPLOYMENT_URL } from '../services/authService';

interface DeploymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const DeploymentModal: React.FC<DeploymentModalProps> = ({ isOpen, onClose, lang }) => {
  const isRtl = lang === 'ar';
  const deploymentUrl = authService.getDeploymentUrl();

  const [copied, setCopied] = useState(false);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(deploymentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShareApp = async () => {
    const title = 'Mind AI - عقلك الذكي نحو مستقبل أفضل';
    const text = isRtl
      ? 'تطبيق Mind AI: عقلك الذكي نحو مستقبل أفضل. حل الواجبات بالذكاء الاصطناعي، شرح الرياضيات والفيزياء، وملخصات الدروس واختبارات تفاعلية لجميع المراحل الدراسية!'
      : 'Mind AI: Your intelligent mind towards a brighter future. Homework solver, math derivations, and quizzes.';

    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text,
          url: deploymentUrl,
        });
        setShareFeedback(isRtl ? 'تمت المشاركة بنجاح!' : 'Shared successfully!');
        setTimeout(() => setShareFeedback(null), 2500);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopyLink();
        }
      }
    } else {
      handleCopyLink();
      setShareFeedback(isRtl ? 'تم نسخ الرابط! يمكنك مشاركته الآن في واتساب أو أي تطبيق.' : 'Link copied to clipboard!');
      setTimeout(() => setShareFeedback(null), 3000);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 12 }}
            className="w-full max-w-lg bg-[#130b24] rounded-3xl p-6 sm:p-8 shadow-2xl border border-purple-800/50 relative overflow-hidden purple-glow"
          >
            {/* Top decorative gradient */}
            <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-purple-500 via-fuchsia-500 to-indigo-500" />

            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 end-4 w-8 h-8 rounded-full bg-purple-950/80 hover:bg-purple-900 text-purple-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-purple-800/40"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-violet-400 text-white flex items-center justify-center text-2xl shadow-lg purple-glow-sm">
                🚀
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  {isRtl ? 'نشر التطبيق ورابط المشاركة العام' : 'Public App Deployment'}
                </h3>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-semibold text-emerald-400">
                    {isRtl ? 'التطبيق متاح أونلاين على السحابة (Cloud Run)' : 'Live on Cloud Run / Production'}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-purple-200/80 leading-relaxed mb-5">
              {isRtl
                ? 'تم تجهيز التطبيق ونشره للعامة بنجاح! يمكنك فتحه ومشاركته مع زملائك والطلاب على جميع هواتف Android والآيفون وأجهزة الكمبيوتر مباشرة.'
                : 'Your application is live and publicly accessible! Share this real URL with students and friends across all mobile and desktop devices.'}
            </p>

            {/* Real Public Deployment URL Box */}
            <div className="p-3.5 bg-black/50 rounded-2xl border border-purple-800/40 mb-4">
              <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1">
                {isRtl ? 'رابط التطبيق الفعلي المباشر (Actual Live URL)' : 'Actual Live Deployment URL'}
              </span>
              <input
                type="text"
                readOnly
                value={deploymentUrl}
                className="w-full bg-black/40 border border-purple-900/50 rounded-xl px-3 py-2 text-xs font-mono text-purple-300 font-semibold select-all focus:outline-none"
              />
            </div>

            {/* Action Buttons: Copy Link & Share App */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <button
                type="button"
                onClick={handleCopyLink}
                className="py-3 px-4 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-purple-200 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border border-purple-700/40 transition-all cursor-pointer shadow-sm"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-purple-300" />}
                <span>{copied ? (isRtl ? 'تم النسخ بنجاح!' : 'Copied!') : (isRtl ? 'نسخ الرابط' : 'Copy Link')}</span>
              </button>

              <button
                type="button"
                onClick={handleShareApp}
                className="py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-purple-900/50 cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>{isRtl ? 'مشاركة التطبيق' : 'Share App'}</span>
              </button>
            </div>

            {/* Feedback notification */}
            {shareFeedback && (
              <div className="p-3 mb-4 bg-emerald-950/70 text-emerald-200 rounded-xl text-xs font-semibold text-center border border-emerald-700/40">
                {shareFeedback}
              </div>
            )}

            {/* Device Support & PWA Instructions */}
            <div className="p-4 bg-black/30 rounded-2xl border border-purple-900/30 text-xs text-purple-200/90 space-y-2">
              <div className="flex items-center gap-2 font-bold text-purple-300">
                <Smartphone className="w-4 h-4 text-purple-400" />
                <span>{isRtl ? 'كيفية التثبيت والاستخدام على الهواتف والكمبيوتر:' : 'Device Access & PWA Installation:'}</span>
              </div>
              <ul className="space-y-1.5 text-purple-300/80 leading-relaxed ps-2">
                <li>
                  <strong className="text-white">Android / Chrome:</strong> {isRtl ? 'افتح الرابط في المتصفح، واضغط على خيارات المتصفح (⋮) ثم "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".' : 'Open in Chrome and tap "Install app" or "Add to Home screen".'}
                </li>
                <li>
                  <strong className="text-white">iPhone / Safari:</strong> {isRtl ? 'اضغط على زر المشاركة ثم اختر "إضافة إلى الصفحة الرئيسية".' : 'Tap Share button and choose "Add to Home Screen".'}
                </li>
                <li>
                  <strong className="text-white">PC / Mac:</strong> {isRtl ? 'يعمل مباشرة في أي متصفح مع حفظ تلقائي للجلسة وسجل الدراسة.' : 'Works smoothly on any browser with local and cloud session sync.'}
                </li>
              </ul>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
