import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, type Variants } from 'motion/react';
import { Sparkles, Camera, Copy, Check, RotateCcw, AlertTriangle, ArrowRight, ArrowLeft, CheckCircle2, Lightbulb, Target } from 'lucide-react';
import { Language, EducationLevel, SolverResponse } from '../types';
import { translations } from '../i18n/translations';
import { aiService } from '../services/aiService';
import { authService } from '../services/authService';

// Animation variants for deliberate, readable staggered presentation
const solutionContainerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.05,
    },
  },
};

const solutionItemVariants: Variants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: [0.22, 1, 0.36, 1],
    },
  },
};

export const HomeworkSolver: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang, level }) => {
  const t = translations[lang].solver;
  const common = translations[lang].common;
  const isAr = lang === 'ar';

  const [inputQuery, setInputQuery] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [result, setResult] = useState<SolverResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isCompressing, setIsCompressing] = useState(false);

  // Progressive Thinking Stages during processing
  const thinkingStages = isAr
    ? [
        'قراءة وتحليل نص المسألة أو الصورة...',
        'استدعاء القواعد والمعادلات الأكاديمية...',
        'تفكيك مراحل الحل والبرهان المنهجي...',
        'المراجعة والتحقق النهائي من صحة النتيجة...',
      ]
    : [
        'Scanning and analyzing homework inquiry...',
        'Recalling governing laws and academic formulas...',
        'Deriving step-by-step resolution...',
        'Verifying dimensional accuracy and final result...',
      ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isLoading) {
      setLoadingStep(0);
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev < thinkingStages.length - 1 ? prev + 1 : prev));
      }, 1600);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  // Fast client-side image compression before upload
  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      setError(isAr ? 'حجم الصورة كبير جداً (الحد الأقصى 15 ميغابايت).' : 'Image size too large (max 15MB).');
      return;
    }

    setIsCompressing(true);
    setError(null);

    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        const rawBase64 = reader.result as string;
        // Instant downscaling for fast mobile network upload
        const compressed = await aiService.compressImageForUpload(rawBase64, 1200, 0.82);
        setImagePreview(compressed);
      } catch {
        setImagePreview(reader.result as string);
      } finally {
        setIsCompressing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSolve = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputQuery.trim() && !imagePreview) return;

    setIsLoading(true);
    setError(null);

    try {
      const data = await aiService.solveHomework(inputQuery, imagePreview, level, lang);
      setResult(data);

      // Persist to user study history in background
      authService
        .recordActivity({
          type: 'solve',
          title: data.problemSummary || (inputQuery.trim() ? inputQuery.slice(0, 50) : (isAr ? 'مسألة واجب مصورة' : 'Solved Homework')),
          subject: data.subject || (isAr ? 'واجب دراسي' : 'Homework'),
          details: { finalAnswer: data.finalAnswer },
        })
        .catch(() => {});
    } catch (err: any) {
      // Preserve inputQuery and imagePreview, never wipe them!
      setError(err?.message || (isAr ? 'تعذر الاتصال بالخادم مؤقتاً. يرجى الضغط على زر إعادة المحاولة.' : 'Network error. Please click retry.'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopySolution = () => {
    if (!result) return;
    const textToCopy = `EduSmart AI Solution (${translations[lang].levels[level]})\n` +
      `Subject: ${result.subject || 'General'}\n` +
      `Problem: ${result.problemSummary}\n\n` +
      result.steps.map((s, i) => `Step ${i + 1}: ${s.title}\n${s.detail}\n${s.formula ? `Formula: ${s.formula}\n` : ''}`).join('\n') +
      `\nFinal Answer: ${result.finalAnswer}\nKey Concept: ${result.conceptTip}`;

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Input Card in Obsidian & Purple */}
      <div className="bg-[#120b24] rounded-3xl p-5 sm:p-7 shadow-2xl border border-purple-800/40 relative overflow-hidden">
        <div className="absolute top-0 end-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex items-start justify-between flex-wrap gap-2 mb-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-violet-500 flex items-center justify-center text-white shadow-md">
                <Camera className="w-5 h-5" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">{t.title}</h2>
            </div>
            <p className="text-xs sm:text-sm text-purple-200/80 mt-1">{t.subtitle}</p>
          </div>
          <span className="px-3 py-1 bg-purple-950/80 border border-purple-600/40 text-purple-300 text-xs font-bold rounded-full">
            {translations[lang].levels[level]}
          </span>
        </div>

        {/* Quick Sample Questions */}
        <div className="relative z-10 mb-4">
          <p className="text-xs font-semibold text-purple-300/70 mb-2">{t.sampleProblems}</p>
          <div className="flex flex-wrap gap-1.5">
            {[t.sample1, t.sample2, t.sample3].map((sample, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setInputQuery(sample)}
                className="text-xs bg-black/40 hover:bg-purple-900/40 text-purple-200 hover:text-white px-3 py-1.5 rounded-xl border border-purple-900/40 transition-colors text-start cursor-pointer"
              >
                💡 {sample}
              </button>
            ))}
          </div>
        </div>

        {/* Problem Input Form */}
        <form onSubmit={handleSolve} className="relative z-10 space-y-4">
          <div>
            <textarea
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder={t.inputPlaceholder}
              rows={3}
              className="w-full rounded-2xl bg-[#1b1035] border border-purple-800/40 p-4 text-white placeholder:text-purple-400/50 focus:outline-none focus:ring-2 focus:ring-purple-500 text-xs sm:text-sm leading-relaxed resize-none"
            />
          </div>

          {/* Multimodal Photo Input with Instant Compression */}
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <label className="flex-1 w-full border-2 border-dashed border-purple-800/50 hover:border-purple-500 hover:bg-purple-950/20 rounded-2xl p-4 flex flex-col items-center justify-center cursor-pointer transition-all">
              <Camera className="w-7 h-7 text-purple-400 mb-1" />
              <span className="text-xs sm:text-sm text-white font-bold">{t.uploadPrompt}</span>
              <span className="text-[11px] text-purple-300/60 mt-0.5">
                {isCompressing ? (isAr ? 'جاري ضغط الصورة لسرعة الرفع...' : 'Optimizing image for fast upload...') : 'PNG, JPG, WEBP (ضغط تلقائي للسرعة)'}
              </span>
              <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
            </label>

            {imagePreview && (
              <div className="relative w-28 h-28 rounded-2xl overflow-hidden border-2 border-purple-500 shadow-xl flex-shrink-0 group">
                <img src={imagePreview} alt="Homework thumbnail" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => setImagePreview(null)}
                  className="absolute top-1.5 end-1.5 bg-red-600 hover:bg-red-700 text-white rounded-full p-1 text-xs shadow-md cursor-pointer"
                  aria-label="Remove image"
                >
                  ✕
                </button>
                <div className="absolute bottom-0 inset-x-0 bg-black/75 text-purple-200 text-[10px] text-center py-0.5 font-bold">
                  {t.photoAttached}
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="submit"
              disabled={isLoading || (!inputQuery.trim() && !imagePreview)}
              className="flex-1 sm:flex-initial px-8 py-3 rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-40 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-purple-900/50 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <span className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                  <span>{t.solvingBtn}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{t.solveBtn}</span>
                </>
              )}
            </button>

            {(inputQuery || imagePreview) && (
              <button
                type="button"
                onClick={() => {
                  setInputQuery('');
                  setImagePreview(null);
                  setResult(null);
                  setError(null);
                }}
                className="px-4 py-3 rounded-2xl bg-purple-950/60 hover:bg-purple-900 text-purple-300 text-xs font-semibold transition-colors cursor-pointer"
              >
                {t.clearAll}
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Multi-stage Thinking & Progress Indicator */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="p-6 rounded-3xl bg-[#130b26] border border-purple-600/50 shadow-2xl purple-glow space-y-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="w-3 h-3 rounded-full bg-purple-400 animate-ping" />
                <h4 className="text-sm font-black text-white">
                  {isAr ? 'الذكاء الاصطناعي يقوم بحل المسألة الآن...' : 'AI Pedagogical Engine is Thinking...'}
                </h4>
              </div>
              <span className="text-xs text-purple-300 font-mono">
                {Math.round(((loadingStep + 1) / thinkingStages.length) * 100)}%
              </span>
            </div>

            {/* Smooth Progress Bar */}
            <div className="w-full h-2 bg-purple-950 rounded-full overflow-hidden border border-purple-800/40 p-0.5">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-purple-500 via-fuchsia-400 to-emerald-400"
                animate={{ width: `${((loadingStep + 1) / thinkingStages.length) * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>

            {/* Stage Steps List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-xs">
              {thinkingStages.map((stage, idx) => {
                const isPassed = idx <= loadingStep;
                const isCurrent = idx === loadingStep;
                return (
                  <div
                    key={idx}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border transition-all ${
                      isCurrent
                        ? 'bg-purple-900/50 border-purple-400 text-white font-bold'
                        : isPassed
                        ? 'bg-black/30 border-purple-900/30 text-purple-300/80'
                        : 'bg-black/20 border-transparent text-purple-400/40'
                    }`}
                  >
                    <span className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] bg-purple-950 font-bold border border-purple-700/40">
                      {isPassed ? '✓' : idx + 1}
                    </span>
                    <span className="truncate">{stage}</span>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Connection Error Banner with Instant Retry (Preserves Question) */}
      {error && !isLoading && (
        <div className="p-4 sm:p-5 bg-red-950/70 text-red-200 rounded-3xl border border-red-700/60 shadow-xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div className="text-xs sm:text-sm">
              <strong className="block text-red-100 font-bold">{isAr ? 'تنبيه الاتصال' : 'Connection Notice'}</strong>
              <span>{error}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              type="button"
              onClick={() => handleSolve()}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-colors cursor-pointer shadow-md"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isAr ? 'إعادة المحاولة الآن' : 'Retry Now'}</span>
            </button>
            <button
              type="button"
              onClick={() => setError(null)}
              className="p-2 text-red-400 hover:text-white rounded-xl hover:bg-red-900/40 transition-colors"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Solution Presentation in Obsidian & Purple */}
      {result && !isLoading && (
        <motion.div
          key={result.problemSummary + result.finalAnswer}
          initial="hidden"
          animate="visible"
          variants={solutionContainerVariants}
          className="bg-[#120b24] rounded-3xl p-5 sm:p-8 shadow-2xl border border-purple-700/50 space-y-6"
        >
          {/* Header */}
          <motion.div
            variants={solutionItemVariants}
            className="border-b border-purple-900/40 pb-4 flex flex-wrap items-center justify-between gap-3"
          >
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                {result.subject && (
                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-purple-900/60 text-purple-200 border border-purple-500/40">
                    📚 {result.subject}
                  </span>
                )}
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-black/40 text-purple-300 border border-purple-800/40">
                  {translations[lang].levels[level]}
                </span>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-600/40 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  {isAr ? 'حل دقيق ومفصل' : 'Verified Solution'}
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white mt-2">{t.resultTitle}</h3>
            </div>

            <button
              type="button"
              onClick={handleCopySolution}
              className="px-4 py-2 rounded-xl bg-purple-950 hover:bg-purple-900 border border-purple-700/40 text-purple-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? common.copySuccess : common.copy}</span>
            </button>
          </motion.div>

          {/* Problem Formulation */}
          <motion.div
            variants={solutionItemVariants}
            className="bg-black/40 rounded-2xl p-4 border border-purple-900/40"
          >
            <span className="text-[11px] font-bold text-purple-400 uppercase tracking-wide block mb-1">
              {isAr ? 'ملخص وتحليل المسألة' : 'Problem Formulation'}
            </span>
            <p className="text-xs sm:text-sm font-medium text-purple-100/90 italic">
              "{result.problemSummary}"
            </p>
          </motion.div>

          {/* Staggered Sequential Solution Steps without interruption */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider px-1">
              {isAr ? 'خطوات الحل المنهجي المفصل:' : 'Step-by-Step Pedagogical Derivation:'}
            </h4>

            {result.steps.map((step, idx) => (
              <motion.div
                key={idx}
                variants={solutionItemVariants}
                whileHover={{ y: -2, transition: { duration: 0.2 } }}
                className="p-5 rounded-3xl bg-[#140c28] border border-purple-800/40 shadow-lg relative overflow-hidden transition-colors hover:border-purple-500/50"
              >
                <div className="flex items-start gap-3.5">
                  <span className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-purple-600 to-violet-500 text-white text-xs font-black flex items-center justify-center flex-shrink-0 shadow-md">
                    {idx + 1}
                  </span>
                  <div className="flex-1 space-y-1.5">
                    <h5 className="font-bold text-white text-sm sm:text-base">{step.title}</h5>
                    <p className="text-xs sm:text-sm text-purple-200/90 leading-relaxed whitespace-pre-line">
                      {step.detail}
                    </p>
                    {step.formula && (
                      <div className="mt-3 p-3.5 bg-black/50 rounded-xl font-mono text-xs sm:text-sm text-purple-300 border border-purple-700/40 overflow-x-auto shadow-inner">
                        {step.formula}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Final Answer Banner */}
          <motion.div
            variants={solutionItemVariants}
            className="p-6 bg-gradient-to-r from-emerald-950/70 via-[#10241e] to-[#0b1c18] rounded-3xl border border-emerald-500/60 shadow-xl"
          >
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-emerald-400" />
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">{t.finalAnswer}</span>
            </div>
            <p className="text-xl sm:text-2xl font-black text-white mt-2 leading-snug">
              {result.finalAnswer}
            </p>
          </motion.div>

          {/* Concept Takeaway / Exam Tip */}
          <motion.div
            variants={solutionItemVariants}
            className="p-5 bg-gradient-to-r from-purple-950/80 to-[#1b0f33] rounded-3xl border border-purple-600/40 text-purple-100 text-xs sm:text-sm shadow-lg space-y-1.5"
          >
            <div className="flex items-center gap-2 font-bold text-amber-300">
              <Lightbulb className="w-4 h-4 text-amber-400" />
              <span>{t.takeaway}</span>
            </div>
            <p className="leading-relaxed text-purple-200/90">{result.conceptTip}</p>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};
