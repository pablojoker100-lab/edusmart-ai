import React, { useEffect, useState } from 'react';
import { Share2, User, ChevronDown, LogOut, Download, Menu } from 'lucide-react';
import { Language, EducationLevel, UserProfile } from '../types';
import { translations } from '../i18n/translations';
import { aiService } from '../services/aiService';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { MindLogo } from './MindLogo';

interface HeaderProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  currentLevel: EducationLevel;
  onLevelChange: (level: EducationLevel) => void;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onNavigateHome: () => void;
  onOpenDeployment?: () => void;
  onToggleMobileSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLang,
  onLanguageChange,
  currentLevel,
  onLevelChange,
  currentUser,
  onOpenAuth,
  onLogout,
  onNavigateHome,
  onOpenDeployment,
  onToggleMobileSidebar,
}) => {
  const t = translations[currentLang];
  const [backendConfigured, setBackendConfigured] = useState<boolean | null>(null);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const { isInstallable, install } = usePWAInstall();

  useEffect(() => {
    aiService.checkHealth().then((res) => {
      setBackendConfigured(res.geminiConfigured);
    });
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-[#0a0714]/95 backdrop-blur-md border-b border-purple-900/40 px-3.5 py-2.5 sm:px-6 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand & Mobile Hamburger Zone */}
        <div className="flex items-center gap-2 sm:gap-3">
          {onToggleMobileSidebar && (
            <button
              type="button"
              onClick={onToggleMobileSidebar}
              className="lg:hidden p-2 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 hover:text-white border border-purple-800/40 cursor-pointer"
              title="القائمة الجانبية"
            >
              <Menu className="w-5 h-5 text-cyan-400" />
            </button>
          )}

          <div
            onClick={onNavigateHome}
            className="flex items-center gap-2.5 cursor-pointer hover:opacity-95 transition-opacity"
          >
            <MindLogo size="md" showText={false} lang={currentLang} />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black tracking-tight text-white leading-none">
                  Mind <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">AI</span>
                </h1>
              {backendConfigured !== null && (
                <span
                  title={backendConfigured ? 'Gemini AI Backend Connected' : 'Local Educational Fallback Active'}
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                    backendConfigured
                      ? 'bg-purple-950/70 text-purple-300 border border-purple-700/50'
                      : 'bg-amber-950/70 text-amber-300 border border-amber-700/50'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${backendConfigured ? 'bg-cyan-400 animate-pulse' : 'bg-amber-400'}`} />
                  <span className="hidden sm:inline">{backendConfigured ? 'Gemini 3.8' : 'Ready'}</span>
                </span>
              )}
            </div>
            <p className="text-[11px] text-purple-300/80 font-medium hidden sm:block truncate max-w-xs mt-0.5">
              {t.tagline}
            </p>
          </div>
        </div>
        </div>

        {/* Controls: Level, Language & Auth */}
        <div className="flex items-center gap-2">
          {/* Level Switcher */}
          <div className="relative">
            <select
              value={currentLevel}
              onChange={(e) => onLevelChange(e.target.value as EducationLevel)}
              className="appearance-none bg-[#140b27] hover:bg-[#1b0f33] text-purple-200 text-xs sm:text-sm font-semibold py-1.5 px-3 pe-7 rounded-xl border border-purple-800/40 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all cursor-pointer shadow-sm"
              aria-label="Education Level"
            >
              <option value="primary">🎒 {t.levels.primary}</option>
              <option value="middle">📐 {t.levels.middle}</option>
              <option value="high">🎓 {t.levels.high}</option>
              <option value="university">🏛️ {t.levels.university}</option>
            </select>
            <span className="pointer-events-none absolute inset-y-0 end-2 flex items-center text-purple-400 text-[10px]">
              ▼
            </span>
          </div>

          {/* Language Switcher */}
          <div className="flex items-center bg-[#140b27] rounded-xl p-0.5 border border-purple-800/40 shadow-sm">
            {(['en', 'fr', 'ar'] as Language[]).map((lng) => {
              const labels: Record<Language, string> = { en: 'EN', fr: 'FR', ar: 'عربي' };
              return (
                <button
                  key={lng}
                  onClick={() => onLanguageChange(lng)}
                  className={`px-2 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    currentLang === lng
                      ? 'bg-purple-600 text-white shadow-md'
                      : 'text-purple-300/70 hover:text-white'
                  }`}
                  aria-label={`Switch to ${lng.toUpperCase()}`}
                >
                  {labels[lng]}
                </button>
              );
            })}
          </div>

          {/* Share App / Deployment Button */}
          {onOpenDeployment && (
            <button
              type="button"
              onClick={onOpenDeployment}
              title={currentLang === 'ar' ? 'رابط النشر ومشاركة التطبيق' : 'Share App & Live Deployment URL'}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-purple-900/40 hover:bg-purple-800/60 text-purple-200 border border-purple-700/40 text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden md:inline">{currentLang === 'ar' ? 'مشاركة' : 'Share'}</span>
            </button>
          )}

          {/* Quick PWA Install Button */}
          {isInstallable && (
            <button
              type="button"
              onClick={() => install()}
              title={currentLang === 'ar' ? 'تثبيت تطبيق Mind AI على جهازك' : 'Install Mind AI as App'}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-xs font-black rounded-xl transition-all shadow-md shadow-purple-900/40 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{currentLang === 'ar' ? 'تثبيت التطبيق' : 'Install App'}</span>
            </button>
          )}

          {/* User Account / Login Button */}
          {currentUser ? (
            <div className="relative">
              <button
                type="button"
                onClick={() => setProfileMenuOpen(!profileMenuOpen)}
                className="flex items-center gap-2 px-2.5 py-1 bg-purple-950/60 hover:bg-purple-900/70 border border-purple-700/40 rounded-xl transition-all cursor-pointer shadow-sm"
              >
                <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-purple-600 to-violet-400 text-white flex items-center justify-center text-xs font-black shadow-xs">
                  {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : '👤'}
                </div>
                <span className="text-xs font-bold text-purple-200 hidden sm:inline max-w-[80px] truncate">
                  {currentUser.name.split(' ')[0]}
                </span>
                <ChevronDown className="w-3 h-3 text-purple-400" />
              </button>

              {/* Profile Dropdown */}
              {profileMenuOpen && (
                <div
                  className="absolute end-0 mt-2 w-56 bg-[#130b24] rounded-2xl shadow-2xl border border-purple-800/50 p-3 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onClick={() => setProfileMenuOpen(false)}
                >
                  <div className="border-b border-purple-900/40 pb-2.5 mb-2">
                    <p className="font-bold text-xs text-white truncate">{currentUser.name}</p>
                    <p className="text-[11px] text-purple-300/60 truncate">{currentUser.email}</p>
                    <span className="inline-block mt-1 text-[10px] font-semibold px-2 py-0.5 bg-purple-900/40 text-purple-300 rounded-md border border-purple-700/30">
                      {t.levels[currentUser.level as EducationLevel] || currentUser.level}
                    </span>
                  </div>

                  <button
                    onClick={onOpenAuth}
                    className="w-full text-start px-2.5 py-1.5 text-xs text-purple-200 hover:bg-purple-900/40 hover:text-white rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <User className="w-3.5 h-3.5 text-purple-400" />
                    <span>{t.nav.profile}</span>
                  </button>

                  <button
                    onClick={onLogout}
                    className="w-full text-start px-2.5 py-1.5 text-xs text-red-400 hover:bg-red-950/50 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-2 mt-1"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>{t.auth.logoutBtn}</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-purple-900/40 cursor-pointer"
            >
              <User className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t.auth.loginBtn}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
