import React from 'react';
import {
  LayoutDashboard,
  MessageSquare,
  GraduationCap,
  Camera,
  Code2,
  Lightbulb,
  FileText,
  Mail,
  User,
  Settings,
  Sparkles
} from 'lucide-react';
import { ActiveTab, Language } from '../types';
import { translations } from '../i18n/translations';

interface NavigationProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  lang: Language;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange, lang }) => {
  const t = translations[lang].nav;
  const isAr = lang === 'ar';

  // Desktop quick pill bar
  const desktopTabs: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'dashboard', label: t.dashboard, icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'chat', label: t.chat, icon: <MessageSquare className="w-4 h-4 text-cyan-400" />, badge: 'AI' },
    { id: 'code', label: t.code, icon: <Code2 className="w-4 h-4 text-blue-400" /> },
    { id: 'solver', label: t.solver, icon: <Camera className="w-4 h-4 text-purple-400" /> },
    { id: 'ideas', label: t.ideas, icon: <Lightbulb className="w-4 h-4 text-amber-400" /> },
    { id: 'content', label: t.content, icon: <FileText className="w-4 h-4 text-pink-400" /> },
    { id: 'letters', label: t.letters, icon: <Mail className="w-4 h-4 text-indigo-400" /> },
    { id: 'lessons', label: t.lessons, icon: <GraduationCap className="w-4 h-4 text-emerald-400" /> },
  ];

  // Mobile Bottom Bar (Focused, highly responsive)
  const mobileTabs: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: t.dashboard, icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'chat', label: isAr ? 'المحادثة' : 'Chat', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'solver', label: isAr ? 'حل بالصور' : 'Solver', icon: <Camera className="w-5 h-5" /> },
    { id: 'code', label: isAr ? 'البرمجة' : 'Code', icon: <Code2 className="w-5 h-5" /> },
    { id: 'lessons', label: t.lessons, icon: <GraduationCap className="w-5 h-5" /> },
    { id: 'profile', label: t.profile, icon: <User className="w-5 h-5" /> },
  ];

  return (
    <>
      {/* Desktop Quick Header Navigation Bar */}
      <nav className="hidden md:block bg-[#0a0515]/90 border-b border-purple-900/30 sticky top-[57px] z-20 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 flex items-center space-x-1.5 rtl:space-x-reverse overflow-x-auto py-2 scrollbar-none">
          {desktopTabs.map((tab) => {
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 text-white shadow-md shadow-purple-900/40'
                    : 'text-purple-200/80 hover:bg-purple-950/60 hover:text-white'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="px-1.5 py-0.2 rounded-md bg-white/20 text-white text-[9px] font-black">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Mobile Bottom Bar (Touch-Optimized for Android & PWA) */}
      <nav
        className="md:hidden fixed bottom-0 inset-x-0 bg-[#07030e]/95 backdrop-blur-xl border-t border-purple-900/40 z-40 px-1 py-1.5 shadow-[0_-4px_25px_rgba(0,0,0,0.7)] safe-area-bottom"
        aria-label="Mobile Bottom Navigation"
      >
        <div className="flex items-center justify-around max-w-md mx-auto">
          {mobileTabs.map((tab) => {
            const isActive =
              activeTab === tab.id ||
              (tab.id === 'profile' && activeTab === 'auth') ||
              (tab.id === 'chat' && (activeTab === 'ideas' || activeTab === 'content' || activeTab === 'letters'));

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex flex-col items-center justify-center py-1 px-1 flex-1 min-w-0 rounded-xl transition-all cursor-pointer ${
                  isActive
                    ? 'text-cyan-400 font-bold scale-105'
                    : 'text-purple-300/60 hover:text-purple-200'
                }`}
              >
                <span className="p-0.5">
                  {tab.icon}
                </span>
                <span className="text-[10px] leading-tight truncate max-w-[50px] block font-semibold mt-0.5">
                  {tab.label}
                </span>
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 mt-0.5 shadow-sm shadow-cyan-400" />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
