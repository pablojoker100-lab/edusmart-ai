import React, { useState } from 'react';
import { Language, EducationLevel, SummaryResponse } from '../types';
import { translations } from '../i18n/translations';
import { aiService } from '../services/aiService';
import { authService } from '../services/authService';

export const LessonSummarizer: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang, level }) => {
  const t = translations[lang].summarizer;
  const common = translations[lang].common;

  const [lessonText, setLessonText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [summary, setSummary] = useState<SummaryResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const sampleTexts = {
    ar: `التمثيل الضوئي (البناء الضوئي) هو العملية الحيوية التي تقوم بها النباتات الخضراء وبعض الكائنات الحية الأخرى لتحويل الطاقة الضوئية الممتصة من الشمس إلى طاقة كيميائية تُخزن في روابط جزيئات الجلوكوز. تتم هذه العملية داخل البلاستيدات الخضراء بوجود صبغة الكلوروفيل، وتتطلب وجود الماء وثاني أكسيد الكربون، وينتج عنها سكر الجلوكوز كغذاء وغاز الأكسجين كناتج ثانوي ضروري لتنفس الكائنات الحية. تنقسم العملية إلى تفاعلات ضوئية تحدث في الثايلاكويد وتفاعلات لا ضوئية (حلقة كالفن) في الستروما.`,
    fr: `La mitose est un processus de division cellulaire non sexuée qui permet d'obtenir deux cellules filles génétiquement identiques à partir d'une cellule mère diploïde. Elle se déroule en quatre phases successives : la prophase (condensation de la chromatine en chromosomes à deux chromatides et disparition de l'enveloppe nucléaire), la métaphase (alignement des chromosomes sur la plaque équatoriale), l'anaphase (séparation des chromatides sœurs vers les pôles opposés par raccourcissement des fuseaux mitotiques) et la télophase (décondensation des chromosomes et formation de deux nouveaux noyaux, suivie de la cytokinèse).`,
    en: `Photosynthesis is the fundamental biological process by which green plants, algae, and cyanobacteria convert radiant light energy into stable chemical energy stored in glucose molecules. Taking place within specialized chloroplasts containing chlorophyll pigments, this biochemical pathway absorbs atmospheric carbon dioxide and water from soil, releasing vital molecular oxygen as an essential byproduct. The reaction occurs in two coordinated stages: the light-dependent reactions within thylakoid membranes generating ATP and NADPH, followed by the light-independent Calvin cycle within the stroma synthesizing carbohydrates.`,
  };

  const handleSummarize = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!lessonText.trim()) return;

    setIsLoading(true);
    setError(null);
    try {
      const data = await aiService.summarizeLesson(lessonText, level, lang);
      setSummary(data);
      authService
        .recordActivity({
          type: 'summary',
          title: data.title || (lang === 'ar' ? 'ملخص درس أكاديمي' : 'Lesson Revision Sheet'),
          subject: (lang === 'ar' ? 'ملخص درس' : 'Lesson Summary'),
          details: { quickRecap: data.quickRecap },
        })
        .catch(() => {});
    } catch (err: any) {
      setError(err?.message || common.error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-sm border border-slate-200">
        <div className="flex items-start justify-between flex-wrap gap-2 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">📑</span>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">{t.title}</h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">{t.subtitle}</p>
          </div>
          <span className="px-3 py-1 bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold rounded-full">
            {translations[lang].levels[level]}
          </span>
        </div>

        <div className="mb-3">
          <button
            type="button"
            onClick={() => setLessonText(sampleTexts[lang])}
            className="text-xs font-medium text-indigo-600 hover:text-indigo-800 bg-indigo-50/70 hover:bg-indigo-100/70 px-3 py-1.5 rounded-lg border border-indigo-200 transition-colors"
          >
            📋 {t.loadSample}
          </button>
        </div>

        <form onSubmit={handleSummarize} className="space-y-4">
          <textarea
            value={lessonText}
            onChange={(e) => setLessonText(e.target.value)}
            placeholder={t.inputPlaceholder}
            rows={5}
            className="w-full rounded-2xl border border-slate-300 p-3.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed"
          />

          <div className="flex gap-2">
            <button
              type="submit"
              disabled={isLoading || !lessonText.trim()}
              className="px-7 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-semibold text-xs sm:text-sm transition-all shadow-md shadow-indigo-100 flex items-center gap-2 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  <span>{common.loading}</span>
                </>
              ) : (
                <span>{t.summarizeBtn}</span>
              )}
            </button>

            {lessonText && (
              <button
                type="button"
                onClick={() => {
                  setLessonText('');
                  setSummary(null);
                }}
                className="px-4 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold"
              >
                {common.clear}
              </button>
            )}
          </div>
        </form>
      </div>

      {error && <div className="p-4 bg-red-50 text-red-700 rounded-2xl text-sm border border-red-200">{error}</div>}

      {summary && (
        <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-sm border border-slate-200 space-y-6">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <h3 className="text-lg sm:text-xl font-bold text-slate-900">
              📌 {summary.title}
            </h3>
            <span className="text-xs bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full font-semibold border border-indigo-200">
              {translations[lang].levels[level]}
            </span>
          </div>

          {/* Key Takeaways */}
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-indigo-700 uppercase tracking-wider mb-3">
              🎯 {t.keyPoints}
            </h4>
            <div className="space-y-2.5">
              {summary.keyPoints.map((point, idx) => (
                <div key={idx} className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                  <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[11px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="text-xs sm:text-sm text-slate-800 leading-relaxed">{point}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Vocabulary & Formulas */}
          {summary.importantTerms && summary.importantTerms.length > 0 && (
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-indigo-700 uppercase tracking-wider mb-3">
                📖 {t.vocabulary}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {summary.importantTerms.map((term, i) => (
                  <div key={i} className="p-3.5 bg-slate-50/90 rounded-2xl border border-slate-200">
                    <span className="font-bold text-xs sm:text-sm text-indigo-900 block mb-1">
                      {term.term}
                    </span>
                    <p className="text-xs text-slate-600 leading-relaxed">{term.definition}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 60s Recap */}
          <div className="p-4 sm:p-5 bg-gradient-to-r from-indigo-50 via-blue-50 to-cyan-50 rounded-2xl border border-indigo-200 text-xs sm:text-sm text-indigo-950">
            <strong className="block text-indigo-900 font-bold mb-1">
              ⚡ {t.quickRecap}:
            </strong>
            <p className="leading-relaxed">{summary.quickRecap}</p>
          </div>
        </div>
      )}
    </div>
  );
};
