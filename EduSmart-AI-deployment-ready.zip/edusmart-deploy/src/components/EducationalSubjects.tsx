import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Calculator, Atom, Dna, Languages, Compass, Cpu, Sparkles, ArrowRight, CheckCircle2, ChevronRight } from 'lucide-react';
import { Language, EducationLevel, ActiveTab, SubjectItem } from '../types';
import { translations } from '../i18n/translations';

interface EducationalSubjectsProps {
  lang: Language;
  level: EducationLevel;
  onNavigate: (tab: ActiveTab) => void;
}

export const EducationalSubjects: React.FC<EducationalSubjectsProps> = ({
  lang,
  level,
  onNavigate,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const subjectsList: SubjectItem[] = [
    {
      id: 'math',
      name: t.subjects.math,
      category: 'exact',
      icon: 'calculator',
      description: t.subjects.mathDesc,
      topicsCount: 14,
      gradient: 'from-purple-900/40 via-violet-950/60 to-black',
      topics: isRtl
        ? ['التفاضل والتكامل', 'الجبر الخطي', 'حساب المثلثات', 'الهندسة التحليلية', 'الاحتمالات والإحصاء']
        : ['Calculus', 'Linear Algebra', 'Trigonometry', 'Analytical Geometry', 'Probability'],
    },
    {
      id: 'physics',
      name: t.subjects.physics,
      category: 'exact',
      icon: 'atom',
      description: t.subjects.physicsDesc,
      topicsCount: 12,
      gradient: 'from-indigo-950/40 via-purple-950/60 to-black',
      topics: isRtl
        ? ['الميكانيكا الحركية', 'قوانين نيوتن', 'الكهرباء والمغناطيسية', 'البصريات', 'التفاعلات الكيميائية']
        : ['Kinematics', "Newton's Laws", 'Electromagnetism', 'Optics', 'Chemical Reactions'],
    },
    {
      id: 'biology',
      name: t.subjects.biology,
      category: 'natural',
      icon: 'dna',
      description: t.subjects.biologyDesc,
      topicsCount: 10,
      gradient: 'from-emerald-950/40 via-purple-950/50 to-black',
      topics: isRtl
        ? ['البيولوجيا الخلوية', 'التمثيل الضوئي', 'علم الوراثة والـ DNA', 'وظائف الأعضاء', 'البيئة والجيولوجيا']
        : ['Cellular Biology', 'Photosynthesis', 'Genetics & DNA', 'Human Physiology', 'Ecology'],
    },
    {
      id: 'arabic',
      name: t.subjects.arabic,
      category: 'languages',
      icon: 'languages',
      description: t.subjects.arabicDesc,
      topicsCount: 9,
      gradient: 'from-amber-950/40 via-purple-950/50 to-black',
      topics: isRtl
        ? ['قواعد النحو والإعراب', 'علم البلاغة والبيان', 'علم العروض', 'تحليل النصوص الأدبية', 'التعبير الإنشائي']
        : ['Arabic Syntax', 'Rhetoric & Metaphor', 'Prosody & Metre', 'Literary Analysis', 'Composition'],
    },
    {
      id: 'foreign_languages',
      name: t.subjects.languagesSubject,
      category: 'languages',
      icon: 'languages',
      description: t.subjects.languagesDesc,
      topicsCount: 11,
      gradient: 'from-rose-950/40 via-purple-950/50 to-black',
      topics: isRtl
        ? ['القواعد النحوية المتقدمة', 'المصطلحات الأكاديمية', 'كتابة المقال', 'الترجمة الاحترافية', 'الفهم القرائي']
        : ['Advanced Grammar', 'Academic Vocabulary', 'Essay Writing', 'Translation', 'Reading Comprehension'],
    },
    {
      id: 'humanities',
      name: t.subjects.humanitiesSubject,
      category: 'humanities',
      icon: 'compass',
      description: t.subjects.humanitiesDesc,
      topicsCount: 8,
      gradient: 'from-cyan-950/40 via-purple-950/50 to-black',
      topics: isRtl
        ? ['فلسفة المعرفة والأخلاق', 'المنطق الفلسفي', 'التاريخ المعاصر', 'الجغرافيا الاقتصادية', 'الفكر النقدي']
        : ['Epistemology', 'Philosophical Logic', 'Modern History', 'Economic Geography', 'Critical Thinking'],
    },
    {
      id: 'computer_science',
      name: t.subjects.cs,
      category: 'tech',
      icon: 'cpu',
      description: t.subjects.csDesc,
      topicsCount: 13,
      gradient: 'from-fuchsia-950/40 via-purple-950/60 to-black',
      topics: isRtl
        ? ['الخوارزميات وهياكل البيانات', 'لغة البرمجة بايثون', 'البوابات المنطقية', 'الذكاء الاصطناعي', 'قواعد البيانات']
        : ['Algorithms & Data Structures', 'Python Programming', 'Logic Gates', 'AI & Machine Learning', 'Databases'],
    },
  ];

  const categories = [
    { id: 'all', label: t.subjects.all },
    { id: 'exact', label: t.subjects.exact },
    { id: 'natural', label: t.subjects.natural },
    { id: 'languages', label: t.subjects.languages },
    { id: 'humanities', label: t.subjects.humanities },
    { id: 'tech', label: t.subjects.tech },
  ];

  const filteredSubjects = selectedCategory === 'all'
    ? subjectsList
    : subjectsList.filter((s) => s.category === selectedCategory);

  const getSubjectIcon = (iconName: string) => {
    switch (iconName) {
      case 'calculator':
        return <Calculator className="w-6 h-6 text-purple-300" />;
      case 'atom':
        return <Atom className="w-6 h-6 text-violet-300" />;
      case 'dna':
        return <Dna className="w-6 h-6 text-fuchsia-300" />;
      case 'languages':
        return <Languages className="w-6 h-6 text-amber-300" />;
      case 'compass':
        return <Compass className="w-6 h-6 text-cyan-300" />;
      case 'cpu':
        return <Cpu className="w-6 h-6 text-pink-300" />;
      default:
        return <BookOpen className="w-6 h-6 text-purple-300" />;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#130b24] to-[#0a0714] border border-purple-900/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 end-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -start-10 w-60 h-60 bg-violet-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/40 border border-purple-500/30 text-purple-300 text-xs font-semibold">
              <BookOpen className="w-3.5 h-3.5" />
              <span>{t.levels[level]}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {t.subjects.title}
            </h2>
            <p className="text-xs sm:text-sm text-purple-200/80 leading-relaxed">
              {t.subjects.subtitle}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-purple-300 font-semibold px-3 py-1.5 rounded-xl bg-purple-950/60 border border-purple-800/40">
              {subjectsList.length} {isRtl ? 'مواد دراسية متكاملة' : 'Subjects Available'}
            </span>
          </div>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/40 border border-purple-400/40'
                  : 'bg-[#130b24] text-purple-200/70 hover:text-white hover:bg-purple-950/50 border border-purple-900/20'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Subjects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredSubjects.map((sub, idx) => (
          <motion.div
            key={sub.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.05 }}
            className={`rounded-3xl bg-gradient-to-br ${sub.gradient} border border-purple-900/30 hover:border-purple-500/40 p-6 shadow-xl relative overflow-hidden flex flex-col justify-between transition-all group`}
          >
            <div className="relative z-10 space-y-4">
              {/* Top row */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-purple-950/80 border border-purple-500/30 flex items-center justify-center shadow-inner group-hover:scale-105 transition-transform">
                    {getSubjectIcon(sub.icon)}
                  </div>
                  <div>
                    <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
                      {sub.name}
                    </h3>
                    <span className="text-[11px] text-purple-300/70 font-medium">
                      {sub.topicsCount} {isRtl ? 'محور دراسي رئيسي' : 'Core Topics'}
                    </span>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-lg bg-purple-900/30 text-[10px] font-semibold text-purple-300 border border-purple-800/30">
                  {categories.find((c) => c.id === sub.category)?.label || sub.category}
                </span>
              </div>

              {/* Description */}
              <p className="text-xs text-purple-200/80 leading-relaxed">
                {sub.description}
              </p>

              {/* Topics Pills */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {sub.topics.map((top, i) => (
                  <span
                    key={i}
                    className="text-[11px] font-medium px-2.5 py-1 rounded-lg bg-black/40 text-purple-200/90 border border-purple-900/40"
                  >
                    {top}
                  </span>
                ))}
              </div>
            </div>

            {/* Action Buttons to deep-dive into AI tools */}
            <div className="relative z-10 mt-6 pt-4 border-t border-purple-900/30 grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => onNavigate('solver')}
                title={t.subjects.solveSubject}
                className="p-2.5 rounded-xl bg-purple-900/40 hover:bg-purple-800/60 border border-purple-700/30 text-purple-200 hover:text-white text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>📷</span>
                <span>{t.subjects.solveSubject}</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('explainer')}
                title={t.subjects.explainSubject}
                className="p-2.5 rounded-xl bg-purple-900/40 hover:bg-purple-800/60 border border-purple-700/30 text-purple-200 hover:text-white text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>📐</span>
                <span>{t.subjects.explainSubject}</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('summarizer')}
                title={t.subjects.summarizeSubject}
                className="p-2.5 rounded-xl bg-purple-900/40 hover:bg-purple-800/60 border border-purple-700/30 text-purple-200 hover:text-white text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>📑</span>
                <span>{t.subjects.summarizeSubject}</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('quiz')}
                title={t.subjects.quizSubject}
                className="p-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md shadow-purple-900/40"
              >
                <span>🎯</span>
                <span>{t.subjects.quizSubject}</span>
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
