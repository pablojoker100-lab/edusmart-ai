import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Settings, Globe, GraduationCap, Palette, Volume2, Sparkles, Share2, Copy, Check, Smartphone, Monitor, Info } from 'lucide-react';
import { Language, EducationLevel } from '../types';
import { translations } from '../i18n/translations';
import { authService, DEPLOYMENT_URL } from '../services/authService';

interface SettingsViewProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  level: EducationLevel;
  onLevelChange: (level: EducationLevel) => void;
  onOpenDeployment?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  lang,
  onLanguageChange,
  level,
  onLevelChange,
  onOpenDeployment,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const deploymentUrl = authService.getDeploymentUrl();

  const [soundEnabled, setSoundEnabled] = useState(true);
  const [animationsEnabled, setAnimationsEnabled] = useState(true);
  const [selectedThemeTone, setSelectedThemeTone] = useState<'obsidian' | 'amethyst'>('obsidian');
  const [copied, setCopied] = useState(false);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(deploymentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShare = async () => {
    const title = 'Mind AI - عقلك الذكي نحو مستقبل أفضل';
    const text = isRtl
      ? 'تطبيق Mind AI: عقلك الذكي نحو مستقبل أفضل. حل الواجبات، شرح الرياضيات والفيزياء، وملخصات الدروس واختبارات تفاعلية!'
      : 'Mind AI: Your intelligent mind towards a brighter future. Homework solver, math derivations, and quizzes.';

    if (navigator.share) {
      try {
        await navigator.share({ title, text, url: deploymentUrl });
        setShareFeedback(isRtl ? 'تمت المشاركة بنجاح!' : 'Shared successfully!');
        setTimeout(() => setShareFeedback(null), 2500);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          handleCopyLink();
        }
      }
    } else {
      handleCopyLink();
      setShareFeedback(isRtl ? 'تم نسخ الرابط! شاركه عبر واتساب أو أي تطبيق.' : 'Link copied to clipboard!');
      setTimeout(() => setShareFeedback(null), 2500);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#140b27] to-[#0a0714] border border-purple-900/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 end-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-purple-950/80 border border-purple-500/30 flex items-center justify-center text-purple-300 shadow-inner">
            <Settings className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {t.settings.title}
            </h2>
            <p className="text-xs sm:text-sm text-purple-200/80 mt-1">
              {t.settings.subtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Language Section */}
      <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-white font-bold text-base">
          <Globe className="w-5 h-5 text-purple-400" />
          <span>{t.settings.langSection}</span>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {[
            { id: 'ar' as Language, label: 'العربية (RTL)', flag: '🇸🇦' },
            { id: 'fr' as Language, label: 'Français (LTR)', flag: '🇫🇷' },
            { id: 'en' as Language, label: 'English (LTR)', flag: '🇬🇧' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onLanguageChange(item.id)}
              className={`p-4 rounded-2xl border text-xs sm:text-sm font-bold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                lang === item.id
                  ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-900/50 scale-[1.02]'
                  : 'bg-black/30 text-purple-200/70 hover:text-white hover:bg-purple-950/40 border-purple-900/30'
              }`}
            >
              <span className="text-2xl">{item.flag}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grade Level Section */}
      <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-white font-bold text-base">
          <GraduationCap className="w-5 h-5 text-violet-400" />
          <span>{t.settings.levelSection}</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { id: 'primary' as EducationLevel, label: t.levels.primary, icon: '🎒' },
            { id: 'middle' as EducationLevel, label: t.levels.middle, icon: '📐' },
            { id: 'high' as EducationLevel, label: t.levels.high, icon: '🎓' },
            { id: 'university' as EducationLevel, label: t.levels.university, icon: '🏛️' },
          ].map((lvl) => (
            <button
              key={lvl.id}
              type="button"
              onClick={() => onLevelChange(lvl.id)}
              className={`p-4 rounded-2xl border text-xs sm:text-sm font-bold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                level === lvl.id
                  ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-900/50 scale-[1.02]'
                  : 'bg-black/30 text-purple-200/70 hover:text-white hover:bg-purple-950/40 border-purple-900/30'
              }`}
            >
              <span className="text-2xl">{lvl.icon}</span>
              <span>{lvl.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Theme Tone & Preferences */}
      <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-5">
        <div className="flex items-center gap-2 text-white font-bold text-base">
          <Palette className="w-5 h-5 text-fuchsia-400" />
          <span>{t.settings.themeSection}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setSelectedThemeTone('obsidian')}
            className={`p-4 rounded-2xl border text-start flex items-center justify-between transition-all cursor-pointer ${
              selectedThemeTone === 'obsidian'
                ? 'bg-purple-950/80 border-purple-500 shadow-md'
                : 'bg-black/30 border-purple-900/30 text-purple-200/70'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-700 via-black to-violet-500 border border-purple-500/50" />
              <div>
                <strong className="text-white text-xs sm:text-sm block">{t.settings.themeObsidian}</strong>
                <span className="text-[11px] text-purple-300/60">{isRtl ? 'الأساسي المعتمد' : 'Default Premium Mode'}</span>
              </div>
            </div>
            {selectedThemeTone === 'obsidian' && <Check className="w-4 h-4 text-purple-400" />}
          </button>

          <button
            type="button"
            onClick={() => setSelectedThemeTone('amethyst')}
            className={`p-4 rounded-2xl border text-start flex items-center justify-between transition-all cursor-pointer ${
              selectedThemeTone === 'amethyst'
                ? 'bg-purple-950/80 border-purple-500 shadow-md'
                : 'bg-black/30 border-purple-900/30 text-purple-200/70'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-fuchsia-800 via-black to-purple-600 border border-fuchsia-500/50" />
              <div>
                <strong className="text-white text-xs sm:text-sm block">{t.settings.themeAmethyst}</strong>
                <span className="text-[11px] text-purple-300/60">{isRtl ? 'درجة أرجوانية داكنة' : 'Deep Velvet Violet'}</span>
              </div>
            </div>
            {selectedThemeTone === 'amethyst' && <Check className="w-4 h-4 text-purple-400" />}
          </button>
        </div>

        {/* Audio and Animations toggles */}
        <div className="pt-2 border-t border-purple-900/30 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Volume2 className="w-4 h-4 text-purple-400" />
              <span className="text-xs sm:text-sm text-purple-100 font-medium">{t.settings.soundToggle}</span>
            </div>
            <button
              type="button"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                soundEnabled ? 'bg-purple-600 justify-end' : 'bg-black/60 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-md" />
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 text-violet-400" />
              <span className="text-xs sm:text-sm text-purple-100 font-medium">{t.settings.animToggle}</span>
            </div>
            <button
              type="button"
              onClick={() => setAnimationsEnabled(!animationsEnabled)}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                animationsEnabled ? 'bg-purple-600 justify-end' : 'bg-black/60 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-md" />
            </button>
          </div>
        </div>
      </div>

      {/* Live Public Deployment Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-950 via-[#180d33] to-[#0a0714] border border-purple-700/50 shadow-2xl space-y-4">
        <div className="flex items-center gap-2">
          <Share2 className="w-5 h-5 text-purple-400" />
          <h3 className="text-base sm:text-lg font-bold text-white">
            {t.settings.deploymentTitle}
          </h3>
        </div>
        <p className="text-xs sm:text-sm text-purple-200/80 leading-relaxed">
          {t.settings.deploymentDesc}
        </p>

        {/* URL Box */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
          <input
            type="text"
            readOnly
            value={deploymentUrl}
            className="flex-1 bg-black/40 border border-purple-800/40 rounded-xl px-3.5 py-2.5 text-xs font-mono text-purple-300 font-semibold select-all focus:outline-none"
          />
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyLink}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md shadow-purple-900/40"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? t.settings.copied : t.settings.copyUrl}</span>
            </button>

            <button
              type="button"
              onClick={handleShare}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-purple-950 hover:bg-purple-900 text-purple-200 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border border-purple-700/40 transition-colors cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              <span>{t.settings.shareApp}</span>
            </button>
          </div>
        </div>

        {shareFeedback && (
          <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-700/40 text-emerald-200 text-xs font-semibold text-center">
            {shareFeedback}
          </div>
        )}
      </div>

      {/* PWA & Mobile Install Guide */}
      <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-3">
        <div className="flex items-center gap-2 text-white font-bold text-base">
          <Smartphone className="w-5 h-5 text-purple-400" />
          <span>{t.settings.pwaTitle}</span>
        </div>
        <p className="text-xs text-purple-200/80 leading-relaxed">
          {t.settings.pwaDesc}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs text-purple-200/70">
          <div className="p-3 rounded-2xl bg-black/30 border border-purple-900/20">
            <strong className="text-white block mb-1">Android (Chrome):</strong>
            <span>{isRtl ? 'اضغط على زر (⋮) ثم اختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".' : 'Tap (⋮) and choose "Install app" or "Add to Home screen".'}</span>
          </div>
          <div className="p-3 rounded-2xl bg-black/30 border border-purple-900/20">
            <strong className="text-white block mb-1">iPhone (Safari):</strong>
            <span>{isRtl ? 'اضغط على زر المشاركة ثم "إضافة إلى الصفحة الرئيسية".' : 'Tap Share button and choose "Add to Home Screen".'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
