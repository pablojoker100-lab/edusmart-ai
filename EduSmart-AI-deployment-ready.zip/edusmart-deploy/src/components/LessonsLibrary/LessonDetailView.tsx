import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  ArrowRight,
  Star,
  CheckCircle2,
  Clock,
  BookOpen,
  HelpCircle,
  Sparkles,
  Bot,
  Send,
  Award,
  ChevronDown,
  ChevronUp,
  Share2,
  Check,
  RotateCcw,
  Lightbulb,
  FileText
} from 'lucide-react';
import { EducationLevel, Language, LessonItem, LessonQuizQuestion } from '../../types';
import { lessonProgressService } from '../../services/lessonProgressService';
import { aiService } from '../../services/aiService';

interface LessonDetailViewProps {
  lesson: LessonItem;
  onBack: () => void;
  lang: Language;
  level: EducationLevel;
}

export const LessonDetailView: React.FC<LessonDetailViewProps> = ({
  lesson,
  onBack,
  lang,
  level,
}) => {
  const isAr = lang === 'ar';
  const BackArrow = isAr ? ArrowRight : ArrowLeft;

  const [activeTab, setActiveTab] = useState<'explanation' | 'examples' | 'summary' | 'glossary' | 'tutor' | 'quiz'>('explanation');
  const [isFavorite, setIsFavorite] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [expandedSolutions, setExpandedSolutions] = useState<Record<string, boolean>>({});

  // AI Tutor Q&A State
  const [tutorInput, setTutorInput] = useState('');
  const [failedTutorQuestion, setFailedTutorQuestion] = useState<string | null>(null);
  const [tutorMessages, setTutorMessages] = useState<
    { sender: 'user' | 'ai'; text: string; time: string }[]
  >([]);
  const [isTutorLoading, setIsTutorLoading] = useState(false);

  // Quiz State
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState<number | null>(null);

  // Load progress for this lesson
  useEffect(() => {
    const progress = lessonProgressService.getLessonProgress(lesson.id);
    setIsFavorite(progress.isFavorite);
    setIsCompleted(progress.completed);
    if (progress.quizScore !== undefined) {
      setQuizScore(progress.quizScore);
    }
  }, [lesson.id]);

  const handleToggleFavorite = () => {
    const newState = lessonProgressService.toggleFavorite(lesson.id);
    setIsFavorite(newState);
  };

  const handleToggleCompleted = () => {
    const newState = lessonProgressService.toggleCompleted(lesson.id);
    setIsCompleted(newState);
  };

  const toggleSolution = (id: string) => {
    setExpandedSolutions((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Submit AI Question
  const handleSendTutorQuestion = async (presetText?: string) => {
    const questionText = (presetText || tutorInput).trim();
    if (!questionText || isTutorLoading) return;

    const userMsg = {
      sender: 'user' as const,
      text: questionText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setTutorMessages((prev) => [...prev, userMsg]);
    if (!presetText) setTutorInput('');
    setFailedTutorQuestion(null);
    setIsTutorLoading(true);

    try {
      const res = await aiService.askLessonTutor({
        question: questionText,
        lessonTitle: lesson.title,
        subject: lesson.subjectId,
        unit: lesson.unit,
        level,
        lang,
      });

      setTutorMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: res.reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch {
      setFailedTutorQuestion(questionText);
      setTutorMessages((prev) => [
        ...prev,
        {
          sender: 'ai',
          text: isAr
            ? 'تعذر الاتصال المؤقت بالمعلم الذكي. تم حفظ سؤالك، يمكنك الضغط على زر إعادة المحاولة.'
            : 'Temporary connection issue. Your question is saved; click retry below.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsTutorLoading(false);
    }
  };

  // Quiz evaluation
  const handleSelectAnswer = (qId: string, optIndex: number) => {
    if (quizSubmitted) return;
    setUserAnswers((prev) => ({ ...prev, [qId]: optIndex }));
  };

  const handleEvaluateQuiz = () => {
    let correctCount = 0;
    lesson.quiz.forEach((q) => {
      if (userAnswers[q.id] === q.correctIndex) {
        correctCount += 1;
      }
    });

    setQuizScore(correctCount);
    setQuizSubmitted(true);
    lessonProgressService.saveQuizScore(lesson.id, correctCount, lesson.quiz.length);
    if (correctCount >= Math.ceil(lesson.quiz.length * 0.6)) {
      setIsCompleted(true);
    }
  };

  const handleResetQuiz = () => {
    setUserAnswers({});
    setQuizSubmitted(false);
  };

  // Subject Label Map
  const subjectLabels: Record<string, string> = {
    math: isAr ? 'الرياضيات' : 'Mathematics',
    physics_chemistry: isAr ? 'الفيزياء والكيمياء' : 'Physics & Chemistry',
    svt: isAr ? 'علوم الحياة والأرض' : 'SVT',
    philosophy: isAr ? 'الفلسفة' : 'Philosophy',
    arabic: isAr ? 'اللغة العربية' : 'Arabic',
    french: isAr ? 'اللغة الفرنسية' : 'French',
    english: isAr ? 'اللغة الإنجليزية' : 'English',
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Breadcrumb & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#110922] p-4 rounded-3xl border border-purple-900/40">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-purple-950/60 hover:bg-purple-900 text-purple-200 hover:text-white text-xs font-bold transition-all border border-purple-800/40 cursor-pointer"
        >
          <BackArrow className="w-4 h-4" />
          <span>{isAr ? 'العودة لمكتبة الدروس' : 'Back to Lessons'}</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Favorite Button */}
          <button
            type="button"
            onClick={handleToggleFavorite}
            title={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
            className={`p-2 rounded-2xl border transition-all cursor-pointer ${
              isFavorite
                ? 'bg-amber-500/20 border-amber-500 text-amber-400 shadow-md shadow-amber-500/20'
                : 'bg-black/30 border-purple-900/40 text-purple-300 hover:text-white hover:bg-purple-950/50'
            }`}
          >
            <Star className={`w-4 h-4 ${isFavorite ? 'fill-amber-400' : ''}`} />
          </button>

          {/* Completed Checkbox Button */}
          <button
            type="button"
            onClick={handleToggleCompleted}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-bold border transition-all cursor-pointer ${
              isCompleted
                ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300'
                : 'bg-black/30 border-purple-900/40 text-purple-300 hover:bg-purple-950/50'
            }`}
          >
            <CheckCircle2 className={`w-4 h-4 ${isCompleted ? 'text-emerald-400' : 'text-purple-400'}`} />
            <span>{isCompleted ? (isAr ? 'درس مكتمل' : 'Completed') : (isAr ? 'تحديد كمكتمل' : 'Mark Complete')}</span>
          </button>
        </div>
      </div>

      {/* Hero Lesson Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#160d2d] to-[#0a0714] border border-purple-800/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 end-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-purple-900/60 border border-purple-500/40 text-purple-200 text-[11px] font-bold">
              {subjectLabels[lesson.subjectId] || lesson.subjectId}
            </span>

            {lesson.moroccanTrack && (
              <span className="px-2.5 py-0.5 rounded-full bg-black/40 border border-purple-700/40 text-amber-300 text-[11px] font-semibold">
                🇲🇦 {lesson.moroccanTrack}
              </span>
            )}

            <span className="flex items-center gap-1 text-[11px] text-purple-300/80 bg-purple-950/40 px-2.5 py-0.5 rounded-full border border-purple-800/30">
              <Clock className="w-3 h-3 text-purple-400" />
              <span>{lesson.estimatedMinutes} {isAr ? 'دقيقة' : 'min'}</span>
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {lesson.title}
          </h1>

          <p className="text-xs sm:text-sm text-purple-200/80 leading-relaxed max-w-3xl">
            {lesson.description}
          </p>

          <div className="text-[11px] font-semibold text-purple-400/90 pt-1">
            <span>{lesson.unit}</span>
          </div>
        </div>
      </div>

      {/* Interactive Tabs Header */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-purple-900/40">
        {[
          { id: 'explanation', label: isAr ? 'شرح الدرس' : 'Explanation', icon: <BookOpen className="w-4 h-4" /> },
          { id: 'examples', label: isAr ? 'أمثلة تطبيقية' : 'Applied Examples', icon: <Lightbulb className="w-4 h-4" /> },
          { id: 'summary', label: isAr ? 'ملخص وقواعد' : 'Key Summary', icon: <FileText className="w-4 h-4" /> },
          { id: 'glossary', label: isAr ? 'معجم المصطلحات' : 'Glossary', icon: <HelpCircle className="w-4 h-4" /> },
          { id: 'tutor', label: isAr ? 'اسأل الذكاء الاصطناعي' : 'AI Tutor Q&A', icon: <Bot className="w-4 h-4" /> },
          { id: 'quiz', label: isAr ? 'اختبار الفهم' : 'Lesson Quiz', icon: <Award className="w-4 h-4" /> },
        ].map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/50 border border-purple-400/50'
                  : 'bg-[#120a24] text-purple-300/70 hover:bg-purple-950/60 hover:text-white border border-purple-900/30'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
              {tab.id === 'quiz' && quizScore !== null && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-purple-950 text-purple-300">
                  {quizScore}/{lesson.quiz.length}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content 1: Explanation */}
      {activeTab === 'explanation' && (
        <div className="space-y-6">
          {/* Intro Card */}
          <div className="p-5 sm:p-6 rounded-3xl bg-[#120b24] border border-purple-900/40 shadow-xl space-y-2.5">
            <h3 className="text-sm sm:text-base font-black text-purple-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>{isAr ? 'تمهيد ومدخل إلى الدرس' : 'Introduction & Fundamentals'}</span>
            </h3>
            <p className="text-xs sm:text-sm text-purple-100/90 leading-relaxed">
              {lesson.simplifiedExplanation.introduction}
            </p>
          </div>

          {/* Sections */}
          <div className="space-y-4">
            {lesson.simplifiedExplanation.sections.map((section, idx) => (
              <div
                key={idx}
                className="p-5 sm:p-6 rounded-3xl bg-[#130b26] border border-purple-800/40 shadow-xl space-y-3.5 hover:border-purple-600/40 transition-colors"
              >
                <h4 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-purple-900/70 text-purple-300 text-xs flex items-center justify-center font-black">
                    {idx + 1}
                  </span>
                  <span>{section.heading}</span>
                </h4>

                <div className="text-xs sm:text-sm text-purple-200/90 leading-relaxed whitespace-pre-line">
                  {section.content}
                </div>

                {section.keyFormulaOrRule && (
                  <div className="p-4 rounded-2xl bg-black/40 border border-purple-600/40 shadow-inner">
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1">
                      {isAr ? 'القاعدة أو الصيغة الرياضية المركزية' : 'Core Rule / Formula'}
                    </span>
                    <div className="font-mono text-xs sm:text-sm text-purple-200 font-bold overflow-x-auto py-1">
                      {section.keyFormulaOrRule}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Conclusion */}
          <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-950/60 to-[#140b27] border border-purple-700/40 shadow-xl">
            <h4 className="text-xs sm:text-sm font-bold text-white mb-1.5 flex items-center gap-2">
              <Check className="w-4 h-4 text-purple-400" />
              <span>{isAr ? 'خلاصة الدرس واستيعاب المفاهيم' : 'Lesson Synthesis'}</span>
            </h4>
            <p className="text-xs sm:text-sm text-purple-200/80 leading-relaxed">
              {lesson.simplifiedExplanation.conclusion}
            </p>
          </div>
        </div>
      )}

      {/* Tab Content 2: Applied Examples (National Exam Style) */}
      {activeTab === 'examples' && (
        <div className="space-y-5">
          <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-800/40 text-xs text-purple-300 flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <span>
              {isAr
                ? 'نماذج تطبيقية وتمارين محلولة مستوحاة من الامتحانات الوطنية والجهوية الموحدة بالمغرب.'
                : 'Applied problems with complete step-by-step solutions inspired by official Moroccan examinations.'}
            </span>
          </div>

          {lesson.practicalExamples.map((ex) => {
            const isExpanded = !!expandedSolutions[ex.id];
            return (
              <div
                key={ex.id}
                className="p-5 sm:p-6 rounded-3xl bg-[#130b26] border border-purple-800/40 shadow-xl space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-purple-900/40 pb-3">
                  <h4 className="text-sm sm:text-base font-bold text-white">
                    {ex.title}
                  </h4>
                  {ex.examOrigin && (
                    <span className="px-2.5 py-0.5 rounded-full bg-purple-900/50 border border-purple-600/40 text-amber-300 text-[10px] font-semibold">
                      📝 {ex.examOrigin}
                    </span>
                  )}
                </div>

                {/* Problem Statement */}
                <div className="p-4 rounded-2xl bg-black/40 border border-purple-900/30 text-xs sm:text-sm text-purple-100 whitespace-pre-line leading-relaxed font-sans">
                  <strong className="block text-purple-300 mb-1 text-xs">
                    {isAr ? 'نص المسألة / التمرين:' : 'Problem Statement:'}
                  </strong>
                  {ex.problem}
                </div>

                {/* Solution Toggle */}
                <div>
                  <button
                    type="button"
                    onClick={() => toggleSolution(ex.id)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-900/40 cursor-pointer"
                  >
                    <span>{isExpanded ? (isAr ? 'إخفاء الحل النموذجي' : 'Hide Solution') : (isAr ? 'عرض الحل النموذجي خطوة بخطوة' : 'Show Step-by-Step Solution')}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.2 }}
                        className="mt-3.5 p-4 rounded-2xl bg-[#1b1036] border border-purple-700/50 text-xs sm:text-sm text-purple-100/95 whitespace-pre-line leading-relaxed"
                      >
                        <strong className="block text-emerald-400 mb-2 font-bold text-xs">
                          {isAr ? '✓ عناصر الإجابة والحل المفصل:' : '✓ Detailed Solution:'}
                        </strong>
                        {ex.solution}

                        {ex.tip && (
                          <div className="mt-3 pt-3 border-t border-purple-800/40 text-amber-300 text-xs flex items-start gap-2">
                            <span className="font-bold">💡 {isAr ? 'توجيه الامتحان:' : 'Exam Tip:'}</span>
                            <span>{ex.tip}</span>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab Content 3: Summary & Key Points */}
      {activeTab === 'summary' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-[#120b24] border border-purple-800/40 shadow-xl space-y-5">
          <div className="flex items-center gap-2.5 pb-3 border-b border-purple-900/40">
            <FileText className="w-5 h-5 text-purple-400" />
            <div>
              <h3 className="text-base font-black text-white">
                {isAr ? 'خلاصة الدرس والقواعد الذهبية' : 'Essential Lesson Rules & Formulas'}
              </h3>
              <p className="text-xs text-purple-300/70">
                {isAr ? 'أهم الأفكار والقواعد التي يجب حفظها ومراجعتها قبل الامتحان' : 'Core summary points for exam preparation'}
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {lesson.summaryKeyPoints.map((point, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-3.5 rounded-2xl bg-black/30 border border-purple-900/30 text-xs sm:text-sm text-purple-100"
              >
                <div className="w-5 h-5 rounded-full bg-purple-600/30 text-purple-300 flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 border border-purple-500/40">
                  {idx + 1}
                </div>
                <span className="leading-relaxed">{point}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Content 4: Glossary of Difficult Terms */}
      {activeTab === 'glossary' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-800/40 text-xs text-purple-300">
            {isAr
              ? 'معجم المفاهيم والمصطلحات الأكاديمية الصعبة لتعميق الفهم والاستعمال اللغوي والعلمي الصحيح.'
              : 'Glossary of academic and technical terms in this lesson.'}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {lesson.difficultTerms.map((term, idx) => (
              <div
                key={idx}
                className="p-5 rounded-3xl bg-[#130b26] border border-purple-800/40 shadow-lg space-y-2"
              >
                <h4 className="text-sm font-bold text-purple-300 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-400" />
                  <span>{term.term}</span>
                </h4>
                <p className="text-xs sm:text-sm text-purple-100/90 leading-relaxed">
                  {term.definition}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Content 5: AI Lesson Tutor Q&A */}
      {activeTab === 'tutor' && (
        <div className="p-5 sm:p-6 rounded-3xl bg-[#120b24] border border-purple-800/40 shadow-xl space-y-5">
          <div className="flex items-center gap-2.5 pb-3 border-b border-purple-900/40">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-violet-500 flex items-center justify-center text-white shadow-md">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                {isAr ? 'اسأل الذكاء الاصطناعي حول هذا الدرس' : 'Interactive AI Lesson Tutor'}
              </h3>
              <p className="text-xs text-purple-300/70">
                {isAr
                  ? 'طرح أي سؤال أو طلب توضيح إضافي بخصوص هذا الدرس وفق المنهاج المغربي'
                  : 'Ask any question or get additional explanations tailored to this specific lesson'}
              </p>
            </div>
          </div>

          {/* Quick preset questions */}
          <div className="flex flex-wrap gap-2 text-xs">
            {[
              isAr ? 'اشرح لي هذا الدرس بمثال واقعي بسيط' : 'Explain this with a simple real-life example',
              isAr ? 'ما هي الأخطاء الشائعة في هذا الدرس بالامتحان الوطني؟' : 'What are common mistakes in this topic?',
              isAr ? 'كيف أطبق هذه القاعدة في مسألة صعبة؟' : 'How to apply this formula in hard problems?',
            ].map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendTutorQuestion(preset)}
                className="px-3 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900 text-purple-200 border border-purple-800/40 text-xs transition-colors cursor-pointer text-start"
              >
                💬 {preset}
              </button>
            ))}
          </div>

          {/* Conversation history */}
          <div className="space-y-3 min-h-[200px] max-h-[400px] overflow-y-auto p-4 rounded-2xl bg-black/40 border border-purple-900/30">
            {tutorMessages.length === 0 ? (
              <div className="text-center py-10 text-purple-300/60 text-xs">
                {isAr
                  ? 'لم تطرح أي سؤال بعد. اكتب سؤالك أدناه أو اختر أحد الاقتراحات السريعة أعلاه!'
                  : 'No questions asked yet. Type your question below or pick a preset above!'}
              </div>
            ) : (
              tutorMessages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed whitespace-pre-line ${
                      msg.sender === 'user'
                        ? 'bg-purple-600 text-white rounded-ee-none'
                        : 'bg-[#1b1036] border border-purple-700/50 text-purple-100 rounded-es-none'
                    }`}
                  >
                    {msg.text}
                  </div>
                  <span className="text-[10px] text-purple-400/60 px-1 mt-1">{msg.time}</span>
                </div>
              ))
            )}

            {isTutorLoading && (
              <div className="flex items-center gap-2 p-3 text-xs text-purple-300">
                <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                <span>{isAr ? 'الذكاء الاصطناعي يقوم بصياغة الإجابة والتحليل السريع...' : 'AI Tutor is thinking...'}</span>
              </div>
            )}

            {failedTutorQuestion && (
              <div className="p-3 bg-amber-950/40 border border-amber-500/40 rounded-2xl flex items-center justify-between gap-2 text-xs text-amber-200">
                <span>{isAr ? 'تم حفظ سؤالك، يمكنك إعادة المحاولة فوراً:' : 'Question saved. Retry:'}</span>
                <button
                  type="button"
                  onClick={() => handleSendTutorQuestion(failedTutorQuestion)}
                  className="px-3 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendTutorQuestion();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={tutorInput}
              onChange={(e) => setTutorInput(e.target.value)}
              placeholder={isAr ? 'اطرح سؤالك حول هذا الدرس بالتحديد...' : 'Type your question about this lesson...'}
              className="flex-1 bg-[#1a0f33] border border-purple-800/40 rounded-2xl px-4 py-3 text-xs sm:text-sm text-white placeholder-purple-400/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <button
              type="submit"
              disabled={!tutorInput.trim() || isTutorLoading}
              className="px-4 py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold transition-all shadow-md shadow-purple-900/50 cursor-pointer flex items-center justify-center"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* Tab Content 6: Interactive Lesson Quiz */}
      {activeTab === 'quiz' && (
        <div className="p-5 sm:p-8 rounded-3xl bg-[#120b24] border border-purple-800/40 shadow-xl space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-purple-900/40">
            <div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400" />
                <span>{isAr ? 'اختبار قياس مدى استيعاب الدرس' : 'End-of-Lesson Comprehension Quiz'}</span>
              </h3>
              <p className="text-xs text-purple-300/70 mt-0.5">
                {isAr
                  ? 'أسئلة متعددة الاختيارات مع تصحيح تلقائي وتفسير تفصيلي للإجابات'
                  : 'Multiple-choice questions with instant scoring and detailed explanations'}
              </p>
            </div>

            {quizSubmitted && quizScore !== null && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-purple-950 border border-purple-600/40">
                <span className="text-xs text-purple-300 font-bold">{isAr ? 'النتيجة:' : 'Score:'}</span>
                <span className="text-sm font-black text-amber-300">
                  {quizScore} / {lesson.quiz.length}
                </span>
              </div>
            )}
          </div>

          <div className="space-y-6">
            {lesson.quiz.map((q, qIndex) => {
              const selectedOpt = userAnswers[q.id];
              const isAnswered = selectedOpt !== undefined;

              return (
                <div
                  key={q.id}
                  className="p-5 rounded-3xl bg-[#140c28] border border-purple-900/40 space-y-3"
                >
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-xl bg-purple-900/70 text-purple-300 text-xs font-black flex items-center justify-center flex-shrink-0 mt-0.5">
                      {qIndex + 1}
                    </span>
                    <h4 className="text-xs sm:text-sm font-bold text-white leading-relaxed">
                      {q.question}
                    </h4>
                  </div>

                  {/* Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                    {q.options.map((opt, optIndex) => {
                      const isSelected = selectedOpt === optIndex;
                      const isCorrect = q.correctIndex === optIndex;

                      let style = 'bg-black/30 border-purple-900/30 text-purple-200/80 hover:bg-purple-950/40';
                      if (quizSubmitted) {
                        if (isCorrect) {
                          style = 'bg-emerald-950/80 border-emerald-500 text-emerald-200 font-bold shadow-md shadow-emerald-900/40';
                        } else if (isSelected && !isCorrect) {
                          style = 'bg-red-950/80 border-red-500 text-red-200';
                        }
                      } else if (isSelected) {
                        style = 'bg-purple-600 text-white border-purple-400 shadow-md shadow-purple-900/40';
                      }

                      return (
                        <button
                          key={optIndex}
                          type="button"
                          disabled={quizSubmitted}
                          onClick={() => handleSelectAnswer(q.id, optIndex)}
                          className={`p-3.5 rounded-2xl border text-xs sm:text-sm text-start transition-all cursor-pointer flex items-center justify-between ${style}`}
                        >
                          <span>{opt}</span>
                          {quizSubmitted && isCorrect && <Check className="w-4 h-4 text-emerald-400" />}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation after submission */}
                  {quizSubmitted && (
                    <div className="mt-3 p-3 rounded-2xl bg-purple-950/40 border border-purple-800/30 text-xs text-purple-200/90 leading-relaxed">
                      <strong className="text-purple-300 block mb-0.5 font-bold">
                        {isAr ? 'تفسير الإجابة الصحيحة:' : 'Explanation:'}
                      </strong>
                      {q.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Quiz Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-purple-900/40">
            {!quizSubmitted ? (
              <button
                type="button"
                onClick={handleEvaluateQuiz}
                disabled={Object.keys(userAnswers).length === 0}
                className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 disabled:opacity-50 text-white font-bold text-xs sm:text-sm shadow-lg shadow-purple-900/50 cursor-pointer"
              >
                {isAr ? 'تصحيح الإجابات وحساب النتيجة' : 'Submit & Check Answers'}
              </button>
            ) : (
              <button
                type="button"
                onClick={handleResetQuiz}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-2xl bg-purple-950 hover:bg-purple-900 text-purple-200 text-xs sm:text-sm font-bold border border-purple-700/40 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{isAr ? 'إعادة الاختبار' : 'Retake Quiz'}</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
