import React, { useState } from 'react';
import { X, Plus, BookOpen, Check } from 'lucide-react';
import { EducationLevel, Language, LessonItem, LessonSubjectId } from '../../types';
import { lessonProgressService } from '../../services/lessonProgressService';

interface AddLessonModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLessonAdded: (lesson: LessonItem) => void;
  lang: Language;
  defaultLevel: EducationLevel;
  defaultSubject?: LessonSubjectId;
}

export const AddLessonModal: React.FC<AddLessonModalProps> = ({
  isOpen,
  onClose,
  onLessonAdded,
  lang,
  defaultLevel,
  defaultSubject = 'math',
}) => {
  const isAr = lang === 'ar';

  const [title, setTitle] = useState('');
  const [subjectId, setSubjectId] = useState<LessonSubjectId>(defaultSubject);
  const [level, setLevel] = useState<EducationLevel>(defaultLevel);
  const [moroccanTrack, setMoroccanTrack] = useState('الثانية باكالوريا - علوم تجريبية ورياضية');
  const [unit, setUnit] = useState('الوحدة الأولى');
  const [estimatedMinutes, setEstimatedMinutes] = useState(20);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [description, setDescription] = useState('');
  const [intro, setIntro] = useState('');
  const [section1Heading, setSection1Heading] = useState('1. المفهوم والقاعدة الأساسية');
  const [section1Content, setSection1Content] = useState('');
  const [section1Formula, setSection1Formula] = useState('');
  const [conclusion, setConclusion] = useState('');
  const [summaryPoints, setSummaryPoints] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      alert(isAr ? 'يرجى إدخال عنوان الدرس والوصف.' : 'Please enter lesson title and description.');
      return;
    }

    const newLesson: LessonItem = {
      id: `custom-${Date.now()}`,
      title: title.trim(),
      subjectId,
      level,
      moroccanTrack: moroccanTrack.trim() || 'المنهاج المغربي الرسمي',
      unit: unit.trim() || 'الوحدة التعليمية',
      estimatedMinutes: Number(estimatedMinutes) || 20,
      difficulty,
      description: description.trim(),
      simplifiedExplanation: {
        introduction: intro.trim() || description.trim(),
        sections: [
          {
            heading: section1Heading.trim() || '1. القواعد والشرح',
            content: section1Content.trim() || description.trim(),
            keyFormulaOrRule: section1Formula.trim() || undefined,
          },
        ],
        conclusion: conclusion.trim() || 'تمت دراسة هذا الدرس بنجاح وفق المقرر الدراسي.',
      },
      practicalExamples: [
        {
          id: `ex-${Date.now()}`,
          title: 'مثال تطبيقي (نموذج امتحانات)',
          problem: 'تطبيق مباشر للقاعدة والقوانين المدروسة في هذا الدرس.',
          solution: 'يتم التعويض بالمعطيات وتطبيق الخاصية خطوة بخطوة للوصول إلى النتيجة الصحيحة.',
          examOrigin: 'الامتحان الوطني / الجهوي الموحد',
        },
      ],
      summaryKeyPoints: summaryPoints.trim()
        ? summaryPoints.split('\n').filter((p) => p.trim())
        : [title.trim(), 'القاعدة الأساسية للدرس وتطبيقاتها.'],
      difficultTerms: [
        {
          term: title.trim(),
          definition: description.trim(),
        },
      ],
      quiz: [
        {
          id: `q-${Date.now()}-1`,
          question: `ما هو المفهوم الرئيسي لدرس "${title.trim()}"؟`,
          options: [
            description.trim().slice(0, 45) || 'القاعدة الأساسية للدرس',
            'مفهوم غير مرتبط بالدرس',
            'تطبيق افتراضي',
            'لا شيء مما سبق',
          ],
          correctIndex: 0,
          explanation: 'الخيار الأول يمثل المفهوم الصحيح المحدد في الدرس.',
        },
      ],
      isCustom: true,
    };

    lessonProgressService.saveCustomLesson(newLesson);
    onLessonAdded(newLesson);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in">
      <div className="bg-[#120b24] border border-purple-800/60 rounded-3xl p-5 sm:p-6 w-full max-w-2xl text-white shadow-2xl relative my-8">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 end-4 text-purple-400 hover:text-white p-1 rounded-xl bg-purple-950/40 hover:bg-purple-900 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-purple-900/40">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-violet-500 flex items-center justify-center text-white shadow-md">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">
              {isAr ? 'إضافة درس تعليمي جديد' : 'Add New Educational Lesson'}
            </h3>
            <p className="text-xs text-purple-300/70">
              {isAr
                ? 'إثراء مكتبة الدروس بمحتوى جديد وفق المنهاج المغربي'
                : 'Enrich the lesson library with new curriculum content'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {/* Title & Subject */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-purple-200 font-semibold mb-1">
                {isAr ? 'عنوان الدرس *' : 'Lesson Title *'}
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={isAr ? 'مثال: حساب التكامل وتطبيقاته' : 'e.g. Integral Calculus'}
                className="w-full bg-[#1b1133] border border-purple-800/40 rounded-xl px-3.5 py-2 text-white placeholder-purple-400/40 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-purple-200 font-semibold mb-1">
                {isAr ? 'المادة الدراسية' : 'Subject'}
              </label>
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value as LessonSubjectId)}
                className="w-full bg-[#1b1133] border border-purple-800/40 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 cursor-pointer"
              >
                <option value="math">{isAr ? 'الرياضيات' : 'Mathematics'}</option>
                <option value="physics_chemistry">{isAr ? 'الفيزياء والكيمياء' : 'Physics & Chemistry'}</option>
                <option value="svt">{isAr ? 'علوم الحياة والأرض (SVT)' : 'Life & Earth Sciences'}</option>
                <option value="philosophy">{isAr ? 'الفلسفة' : 'Philosophy'}</option>
                <option value="arabic">{isAr ? 'اللغة العربية' : 'Arabic'}</option>
                <option value="french">{isAr ? 'اللغة الفرنسية' : 'French'}</option>
                <option value="english">{isAr ? 'اللغة الإنجليزية' : 'English'}</option>
              </select>
            </div>
          </div>

          {/* Level & Track */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-purple-200 font-semibold mb-1">
                {isAr ? 'المستوى الدراسي' : 'School Level'}
              </label>
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as EducationLevel)}
                className="w-full bg-[#1b1133] border border-purple-800/40 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500 cursor-pointer"
              >
                <option value="high">{isAr ? 'الثانوي التأهيلي (الباكالوريا)' : 'High School'}</option>
                <option value="middle">{isAr ? 'الثانوي الإعدادي' : 'Middle School'}</option>
                <option value="primary">{isAr ? 'الابتدائي' : 'Primary'}</option>
                <option value="university">{isAr ? 'الجامعي' : 'University'}</option>
              </select>
            </div>

            <div>
              <label className="block text-purple-200 font-semibold mb-1">
                {isAr ? 'الشعبة / المسلك المغربي' : 'Moroccan Track'}
              </label>
              <input
                type="text"
                value={moroccanTrack}
                onChange={(e) => setMoroccanTrack(e.target.value)}
                placeholder={isAr ? 'مثال: 2BAC علوم رياضية / علوم تجريبية' : 'Track info'}
                className="w-full bg-[#1b1133] border border-purple-800/40 rounded-xl px-3.5 py-2 text-white placeholder-purple-400/40 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          {/* Unit & Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-purple-200 font-semibold mb-1">
                {isAr ? 'الوحدة / المجزوءة / المحور' : 'Unit / Module'}
              </label>
              <input
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder={isAr ? 'مثال: الوحدة الثالثة: حساب التكامل' : 'Unit title'}
                className="w-full bg-[#1b1133] border border-purple-800/40 rounded-xl px-3.5 py-2 text-white placeholder-purple-400/40 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block text-purple-200 font-semibold mb-1">
                {isAr ? 'المدة (بالدقائق)' : 'Minutes'}
              </label>
              <input
                type="number"
                min={5}
                max={180}
                value={estimatedMinutes}
                onChange={(e) => setEstimatedMinutes(Number(e.target.value))}
                className="w-full bg-[#1b1133] border border-purple-800/40 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-purple-200 font-semibold mb-1">
              {isAr ? 'وصف موجز للدرس *' : 'Brief Description *'}
            </label>
            <textarea
              required
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={isAr ? 'مقدمة سريعة توضح أهداف الدرس وأهميته في الامتحان...' : 'Overview of the lesson'}
              className="w-full bg-[#1b1133] border border-purple-800/40 rounded-xl p-3 text-white placeholder-purple-400/40 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
            />
          </div>

          {/* Section Content & Formula */}
          <div className="p-3.5 rounded-2xl bg-black/40 border border-purple-900/40 space-y-2.5">
            <h4 className="text-xs font-bold text-purple-300">
              {isAr ? 'المحتوى والشرح التفصيلي' : 'Detailed Explanation'}
            </h4>
            <input
              type="text"
              value={section1Heading}
              onChange={(e) => setSection1Heading(e.target.value)}
              placeholder={isAr ? 'عنوان المحور الأول' : 'Section Heading'}
              className="w-full bg-[#160c2b] border border-purple-800/30 rounded-lg px-3 py-1.5 text-xs text-white"
            />
            <textarea
              rows={3}
              value={section1Content}
              onChange={(e) => setSection1Content(e.target.value)}
              placeholder={isAr ? 'اكتب الشرح المبسط والقواعد والنظريات الأساسية...' : 'Explanation content'}
              className="w-full bg-[#160c2b] border border-purple-800/30 rounded-lg p-2.5 text-xs text-white resize-none"
            />
            <input
              type="text"
              value={section1Formula}
              onChange={(e) => setSection1Formula(e.target.value)}
              placeholder={isAr ? 'القاعدة أو الصيغة الرياضية المركزية (اختياري)' : 'Key formula or rule (optional)'}
              className="w-full bg-[#160c2b] border border-purple-800/30 rounded-lg px-3 py-1.5 text-xs text-purple-300 font-mono"
            />
          </div>

          {/* Key Summary points */}
          <div>
            <label className="block text-purple-200 font-semibold mb-1">
              {isAr ? 'خلاصات وقواعد ذهبية (نقطة في كل سطر)' : 'Summary Key Points (one per line)'}
            </label>
            <textarea
              rows={2}
              value={summaryPoints}
              onChange={(e) => setSummaryPoints(e.target.value)}
              placeholder={isAr ? "القاعدة الأولى المهمة\nالقاعدة الثانية للحل\nنصيحة الامتحان الوطني" : "Key points"}
              className="w-full bg-[#1b1133] border border-purple-800/40 rounded-xl p-3 text-white placeholder-purple-400/40 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-purple-900/40">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-purple-950/60 hover:bg-purple-900 text-purple-300 text-xs font-semibold transition-colors"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-purple-900/50"
            >
              <Check className="w-4 h-4" />
              <span>{isAr ? 'حفظ وإضافة الدرس' : 'Save Lesson'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
