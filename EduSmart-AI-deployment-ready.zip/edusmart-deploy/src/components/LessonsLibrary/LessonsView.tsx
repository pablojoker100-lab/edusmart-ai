import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  GraduationCap,
  Search,
  Star,
  CheckCircle2,
  Clock,
  Plus,
  Filter,
  Calculator,
  Atom,
  Dna,
  BookMarked,
  Languages,
  BookOpen,
  ArrowRight,
  ArrowLeft,
  Award,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { EducationLevel, Language, LessonItem, LessonSubjectId } from '../../types';
import { lessonProgressService } from '../../services/lessonProgressService';
import { LessonDetailView } from './LessonDetailView';
import { AddLessonModal } from './AddLessonModal';

interface LessonsViewProps {
  lang: Language;
  level: EducationLevel;
  onLevelChange?: (level: EducationLevel) => void;
}

export const LessonsView: React.FC<LessonsViewProps> = ({
  lang,
  level,
  onLevelChange,
}) => {
  const isAr = lang === 'ar';
  const Arrow = isAr ? ArrowLeft : ArrowRight;

  const [selectedSubject, setSelectedSubject] = useState<LessonSubjectId | 'all'>('all');
  const [filterType, setFilterType] = useState<'all' | 'favorites' | 'incomplete' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLesson, setSelectedLesson] = useState<LessonItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [allLessons, setAllLessons] = useState<LessonItem[]>([]);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Load all lessons
  useEffect(() => {
    setAllLessons(lessonProgressService.getAllLessons());
  }, [refreshTrigger]);

  const refreshData = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  // 7 Subjects definitions
  const subjectsList: {
    id: LessonSubjectId;
    name: string;
    nameFr: string;
    icon: React.ReactNode;
    color: string;
  }[] = [
    {
      id: 'math',
      name: 'الرياضيات',
      nameFr: 'Mathématiques',
      icon: <Calculator className="w-4 h-4 text-purple-300" />,
      color: 'from-purple-600/30 to-violet-800/30 border-purple-500/40',
    },
    {
      id: 'physics_chemistry',
      name: 'الفيزياء والكيمياء',
      nameFr: 'Physique - Chimie',
      icon: <Atom className="w-4 h-4 text-cyan-300" />,
      color: 'from-cyan-600/30 to-blue-800/30 border-cyan-500/40',
    },
    {
      id: 'svt',
      name: 'علوم الحياة والأرض',
      nameFr: 'SVT',
      icon: <Dna className="w-4 h-4 text-emerald-300" />,
      color: 'from-emerald-600/30 to-teal-800/30 border-emerald-500/40',
    },
    {
      id: 'philosophy',
      name: 'الفلسفة',
      nameFr: 'Philosophie',
      icon: <BookMarked className="w-4 h-4 text-amber-300" />,
      color: 'from-amber-600/30 to-orange-800/30 border-amber-500/40',
    },
    {
      id: 'arabic',
      name: 'اللغة العربية',
      nameFr: 'Langue Arabe',
      icon: <BookOpen className="w-4 h-4 text-fuchsia-300" />,
      color: 'from-fuchsia-600/30 to-pink-800/30 border-fuchsia-500/40',
    },
    {
      id: 'french',
      name: 'اللغة الفرنسية',
      nameFr: 'Français',
      icon: <Languages className="w-4 h-4 text-indigo-300" />,
      color: 'from-indigo-600/30 to-purple-800/30 border-indigo-500/40',
    },
    {
      id: 'english',
      name: 'اللغة الإنجليزية',
      nameFr: 'English',
      icon: <Languages className="w-4 h-4 text-rose-300" />,
      color: 'from-rose-600/30 to-pink-800/30 border-rose-500/40',
    },
  ];

  // Filtering lessons
  const filteredLessons = useMemo(() => {
    const progressMap = lessonProgressService.getProgressMap();
    const favorites = lessonProgressService.getFavorites();

    return allLessons.filter((l) => {
      // 1. Subject Filter
      if (selectedSubject !== 'all' && l.subjectId !== selectedSubject) {
        return false;
      }

      // 2. Status / Bookmark Filter
      const isFav = favorites.includes(l.id);
      const isComp = !!progressMap[l.id]?.completed;

      if (filterType === 'favorites' && !isFav) return false;
      if (filterType === 'completed' && !isComp) return false;
      if (filterType === 'incomplete' && isComp) return false;

      // 3. Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const inTitle = l.title.toLowerCase().includes(q);
        const inDesc = l.description.toLowerCase().includes(q);
        const inUnit = l.unit.toLowerCase().includes(q);
        const inTrack = l.moroccanTrack?.toLowerCase().includes(q);
        if (!inTitle && !inDesc && !inUnit && !inTrack) return false;
      }

      return true;
    });
  }, [allLessons, selectedSubject, filterType, searchQuery, refreshTrigger]);

  // Overall Statistics
  const stats = useMemo(() => {
    return lessonProgressService.getStats(selectedSubject === 'all' ? undefined : selectedSubject);
  }, [selectedSubject, refreshTrigger, allLessons]);

  // If a lesson is opened, render Detail View
  if (selectedLesson) {
    return (
      <LessonDetailView
        lesson={selectedLesson}
        onBack={() => {
          setSelectedLesson(null);
          refreshData();
        }}
        lang={lang}
        level={level}
      />
    );
  }

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-200">
      {/* Hero Moroccan Curriculum Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#150c2a] to-[#080512] border border-purple-800/40 text-white p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 end-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 start-0 w-80 h-80 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-purple-900/60 border border-purple-500/40 text-purple-200 text-xs font-bold">
                <GraduationCap className="w-3.5 h-3.5 text-purple-400" />
                <span>{isAr ? 'مكتبة الدروس والمنهاج المغربي' : 'Moroccan Curriculum Lessons'}</span>
              </span>

              <span className="px-2.5 py-0.5 rounded-full bg-black/40 border border-amber-600/40 text-amber-300 text-[11px] font-semibold">
                🇲🇦 مقرر وزارة التربية الوطنية
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {isAr ? 'دروس تعليمية شاملة ومفصلة' : 'Comprehensive Structured Lessons'}
            </h2>

            <p className="text-xs sm:text-sm text-purple-200/80 leading-relaxed">
              {isAr
                ? 'دروس غنية ومفصلة لجميع المواد الدراسية مع شروحات الذكاء الاصطناعي، أمثلة الامتحانات الوطنية والجهوية، وتتبع ذكي لتقدمك في التعلم.'
                : 'Authentic lessons across math, sciences, philosophy and languages with AI explanations, exam exercises, and progress tracking.'}
            </p>
          </div>

          {/* Quick Action: Add Custom Lesson */}
          <div className="flex flex-col sm:flex-row md:flex-col items-stretch sm:items-center md:items-end gap-3 flex-shrink-0">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-purple-900/40 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة درس جديد' : 'Add New Lesson'}</span>
            </button>

            {/* Quick Progress Indicator */}
            <div className="p-3 rounded-2xl bg-[#120822] border border-purple-800/40 text-xs text-purple-200/90 w-full sm:w-auto text-center md:text-start">
              <div className="flex items-center justify-between gap-4 mb-1">
                <span className="font-semibold">{isAr ? 'نسبة الإنجاز:' : 'Completion:'}</span>
                <span className="font-black text-purple-300">{stats.percentage}%</span>
              </div>
              <div className="w-36 h-2 bg-purple-950 rounded-full overflow-hidden border border-purple-800/40">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-fuchsia-400 rounded-full transition-all duration-500"
                  style={{ width: `${stats.percentage}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 7 Subjects Selector Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-white px-1">
          <span className="flex items-center gap-1.5">
            <BookOpen className="w-4 h-4 text-purple-400" />
            <span>{isAr ? 'المواد الدراسية السبع (المنهاج المغربي)' : 'The 7 Educational Subjects'}</span>
          </span>
          <span className="text-purple-300/60 text-xs font-normal">
            {allLessons.length} {isAr ? 'درساً متاحاً' : 'lessons available'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
          {/* All Subjects Pill */}
          <button
            type="button"
            onClick={() => setSelectedSubject('all')}
            className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
              selectedSubject === 'all'
                ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-900/50 scale-[1.02]'
                : 'bg-[#120a24] text-purple-200/70 hover:text-white hover:bg-purple-950/50 border-purple-900/30'
            }`}
          >
            <Sparkles className="w-4 h-4 text-purple-300" />
            <span className="truncate max-w-full">{isAr ? 'الكل' : 'All'}</span>
          </button>

          {/* 7 Subject Buttons */}
          {subjectsList.map((sub) => {
            const isSelected = selectedSubject === sub.id;
            const count = allLessons.filter((l) => l.subjectId === sub.id).length;

            return (
              <button
                key={sub.id}
                type="button"
                onClick={() => setSelectedSubject(sub.id)}
                className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-900/50 scale-[1.02]'
                    : 'bg-[#120a24] text-purple-200/70 hover:text-white hover:bg-purple-950/50 border-purple-900/30'
                }`}
              >
                <span>{sub.icon}</span>
                <span className="truncate max-w-full">{isAr ? sub.name : sub.nameFr}</span>
                <span className="text-[10px] opacity-75">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'all', label: isAr ? 'جميع الدروس' : 'All Lessons', icon: null },
            { id: 'favorites', label: isAr ? 'المفضلة ⭐' : 'Favorites', icon: <Star className="w-3.5 h-3.5" /> },
            { id: 'incomplete', label: isAr ? 'غير المكتملة ⏳' : 'Incomplete', icon: null },
            { id: 'completed', label: isAr ? 'المكتملة ✅' : 'Completed', icon: <CheckCircle2 className="w-3.5 h-3.5" /> },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setFilterType(item.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                filterType === item.id
                  ? 'bg-purple-900/70 text-purple-200 border border-purple-600 shadow-sm'
                  : 'bg-black/30 text-purple-300/60 hover:text-purple-200 border border-purple-900/30'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-purple-400 absolute start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'بحث في الدروس والقواعد...' : 'Search lessons & topics...'}
            className="w-full bg-[#120a24] border border-purple-800/40 rounded-xl ps-9 pe-4 py-2 text-xs text-white placeholder-purple-400/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* Lessons Grid Cards */}
      {filteredLessons.length === 0 ? (
        <div className="p-10 rounded-3xl bg-[#120a24] border border-purple-900/30 text-center space-y-3">
          <GraduationCap className="w-12 h-12 text-purple-500/40 mx-auto" />
          <h4 className="text-sm sm:text-base font-bold text-white">
            {isAr ? 'لم يتم العثور على دروس مطابقة' : 'No matching lessons found'}
          </h4>
          <p className="text-xs text-purple-300/70 max-w-sm mx-auto">
            {isAr
              ? 'جرّب تغيير عبارة البحث أو اختيار مادة أخرى أو أضف درساً جديداً بنفسك.'
              : 'Try adjusting your search criteria, selecting another subject, or adding a new lesson.'}
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedSubject('all');
              setFilterType('all');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-xl bg-purple-950 hover:bg-purple-900 text-purple-200 text-xs font-bold border border-purple-700/40 transition-colors"
          >
            {isAr ? 'إعادة ضبط التصفية' : 'Reset Filters'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredLessons.map((lesson) => {
            const progress = lessonProgressService.getLessonProgress(lesson.id);
            const isFav = lessonProgressService.isFavorite(lesson.id);
            const isCompleted = progress.completed;

            return (
              <div
                key={lesson.id}
                className={`group rounded-3xl p-5 border transition-all duration-200 flex flex-col justify-between relative overflow-hidden bg-[#130b26] hover:bg-[#180e30] ${
                  isCompleted
                    ? 'border-emerald-600/40 shadow-emerald-950/20'
                    : 'border-purple-800/40 hover:border-purple-600/50 shadow-xl'
                }`}
              >
                {/* Top badges */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-purple-950/70 border border-purple-700/40 text-purple-300 text-[10px] font-bold">
                      {lesson.unit}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {isCompleted && (
                        <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 text-[10px] font-bold border border-emerald-600/40">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>{isAr ? 'مكتمل' : 'Done'}</span>
                        </span>
                      )}

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          lessonProgressService.toggleFavorite(lesson.id);
                          refreshData();
                        }}
                        className={`p-1.5 rounded-xl border transition-colors ${
                          isFav
                            ? 'bg-amber-500/20 border-amber-500 text-amber-400'
                            : 'bg-black/30 border-purple-900/30 text-purple-400/60 hover:text-white'
                        }`}
                      >
                        <Star className={`w-3.5 h-3.5 ${isFav ? 'fill-amber-400' : ''}`} />
                      </button>
                    </div>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors line-clamp-2">
                      {lesson.title}
                    </h3>

                    {lesson.moroccanTrack && (
                      <p className="text-[11px] text-amber-300/80 font-medium mt-1">
                        🇲🇦 {lesson.moroccanTrack}
                      </p>
                    )}

                    <p className="text-xs text-purple-200/70 mt-2 line-clamp-2 leading-relaxed">
                      {lesson.description}
                    </p>
                  </div>
                </div>

                {/* Footer Info & Action */}
                <div className="pt-4 mt-4 border-t border-purple-900/30 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-[11px] text-purple-300/70">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-purple-400" />
                      <span>{lesson.estimatedMinutes} د</span>
                    </span>
                    {progress.quizScore !== undefined && (
                      <span className="flex items-center gap-1 text-amber-300 font-bold">
                        <Award className="w-3 h-3" />
                        <span>{progress.quizScore}/{lesson.quiz.length}</span>
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedLesson(lesson)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-900/40 cursor-pointer"
                  >
                    <span>{isAr ? 'ابدأ الدرس' : 'Start Lesson'}</span>
                    <Arrow className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Custom Lesson Modal */}
      <AddLessonModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onLessonAdded={(newLesson) => {
          refreshData();
          setSelectedLesson(newLesson);
        }}
        lang={lang}
        defaultLevel={level}
        defaultSubject={selectedSubject === 'all' ? 'math' : selectedSubject}
      />
    </div>
  );
};
