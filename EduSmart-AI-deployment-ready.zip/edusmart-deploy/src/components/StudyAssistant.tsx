import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Send, RotateCcw, Sparkles, User, AlertCircle, Trash2, CheckCircle2 } from 'lucide-react';
import { Language, EducationLevel, ChatMessage } from '../types';
import { translations } from '../i18n/translations';
import { aiService } from '../services/aiService';

export const StudyAssistant: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang, level }) => {
  const t = translations[lang].tutor;
  const isAr = lang === 'ar';

  const defaultGreeting =
    lang === 'ar'
      ? `مرحباً بك! أنا رفيقك الدراسي الذكي في EduSmart AI لمستوى (${translations[lang].levels[level]}). ما المفهوم أو المسألة التي تود فهمها أو التدرب عليها الآن؟`
      : lang === 'fr'
      ? `Bonjour ! Je suis votre tuteur académique intelligent pour le niveau ${translations[lang].levels[level]}. Quel sujet ou notion souhaitez-vous approfondir aujourd'hui ?`
      : `Hello! I am your EduSmart academic tutor adapted for ${translations[lang].levels[level]}. What lesson, concept, or homework problem would you like to explore together?`;

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(`edusmart_chat_${level}_${lang}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return [
      {
        id: 'welcome',
        sender: 'ai',
        text: defaultGreeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [thinkingStage, setThinkingStage] = useState(0);
  const [failedQuery, setFailedQuery] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const thinkingStages = isAr
    ? [
        'قراءة وتحليل السؤال الأكاديمي...',
        'استحضار مفاهيم المنهاج والدروس المقررة...',
        'صياغة الشرح التفاعلي بطريقة مبسطة ودقيقة...',
      ]
    : [
        'Parsing your academic inquiry...',
        'Recalling curriculum syllabus and concepts...',
        'Drafting clear, step-by-step pedagogical explanation...',
      ];

  // Save conversation locally to protect student data against page refresh
  useEffect(() => {
    try {
      if (messages.length > 0) {
        localStorage.setItem(`edusmart_chat_${level}_${lang}`, JSON.stringify(messages.slice(-30)));
      }
    } catch {
      // ignore storage errors
    }
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Progressive thinking status rotation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTyping) {
      setThinkingStage(0);
      interval = setInterval(() => {
        setThinkingStage((prev) => (prev < thinkingStages.length - 1 ? prev + 1 : prev));
      }, 1400);
    }
    return () => clearInterval(interval);
  }, [isTyping]);

  const handleSend = async (messageText?: string) => {
    const textToSend = (messageText || inputText).trim();
    if (!textToSend || isTyping) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setFailedQuery(null);
    setIsTyping(true);

    try {
      const reply = await aiService.askTutor(userMsg.text, level, lang);
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error('Tutor error:', err);
      setFailedQuery(textToSend);
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text:
          isAr
            ? 'تعذر الوصول المؤقت إلى خادم المعلم الذكي. تم حفظ سؤالك، يمكنك الضغط على زر إعادة المحاولة فوراً.'
            : 'Temporary connection delay with the AI Tutor. Your question has been safely preserved. Click Retry below.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleRetry = () => {
    if (!failedQuery) return;
    const retryText = failedQuery;
    setFailedQuery(null);
    handleSend(retryText);
  };

  const handleClear = () => {
    const freshWelcome: ChatMessage = {
      id: 'welcome',
      sender: 'ai',
      text: defaultGreeting,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages([freshWelcome]);
    setFailedQuery(null);
    try {
      localStorage.removeItem(`edusmart_chat_${level}_${lang}`);
    } catch {
      // ignore
    }
  };

  const copyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-200px)] min-h-[580px] flex flex-col bg-[#120b24] rounded-3xl shadow-2xl border border-purple-900/40 overflow-hidden relative backdrop-blur-md">
      {/* Top Header Bar */}
      <div className="px-5 py-4 bg-[#180e33]/90 border-b border-purple-900/30 flex justify-between items-center z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-500 text-white flex items-center justify-center font-bold shadow-lg shadow-purple-600/30">
            <Bot className="w-5 h-5 text-purple-100" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">{t.title}</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                Turbo Flash ⚡
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-purple-300/70 font-medium mt-0.5">
              <span>{translations[lang].levels[level]}</span>
              <span>•</span>
              <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                {isAr ? 'جاهز للاستجابة السريعة' : 'Fast Response Ready'}
              </span>
            </div>
          </div>
        </div>

        <button
          onClick={handleClear}
          title={t.clearChat}
          className="text-xs text-purple-300/60 hover:text-red-400 px-3 py-1.5 rounded-xl border border-purple-900/40 hover:bg-purple-900/20 transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{t.clearChat}</span>
        </button>
      </div>

      {/* Preset Fast Starters */}
      <div className="px-4 py-2.5 bg-[#0e071c] border-b border-purple-900/20 overflow-x-auto flex items-center gap-2 text-xs scrollbar-none">
        <span className="text-purple-400 font-semibold whitespace-nowrap text-[11px] flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-purple-400" />
          {t.presetPrompts}:
        </span>
        {[t.prompt1, t.prompt2, t.prompt3].map((prompt, i) => (
          <button
            key={i}
            onClick={() => handleSend(prompt)}
            disabled={isTyping}
            className="whitespace-nowrap px-3 py-1.5 rounded-full bg-purple-950/60 hover:bg-purple-800/50 text-purple-200 border border-purple-700/30 hover:border-purple-500/50 font-medium transition-all text-[11px] cursor-pointer disabled:opacity-50"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-gradient-to-b from-[#120b24] to-[#0c0719]">
        {messages.map((m) => {
          const isAi = m.sender === 'ai';
          const isErrorMsg = m.text.includes('تعذر الوصول') || m.text.includes('Temporary connection');

          return (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
              className={`flex ${isAi ? 'justify-start' : 'justify-end'}`}
            >
              <div
                className={`max-w-[88%] sm:max-w-[82%] rounded-3xl p-4 sm:p-5 text-xs sm:text-sm shadow-xl leading-relaxed relative group ${
                  isAi
                    ? isErrorMsg
                      ? 'bg-red-950/40 text-red-200 border border-red-500/40 rounded-tl-none rtl:rounded-tr-none rtl:rounded-tl-3xl'
                      : 'bg-[#1b1035] text-purple-100 border border-purple-800/40 rounded-tl-none rtl:rounded-tr-none rtl:rounded-tl-3xl shadow-purple-950/50'
                    : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-tr-none rtl:rounded-tl-none rtl:rounded-tr-3xl shadow-purple-600/20'
                }`}
              >
                <div className="flex items-center justify-between gap-3 mb-2 opacity-70 text-[10px] sm:text-[11px]">
                  <div className="flex items-center gap-1.5 font-medium">
                    {isAi ? (
                      <>
                        <Bot className="w-3.5 h-3.5 text-purple-300" />
                        <span>EduSmart AI Tutor</span>
                      </>
                    ) : (
                      <>
                        <User className="w-3.5 h-3.5 text-purple-200" />
                        <span>{isAr ? 'أنت' : 'You'}</span>
                      </>
                    )}
                    <span>•</span>
                    <span>{m.timestamp}</span>
                  </div>

                  {isAi && !isErrorMsg && (
                    <button
                      onClick={() => copyMessage(m.id, m.text)}
                      className="opacity-0 group-hover:opacity-100 hover:text-white transition-opacity text-[10px] flex items-center gap-1 cursor-pointer bg-purple-900/40 px-2 py-0.5 rounded-md"
                    >
                      {copiedId === m.id ? (
                        <>
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">{isAr ? 'تم النسخ' : 'Copied'}</span>
                        </>
                      ) : (
                        <span>{isAr ? 'نسخ' : 'Copy'}</span>
                      )}
                    </button>
                  )}
                </div>

                <p className="whitespace-pre-line leading-relaxed font-sans">{m.text}</p>
              </div>
            </motion.div>
          );
        })}

        {/* Dynamic Thinking & Processing Status Indicator */}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-start"
          >
            <div className="bg-[#1b1035] border border-purple-500/40 rounded-2xl rounded-tl-none rtl:rounded-tr-none rtl:rounded-tl-2xl p-4 shadow-xl max-w-md w-full">
              <div className="flex items-center gap-3">
                <div className="relative w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-purple-300 animate-pulse" />
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-purple-400 animate-ping" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between text-xs font-semibold text-purple-200 mb-1">
                    <span>{thinkingStages[thinkingStage]}</span>
                    <span className="text-[10px] text-purple-400 font-mono">
                      {Math.round(((thinkingStage + 1) / thinkingStages.length) * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-purple-950 rounded-full h-1.5 overflow-hidden">
                    <motion.div
                      className="bg-gradient-to-r from-purple-500 to-indigo-400 h-full rounded-full"
                      initial={{ width: '20%' }}
                      animate={{ width: `${((thinkingStage + 1) / thinkingStages.length) * 100}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Failed Query Retry Banner */}
        {failedQuery && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-amber-950/40 border border-amber-500/40 rounded-2xl flex items-center justify-between gap-3 text-xs sm:text-sm text-amber-200"
          >
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
              <span>
                {isAr
                  ? 'تم الاحتفاظ بسؤالك لمنع ضياعه بسبب انقطاع الاتصال.'
                  : 'Your question was saved so you will not lose it.'}
              </span>
            </div>
            <button
              onClick={handleRetry}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl flex items-center gap-1.5 shrink-0 transition-colors shadow-lg shadow-amber-600/20 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{isAr ? 'إعادة المحاولة الآن' : 'Retry Now'}</span>
            </button>
          </motion.div>
        )}

        <div ref={chatBottomRef} />
      </div>

      {/* Input Form with guaranteed text persistence */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="p-3 sm:p-4 bg-[#180e33]/90 border-t border-purple-900/30 flex gap-2.5 z-10"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={t.placeholder}
          disabled={isTyping}
          className="flex-1 rounded-2xl bg-[#0d071a] border border-purple-900/50 px-4 py-3.5 text-xs sm:text-sm text-purple-100 placeholder:text-purple-400/40 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all disabled:opacity-60"
        />
        <button
          type="submit"
          disabled={!inputText.trim() || isTyping}
          className="px-5 sm:px-6 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:from-purple-950 disabled:to-purple-950 disabled:text-purple-600/50 text-white font-semibold text-xs sm:text-sm transition-all shadow-lg shadow-purple-600/30 flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed shrink-0"
        >
          <span className="hidden sm:inline">{t.send}</span>
          <Send className="w-4 h-4 rtl:rotate-180" />
        </button>
      </form>
    </div>
  );
};
