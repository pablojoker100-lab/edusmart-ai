import React from 'react';

interface MindLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showSlogan?: boolean;
  className?: string;
  lang?: string;
}

export const MindLogo: React.FC<MindLogoProps> = ({
  size = 'md',
  showText = true,
  showSlogan = false,
  className = '',
  lang = 'ar',
}) => {
  const isAr = lang === 'ar';

  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  const textSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-4xl',
  };

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Luminous Emblem */}
      <div className={`relative ${iconSizes[size]} shrink-0 rounded-2xl bg-gradient-to-tr from-[#1f0b3d] via-[#100726] to-[#080314] p-0.5 shadow-xl shadow-purple-950/60 border border-purple-500/40 group`}>
        {/* Ambient Glow */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-cyan-500/20 via-purple-600/30 to-pink-500/20 blur-md -z-10 opacity-75 group-hover:opacity-100 transition-opacity" />
        
        <svg
          viewBox="0 0 64 64"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full p-1"
        >
          <defs>
            <linearGradient id="logoGrad" x1="12" y1="12" x2="52" y2="52" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="45%" stopColor="#a855f7" />
              <stop offset="100%" stopColor="#ec4899" />
            </linearGradient>
            <linearGradient id="innerBridgeGrad" x1="20" y1="30" x2="44" y2="40" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#c084fc" />
            </linearGradient>
          </defs>

          {/* Neural Brain / Synapse 'M' Shape */}
          <path
            d="M16 43 V26 C16 19.5 22 17 28 22 L32 26 L36 22 C42 17 48 19.5 48 26 V43"
            stroke="url(#logoGrad)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          <path
            d="M21 34 C25 31 28 33 32 37 C36 33 39 31 43 34"
            stroke="url(#innerBridgeGrad)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          <path
            d="M25 44 L32 38 L39 44"
            stroke="url(#logoGrad)"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Neural Synapse Dots */}
          <circle cx="16" cy="26" r="3" fill="#38bdf8" />
          <circle cx="48" cy="26" r="3" fill="#ec4899" />
          <circle cx="28" cy="22" r="2.2" fill="#a855f7" />
          <circle cx="36" cy="22" r="2.2" fill="#a855f7" />
          <circle cx="16" cy="43" r="2.5" fill="#c084fc" />
          <circle cx="48" cy="43" r="2.5" fill="#c084fc" />

          {/* Glowing AI Core */}
          <circle cx="32" cy="26" r="3.5" fill="#ffffff" />
          <circle cx="32" cy="26" r="1.5" fill="#38bdf8" />
        </svg>
      </div>

      {/* Typography Zone */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 leading-none">
            <span className={`font-black tracking-tight text-white ${textSizes[size]}`}>
              Mind
            </span>
            <span className={`font-black tracking-tight bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent ${textSizes[size]}`}>
              AI
            </span>
          </div>

          {showSlogan && (
            <p className="text-[11px] font-semibold text-purple-300/80 mt-1 truncate">
              {isAr ? 'عقلك الذكي نحو مستقبل أفضل.' : 'Your intelligent mind towards a brighter future.'}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
