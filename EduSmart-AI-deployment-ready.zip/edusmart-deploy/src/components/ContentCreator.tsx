import React, { useState } from 'react';
import { motion } from 'motion/react';
import { FileText, Sparkles, Copy, Check, Hash, Share2, Megaphone, Video, RotateCcw } from 'lucide-react';
import { Language, EducationLevel, ContentResponse } from '../types';
import { aiService } from '../services/aiService';

export const ContentCreator: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang }) => {
  const isAr = lang === 'ar';

  const contentTypes = [
    { id: 'article', label: isAr ? 'مقالة كاملة' : 'Full Article', icon: FileText },
    { id: 'social', label: isAr ? 'منشور تواصل (LinkedIn/X)' : 'Social Post', icon: Share2 },
    { id: 'video', label: isAr ? 'سيناريو فيديو (Reels/TikTok)' : 'Video Script', icon: Video },
    { id: 'ad', label: isAr ? 'نص إعلاني وتسويقي' : 'Ad Copy', icon: Megaphone },
  ];

  const tones = [
    { id: 'engaging', label: isAr ? 'حماسي وجذاب' : 'Engaging & Vibrant' },
    { id: 'academic', label: isAr ? 'أكاديمي رصين' : 'Academic & Formal' },
    { id: 'professional', label: isAr ? 'مهني واحترافي' : 'Professional' },
    { id: 'storytelling', label: isAr ? 'قصصي وسردي' : 'Storytelling' },
  ];

  const presets = [
    isAr ? 'كيف تنظم وقتك للدراسة والتفوق بدون ضغط وتوتر' : 'How to optimize study habits for top grades without burnout',
    isAr ? 'أهمية تعلم لغات البرمجة والذكاء الاصطناعي في 2026' : 'Why learning AI engineering is essential in 2026',
    isAr ? 'نصائح عملية لاجتياز الامتحانات الوطنية بتفوق' : 'Actionable revision hacks for national baccalaureate exams',
    isAr ? 'قصة نجاح ملهمة عن التحول من الفشل إلى الريادة' : 'Inspiring storytelling post on overcoming early adversity',
  ];

  const [selectedType, setSelectedType] = useState<'article' | 'social' | 'video' | 'ad'>('article');
  const [selectedTone, setSelectedTone] = useState('engaging');
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [content, setContent] = useState<ContentResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCreate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const res = await aiService.generateContent({
        topic: topic.trim(),
        contentType: selectedType,
        tone: selectedTone,
        lang,
      });
      setContent(res);
    } catch {
      setError(isAr ? 'تعذر إنشاء المحتوى. يرجى إعادة المحاولة.' : 'Content generation failed. Please retry.');
    } finally {
      setIsLoading(false);
    }
  };

  const copyFullContent = () => {
    if (!content) return;
    const fullText = `${content.title}\n\n${content.hook}\n\n${content.body}\n\n${content.callToAction}\n\n${content.hashtags?.join(' ')}`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header Input Box */}
      <div className="bg-[#120b24] rounded-3xl p-6 sm:p-8 border border-purple-900/40 shadow-xl relative overflow-hidden">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-fuchsia-600 to-pink-600 flex items-center justify-center text-white shadow-lg shadow-pink-900/40">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isAr ? 'صانع المحتوى والمقالات الاحترافي' : 'Content & Article Creator'}
            </h2>
            <p className="text-xs sm:text-sm text-purple-300/70 mt-0.5">
              {isAr
                ? 'كتابة مقالات متكاملة، منشورات سوشيال ميديا جذابة، وسيناريوهات فيديو تلفت الأنظار'
                : 'Craft captivating articles, viral social copy, and high-retention video scripts'}
            </p>
          </div>
        </div>

        {/* Content Type Selection */}
        <div className="flex flex-wrap gap-2 pt-4">
          {contentTypes.map((type) => {
            const Icon = type.icon;
            return (
              <button
                key={type.id}
                type="button"
                onClick={() => setSelectedType(type.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  selectedType === type.id
                    ? 'bg-gradient-to-r from-fuchsia-600 to-pink-600 text-white shadow-md'
                    : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 border border-purple-900/30'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{type.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tone Selector */}
        <div className="pt-4 flex items-center gap-2 overflow-x-auto scrollbar-none pb-1">
          <span className="text-xs font-bold text-purple-400 shrink-0">{isAr ? 'النبرة:' : 'Tone:'}</span>
          {tones.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSelectedTone(t.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedTone === t.id
                  ? 'bg-purple-600 text-white border border-purple-400 shadow-sm'
                  : 'bg-[#180d33] hover:bg-purple-900/40 text-purple-300/80 border border-purple-900/30'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Presets */}
        <div className="pt-4">
          <span className="text-[11px] font-bold text-purple-400/80 block mb-2">
            {isAr ? 'مواضيع شائعة ومقترحة:' : 'Suggested Prompts:'}
          </span>
          <div className="flex flex-wrap gap-2">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setTopic(preset)}
                className="text-xs bg-[#190f33] hover:bg-purple-900/50 text-purple-200 px-3 py-1.5 rounded-xl border border-purple-800/30 text-start cursor-pointer transition-all"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleCreate} className="mt-5 space-y-4">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            disabled={isLoading}
            placeholder={
              isAr
                ? 'أدخل موضوع المقال أو الفكرة التي تريد تحويلها إلى محتوى مبهر...'
                : 'Enter the topic or core message you want to turn into impactful content...'
            }
            className="w-full bg-[#0a0515] border border-purple-900/50 focus:border-pink-500 rounded-2xl px-4 py-3.5 text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none focus:ring-1 focus:ring-pink-500 transition-all font-medium"
          />

          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={!topic.trim() || isLoading}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-fuchsia-600 via-pink-600 to-purple-600 hover:from-fuchsia-500 hover:to-purple-500 disabled:opacity-40 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-pink-950/60 flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isLoading ? (isAr ? 'جاري صياغة المحتوى...' : 'Writing Content...') : (isAr ? 'إنشاء المحتوى فوراً' : 'Create Content')}</span>
            </button>

            {topic && !isLoading && (
              <button
                type="button"
                onClick={() => {
                  setTopic('');
                  setContent(null);
                  setError(null);
                }}
                className="px-4 py-3 rounded-2xl bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 text-xs font-semibold cursor-pointer"
              >
                {isAr ? 'مسح' : 'Clear'}
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 bg-red-950/40 border border-red-500/40 rounded-2xl flex items-center justify-between text-xs text-red-200">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => handleCreate()}
            className="px-3 py-1 bg-red-600 text-white rounded-xl font-bold flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
          </button>
        </div>
      )}

      {/* Content Result */}
      {content && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#120b24] rounded-3xl p-6 sm:p-8 border border-purple-900/40 shadow-2xl space-y-6"
        >
          {/* Header Action */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-purple-900/30">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-pink-400 bg-pink-950/60 border border-pink-500/30 px-3 py-1 rounded-full">
                {content.type}
              </span>
              <h3 className="text-lg sm:text-xl font-black text-white mt-2">{content.title}</h3>
            </div>

            <button
              type="button"
              onClick={copyFullContent}
              className="px-4 py-2 rounded-xl bg-purple-900/60 hover:bg-purple-800/60 border border-purple-700/40 text-purple-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">{isAr ? 'تم نسخ المحتوى كاملاً' : 'Copied!'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-pink-400" />
                  <span>{isAr ? 'نسخ المحتوى بالكامل' : 'Copy Full Content'}</span>
                </>
              )}
            </button>
          </div>

          {/* Catchy Hook Callout */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-pink-950/40 via-purple-950/40 to-transparent border-l-4 rtl:border-l-0 rtl:border-r-4 border-pink-500">
            <span className="text-[11px] font-black text-pink-300 uppercase tracking-wider block mb-1">
              🎯 {isAr ? 'المقدمة الجاذبة (The Hook):' : 'The Hook:'}
            </span>
            <p className="text-sm font-bold text-white leading-relaxed">{content.hook}</p>
          </div>

          {/* Formatted Body */}
          <div className="p-5 rounded-2xl bg-[#090412] border border-purple-900/30 text-xs sm:text-sm text-purple-100 leading-relaxed whitespace-pre-line select-all">
            {content.body}
          </div>

          {/* Call to Action */}
          <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 text-xs sm:text-sm text-emerald-200 font-semibold">
            <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-1">
              📣 {isAr ? 'الدعوة لاتخاذ إجراء (Call to Action):' : 'Call to Action:'}
            </span>
            {content.callToAction}
          </div>

          {/* Hashtags */}
          {content.hashtags && content.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-2">
              {content.hashtags.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded-full bg-purple-950/60 border border-purple-800/40 text-purple-300 text-xs font-semibold flex items-center gap-1"
                >
                  <Hash className="w-3 h-3 text-pink-400" />
                  {tag.replace(/^#/, '')}
                </span>
              ))}
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};
