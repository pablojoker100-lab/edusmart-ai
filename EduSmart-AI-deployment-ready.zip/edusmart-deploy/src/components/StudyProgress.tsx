import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { TrendingUp, Clock, Flame, Target, CheckCircle2, BarChart3, ArrowUpRight, BookOpen, Trash2, Calendar, GraduationCap } from 'lucide-react';
import { Language, EducationLevel, ActiveTab, UserProfile, UserProgressData } from '../types';
import { translations } from '../i18n/translations';
import { authService } from '../services/authService';
import { lessonProgressService } from '../services/lessonProgressService';

interface StudyProgressProps {
  lang: Language;
  level: EducationLevel;
  currentUser: UserProfile | null;
  onNavigate: (tab: ActiveTab) => void;
}

export const StudyProgress: React.FC<StudyProgressProps> = ({
  lang,
  level,
  currentUser,
  onNavigate,
}) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';

  const [progress, setProgress] = useState<UserProgressData>({
    solvedCount: 0,
    quizzesTaken: 0,
    averageScore: 0,
    history: [],
  });
  const [clearing, setClearing] = useState(false);
  const [lessonStats, setLessonStats] = useState(() => lessonProgressService.getStats());

  useEffect(() => {
    authService.getUserProgress().then(setProgress);
    setLessonStats(lessonProgressService.getStats());
  }, [currentUser]);

  const handleClearHistory = async () => {
    if (!window.confirm(isRtl ? 'هل أنت متأكد من مسح سجل الدراسة؟' : 'Are you sure you want to clear your study history?')) {
      return;
    }
    setClearing(true);
    await authService.clearStudyHistory();
    setProgress((prev) => ({ ...prev, history: [] }));
    setClearing(false);
  };

  // Weekly study distribution mock
  const weekDays = [
    { day: isRtl ? 'السبت' : 'Sat', hours: 2.5, percent: 70 },
    { day: isRtl ? 'الأحد' : 'Sun', hours: 3.2, percent: 85 },
    { day: isRtl ? 'الاثنين' : 'Mon', hours: 1.8, percent: 50 },
    { day: isRtl ? 'الثلاثاء' : 'Tue', hours: 2.8, percent: 75 },
    { day: isRtl ? 'الأربعاء' : 'Wed', hours: 3.5, percent: 92 },
    { day: isRtl ? 'الخميس' : 'Thu', hours: 2.1, percent: 60 },
    { day: isRtl ? 'الجمعة' : 'Fri', hours: 1.5, percent: 40 },
  ];

  // Subject mastery indicators
  const masteryData = [
    { name: t.subjects.math, percent: 88, color: 'from-purple-500 to-indigo-600' },
    { name: t.subjects.physics, percent: 82, color: 'from-violet-500 to-purple-600' },
    { name: t.subjects.biology, percent: 94, color: 'from-fuchsia-500 to-pink-600' },
    { name: t.subjects.languagesSubject, percent: 86, color: 'from-purple-600 to-violet-500' },
    { name: t.subjects.cs, percent: 96, color: 'from-indigo-500 to-purple-500' },
  ];

  // Calculated XP
  const totalXp = (progress.solvedCount * 25) + (progress.quizzesTaken * 50) + 120;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-purple-950 via-[#130b24] to-[#0a0714] border border-purple-900/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 end-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/40 border border-purple-500/30 text-purple-300 text-xs font-semibold">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{t.progress.title}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {t.progress.title}
            </h2>
            <p className="text-xs sm:text-sm text-purple-200/80 leading-relaxed">
              {t.progress.subtitle}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2.5 rounded-2xl bg-purple-950/80 border border-purple-500/30 text-center shadow-lg">
              <span className="text-xs text-purple-300/80 block font-medium">{t.progress.totalXp}</span>
              <span className="text-xl sm:text-2xl font-black text-purple-400">
                {totalXp} XP
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Solved Problems */}
        <div className="p-5 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-purple-400">
            <Target className="w-5 h-5" />
            <span className="text-[10px] uppercase font-bold text-purple-300/60">Live</span>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">
            {progress.solvedCount > 0 ? progress.solvedCount : '0'}
          </p>
          <span className="text-xs text-purple-200/70 font-semibold block">
            {t.progress.solvedRate}
          </span>
        </div>

        {/* Quizzes Taken */}
        <div className="p-5 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-violet-400">
            <CheckCircle2 className="w-5 h-5" />
            <span className="text-[10px] uppercase font-bold text-violet-300/60">Live</span>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">
            {progress.quizzesTaken > 0 ? progress.quizzesTaken : '0'}
          </p>
          <span className="text-xs text-purple-200/70 font-semibold block">
            {t.progress.quizzesRate}
          </span>
        </div>

        {/* Average Score */}
        <div className="p-5 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-fuchsia-400">
            <BarChart3 className="w-5 h-5" />
            <span className="text-[10px] uppercase font-bold text-fuchsia-300/60">Mastery</span>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">
            {progress.quizzesTaken > 0 ? `${progress.averageScore}%` : '95%'}
          </p>
          <span className="text-xs text-purple-200/70 font-semibold block">
            {t.progress.accuracyRate}
          </span>
        </div>

        {/* Study Streak */}
        <div className="p-5 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-2">
          <div className="flex items-center justify-between text-amber-400">
            <Flame className="w-5 h-5 text-amber-400" />
            <span className="text-[10px] uppercase font-bold text-amber-300/60">Consistency</span>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">
            5 {isRtl ? 'أيام' : 'days'}
          </p>
          <span className="text-xs text-purple-200/70 font-semibold block">
            {t.progress.streakDays}
          </span>
        </div>
      </div>

      {/* Moroccan Curriculum Lessons Progress Card */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-950/80 via-[#180e32] to-[#0d071d] border border-purple-700/50 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-purple-900/60 border border-purple-500/40 flex items-center justify-center text-purple-200">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {isRtl ? 'تقدمك في دروس المنهاج المغربي' : 'Moroccan Curriculum Progress'}
              </h3>
              <span className="text-xs text-purple-300/70">
                {isRtl ? `تم إنجاز ${lessonStats.completed} من أصل ${lessonStats.total} درساً (${lessonStats.incomplete} درساً قيد التعلم)` : `${lessonStats.completed} of ${lessonStats.total} lessons completed`}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('lessons')}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-900/40 cursor-pointer"
          >
            {isRtl ? 'متابعة الدروس' : 'Continue Lessons'}
          </button>
        </div>

        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-xs font-bold text-purple-200">
            <span>{isRtl ? 'نسبة استكمال المقررات:' : 'Overall Curriculum Completion:'}</span>
            <span className="text-purple-300 font-mono text-sm">{lessonStats.percentage}%</span>
          </div>
          <div className="w-full h-3 bg-black/40 rounded-full overflow-hidden p-0.5 border border-purple-800/40">
            <div
              className="h-full rounded-full bg-gradient-to-r from-purple-600 via-fuchsia-500 to-emerald-400 transition-all duration-700"
              style={{ width: `${Math.max(lessonStats.percentage, 5)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Analytics Grid: Weekly Chart & Subject Mastery */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Study Time Chart */}
        <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Clock className="w-5 h-5 text-purple-400" />
              <div>
                <h3 className="text-base font-bold text-white">{t.progress.weeklyHours}</h3>
                <span className="text-xs text-purple-300/70">17.4 {t.progress.hoursSuffix}</span>
              </div>
            </div>
            <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-purple-900/40 text-purple-300 border border-purple-700/30">
              {isRtl ? 'هذا الأسبوع' : 'This Week'}
            </span>
          </div>

          {/* Bar Chart */}
          <div className="pt-4 flex items-end justify-between gap-2 h-44">
            {weekDays.map((item, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                <span className="text-[10px] text-purple-300 font-medium">{item.hours}h</span>
                <div className="w-full max-w-[36px] bg-purple-950/60 rounded-xl overflow-hidden p-1 flex items-end h-28">
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${item.percent}%` }}
                    transition={{ duration: 0.6, delay: idx * 0.08 }}
                    className="w-full rounded-lg bg-gradient-to-t from-purple-700 to-violet-400 shadow-md"
                  />
                </div>
                <span className="text-[11px] font-semibold text-purple-200/80">{item.day}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Subject Mastery Progress Bars */}
        <div className="p-6 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <BookOpen className="w-5 h-5 text-violet-400" />
              <div>
                <h3 className="text-base font-bold text-white">{t.progress.masteryOverview}</h3>
                <span className="text-xs text-purple-300/70">{translations[lang].levels[level]}</span>
              </div>
            </div>
            <span className="text-xs font-bold text-emerald-400">
              90% {isRtl ? 'المتوسط' : 'Avg'}
            </span>
          </div>

          <div className="space-y-4 pt-2">
            {masteryData.map((item, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-purple-100">{item.name}</span>
                  <span className="text-purple-300">{item.percent}%</span>
                </div>
                <div className="h-2.5 w-full bg-purple-950/70 rounded-full overflow-hidden p-0.5 border border-purple-900/30">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${item.percent}%` }}
                    transition={{ duration: 0.8, delay: idx * 0.1 }}
                    className={`h-full rounded-full bg-gradient-to-r ${item.color}`}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Saved Study Activities Log */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#130b24] border border-purple-900/30 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <Calendar className="w-5 h-5 text-purple-400" />
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                {t.progress.recentTimeline}
              </h3>
              <p className="text-xs text-purple-300/70">
                {progress.history.length > 0
                  ? (isRtl ? `تم حفظ ${progress.history.length} نشاط في ملفك الدراسي` : `${progress.history.length} activities logged`)
                  : t.progress.noHistory}
              </p>
            </div>
          </div>

          {progress.history.length > 0 && (
            <button
              type="button"
              disabled={clearing}
              onClick={handleClearHistory}
              className="px-3 py-1.5 rounded-xl bg-purple-950/60 hover:bg-red-950/50 border border-purple-800/40 hover:border-red-700/50 text-purple-300 hover:text-red-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{isRtl ? 'مسح السجل' : 'Clear History'}</span>
            </button>
          )}
        </div>

        {progress.history.length === 0 ? (
          <div className="py-10 text-center rounded-2xl bg-black/30 border border-dashed border-purple-900/40 p-6 space-y-3">
            <span className="text-4xl block">📚</span>
            <p className="text-sm font-bold text-white">{t.progress.noHistory}</p>
            <div className="pt-2 flex items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => onNavigate('solver')}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                📷 {t.nav.solver}
              </button>
              <button
                type="button"
                onClick={() => onNavigate('quiz')}
                className="px-4 py-2 rounded-xl bg-purple-950 hover:bg-purple-900 text-purple-200 text-xs font-bold border border-purple-700/40 transition-colors cursor-pointer"
              >
                🎯 {t.nav.quiz}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-2.5 pt-2">
            {progress.history.slice(0, 10).map((act) => (
              <div
                key={act.id}
                className="p-3.5 sm:p-4 rounded-2xl bg-black/40 hover:bg-purple-950/40 border border-purple-900/30 transition-colors flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-purple-950/80 border border-purple-700/30 flex items-center justify-center text-lg flex-shrink-0">
                    {act.type === 'solve' ? '📷' : act.type === 'quiz' ? '🎯' : act.type === 'summary' ? '📑' : '💡'}
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-white text-xs sm:text-sm truncate">{act.title}</p>
                    <div className="flex items-center gap-2 mt-0.5 text-[11px] text-purple-300/60">
                      <span>{new Date(act.timestamp || act.date || Date.now()).toLocaleDateString(isRtl ? 'ar-EG' : 'en-US')}</span>
                      {act.subject && (
                        <span className="px-2 py-0.5 rounded-md bg-purple-900/40 text-purple-300 font-medium">
                          {act.subject}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {act.score && (
                  <span className="flex-shrink-0 px-3 py-1 rounded-xl bg-purple-950/90 border border-purple-500/40 text-purple-300 font-extrabold text-xs sm:text-sm shadow-sm">
                    {act.score}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
