import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard,
  MessageSquare,
  Code2,
  Lightbulb,
  FileText,
  Mail,
  Camera,
  Cpu,
  BookOpen,
  GraduationCap,
  Layers,
  Sparkles,
  HelpCircle,
  TrendingUp,
  Award,
  User,
  Settings,
  X,
  Share2,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { ActiveTab, Language } from '../types';
import { translations } from '../i18n/translations';
import { MindLogo } from './MindLogo';

interface AppSidebarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  lang: Language;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const AppSidebar: React.FC<AppSidebarProps> = ({
  activeTab,
  onTabChange,
  lang,
  isOpenMobile,
  onCloseMobile,
}) => {
  const isAr = lang === 'ar';
  const t = translations[lang].nav;

  // Grouped Navigation Items
  const navSections = [
    {
      title: isAr ? 'الرئيسية' : 'Overview',
      items: [
        { id: 'dashboard' as ActiveTab, label: t.dashboard, icon: LayoutDashboard, badge: null },
      ],
    },
    {
      title: isAr ? 'منصة الذكاء الاصطناعي' : 'Mind AI Platform',
      items: [
        { id: 'chat' as ActiveTab, label: t.chat, icon: MessageSquare, badge: 'Pro' },
        { id: 'code' as ActiveTab, label: t.code, icon: Code2, badge: 'Turbo' },
        { id: 'ideas' as ActiveTab, label: t.ideas, icon: Lightbulb, badge: null },
        { id: 'content' as ActiveTab, label: t.content, icon: FileText, badge: null },
        { id: 'letters' as ActiveTab, label: t.letters, icon: Mail, badge: null },
      ],
    },
    {
      title: isAr ? 'المساعد الدراسي والمنهاج' : 'Academic & Study',
      items: [
        { id: 'solver' as ActiveTab, label: t.solver, icon: Camera, badge: 'Vision' },
        { id: 'explainer' as ActiveTab, label: t.explainer, icon: Cpu, badge: null },
        { id: 'lessons' as ActiveTab, label: t.lessons, icon: GraduationCap, badge: isAr ? 'المغرب' : 'Curriculum' },
        { id: 'subjects' as ActiveTab, label: t.subjects, icon: BookOpen, badge: null },
        { id: 'tutor' as ActiveTab, label: t.tutor, icon: Sparkles, badge: null },
        { id: 'summarizer' as ActiveTab, label: t.summarizer, icon: Layers, badge: null },
        { id: 'writing' as ActiveTab, label: t.writing, icon: FileText, badge: null },
        { id: 'quiz' as ActiveTab, label: t.quiz, icon: HelpCircle, badge: null },
      ],
    },
    {
      title: isAr ? 'التقدم والحساب' : 'Account & System',
      items: [
        { id: 'progress' as ActiveTab, label: t.progress, icon: TrendingUp, badge: null },
        { id: 'achievements' as ActiveTab, label: t.achievements, icon: Award, badge: null },
        { id: 'profile' as ActiveTab, label: t.profile, icon: User, badge: null },
        { id: 'settings' as ActiveTab, label: t.settings, icon: Settings, badge: null },
      ],
    },
  ];

  const handleSelect = (tab: ActiveTab) => {
    onTabChange(tab);
    onCloseMobile();
  };

  const SidebarContent = (
    <div className="h-full flex flex-col bg-[#080412]/95 border-e border-purple-900/40 select-none">
      {/* Brand Top Header */}
      <div className="p-5 border-b border-purple-900/40 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <MindLogo size="sm" showText={false} lang={lang} />
          <div>
            <div className="flex items-center gap-1.5 leading-none">
              <span className="text-base font-black text-white">Mind</span>
              <span className="text-base font-black bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">AI</span>
            </div>
            <p className="text-[10px] text-purple-300/80 font-bold mt-1 truncate max-w-[160px]">
              {isAr ? 'عقلك الذكي نحو مستقبل أفضل.' : 'Your intelligent mind.'}
            </p>
          </div>
        </div>

        {/* Mobile Close Button */}
        <button
          type="button"
          onClick={onCloseMobile}
          className="md:hidden p-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 hover:text-white border border-purple-800/40"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Nav Scroll Area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-5 scrollbar-none">
        {navSections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-1">
            <span className="text-[10px] font-bold text-purple-400/60 uppercase tracking-wider block px-3 mb-1.5">
              {section.title}
            </span>
            {section.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelect(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-bold transition-all cursor-pointer group ${
                    isActive
                      ? 'bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-600 text-white shadow-lg shadow-purple-950/80'
                      : 'text-purple-300/80 hover:bg-purple-950/50 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                        isActive ? 'text-cyan-200' : 'text-purple-400/80'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`px-2 py-0.5 rounded-full text-[9px] font-black ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-cyan-950/60 border border-cyan-500/30 text-cyan-300'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Footer System Status */}
      <div className="p-3.5 border-t border-purple-900/40 bg-[#06020d]">
        <div className="flex items-center justify-between text-[11px] text-purple-300/80">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="font-semibold">{isAr ? 'متصل بالسحابة' : 'Cloud Ready'}</span>
          </div>
          <span className="text-[10px] font-mono text-purple-400/60">Mind AI v2.5</span>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 sticky top-14 h-[calc(100vh-56px)] z-20">
        {SidebarContent}
      </aside>

      {/* Mobile Slide-in Drawer with Backdrop */}
      <AnimatePresence>
        {isOpenMobile && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onCloseMobile}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            />

            {/* Drawer */}
            <motion.div
              initial={{ x: isAr ? '100%' : '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: isAr ? '100%' : '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="relative w-72 max-w-[85vw] h-full shadow-2xl z-10"
            >
              {SidebarContent}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
