import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Code2, Sparkles, Copy, Check, Play, Terminal, Cpu, CheckCircle2, RotateCcw } from 'lucide-react';
import { Language, EducationLevel, CodeResponse } from '../types';
import { aiService } from '../services/aiService';

export const CodingAssistant: React.FC<{ lang: Language; level: EducationLevel }> = ({ lang }) => {
  const isAr = lang === 'ar';

  const languages = ['Python', 'JavaScript', 'TypeScript', 'C++', 'Java', 'HTML/CSS', 'SQL', 'Go', 'PHP'];
  const taskTypes: { id: 'generate' | 'debug' | 'explain'; label: string }[] = [
    { id: 'generate', label: isAr ? 'كتابة وبرمجة الحل' : 'Write / Generate Code' },
    { id: 'debug', label: isAr ? 'تصحيح واكتشاف الأخطاء' : 'Debug & Fix Errors' },
    { id: 'explain', label: isAr ? 'شرح خوارزمية وكود' : 'Explain Logic & Complexity' },
  ];

  const presets = [
    isAr ? 'خوارزمية البحث الثنائي Binary Search في مصفوفة مرتبة' : 'Binary search algorithm on sorted array',
    isAr ? 'دالة للتحقق من الأعداد الأولية Prime Numbers بكفاءة O(sqrt(n))' : 'Efficient prime checker function',
    isAr ? 'كود React Hook مخصص لإدارة التخزين المحلي useLocalStorage' : 'Custom React hook useLocalStorage with TypeScript',
    isAr ? 'استعلام SQL لجلب أعلى 5 طلاب حسب المعدل التراكمي' : 'SQL query to select top 5 students by GPA with ranking',
  ];

  const [selectedLang, setSelectedLang] = useState('Python');
  const [selectedTask, setSelectedTask] = useState<'generate' | 'debug' | 'explain'>('generate');
  const [codePrompt, setCodePrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<CodeResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!codePrompt.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const data = await aiService.generateCodingSolution({
        prompt: codePrompt.trim(),
        language: selectedLang,
        taskType: selectedTask,
        lang,
      });
      setResult(data);
    } catch {
      setError(isAr ? 'تعذر الاتصال بخدمة البرمجة الذكية. يرجى إعادة المحاولة.' : 'Coding service delay. Please retry.');
    } finally {
      setIsLoading(false);
    }
  };

  const copyCode = () => {
    if (!result?.code) return;
    navigator.clipboard.writeText(result.code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header Box */}
      <div className="bg-[#120b24] rounded-3xl p-6 sm:p-8 border border-purple-900/40 shadow-xl relative overflow-hidden">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-900/40">
            <Code2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isAr ? 'مساعد البرمجة وهندسة البرمجيات' : 'Coding & Engineering Assistant'}
            </h2>
            <p className="text-xs sm:text-sm text-purple-300/70 mt-0.5">
              {isAr
                ? 'توليد وشرح وتصحيح الأكواد بجميع لغات البرمجة مع تحليل التعقيد الزمني والمكاني'
                : 'Write, debug, and explain algorithms across top languages with Big-O complexity notes'}
            </p>
          </div>
        </div>

        {/* Task Type Switcher */}
        <div className="flex flex-wrap gap-2 pt-4">
          {taskTypes.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSelectedTask(t.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedTask === t.id
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md'
                  : 'bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 border border-purple-900/30'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Language Selection */}
        <div className="pt-4 flex items-center gap-2 overflow-x-auto scrollbar-none pb-1">
          <span className="text-xs font-bold text-purple-400 shrink-0">
            {isAr ? 'اللغة:' : 'Language:'}
          </span>
          {languages.map((l) => (
            <button
              key={l}
              type="button"
              onClick={() => setSelectedLang(l)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                selectedLang === l
                  ? 'bg-purple-600 text-white border border-purple-400 shadow-sm'
                  : 'bg-[#180d33] hover:bg-purple-900/40 text-purple-300/80 border border-purple-900/30'
              }`}
            >
              {l}
            </button>
          ))}
        </div>

        {/* Presets */}
        <div className="pt-4">
          <span className="text-[11px] font-bold text-purple-400/80 block mb-2">
            {isAr ? 'أمثلة سريعة جاهزة:' : 'Quick Coding Ideas:'}
          </span>
          <div className="flex flex-wrap gap-2">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCodePrompt(preset)}
                className="text-xs bg-[#190f33] hover:bg-purple-900/50 text-purple-200 px-3 py-1.5 rounded-xl border border-purple-800/30 text-start cursor-pointer transition-all"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <textarea
            value={codePrompt}
            onChange={(e) => setCodePrompt(e.target.value)}
            rows={3}
            disabled={isLoading}
            placeholder={
              isAr
                ? 'صف الخوارزمية، الكود المطلوب كتابته، أو الصق كوداً به خطأ لتصحيحه وتوضيح أسبابه...'
                : 'Describe the feature, algorithm, or paste buggy code to debug...'
            }
            className="w-full bg-[#0a0515] border border-purple-900/50 focus:border-cyan-500 rounded-2xl p-4 text-xs sm:text-sm text-white placeholder-purple-400/40 focus:outline-none focus:ring-1 focus:ring-cyan-500 transition-all font-mono"
          />

          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={!codePrompt.trim() || isLoading}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 hover:from-cyan-400 hover:to-pink-400 disabled:opacity-40 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-purple-950/60 flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isLoading ? (isAr ? 'جاري التحليل والبرمجة...' : 'Writing Code...') : (isAr ? 'تنفيذ وتوليد الكود' : 'Run / Generate')}</span>
            </button>

            {codePrompt && !isLoading && (
              <button
                type="button"
                onClick={() => {
                  setCodePrompt('');
                  setResult(null);
                  setError(null);
                }}
                className="px-4 py-3 rounded-2xl bg-purple-950/40 hover:bg-purple-900/40 text-purple-300 text-xs font-semibold cursor-pointer"
              >
                {isAr ? 'مسح' : 'Clear'}
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 bg-red-950/40 border border-red-500/40 rounded-2xl flex items-center justify-between text-xs text-red-200">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => handleSubmit()}
            className="px-3 py-1 bg-red-600 text-white rounded-xl font-bold flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isAr ? 'إعادة المحاولة' : 'Retry'}</span>
          </button>
        </div>
      )}

      {/* Solution Display */}
      {result && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#120b24] rounded-3xl p-6 sm:p-8 border border-purple-900/40 shadow-2xl space-y-6"
        >
          {/* Top Info Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-purple-900/30">
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-cyan-400" />
              <span className="text-sm font-black text-white">{result.language} Solution</span>
              {result.timeComplexity && (
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-[11px] font-mono font-bold">
                  ⏱️ {result.timeComplexity}
                </span>
              )}
              {result.spaceComplexity && (
                <span className="px-2.5 py-0.5 rounded-full bg-purple-950/80 border border-purple-500/30 text-purple-300 text-[11px] font-mono font-bold">
                  💾 {result.spaceComplexity}
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={copyCode}
              className="px-3.5 py-1.5 rounded-xl bg-purple-900/50 hover:bg-purple-800/50 border border-purple-700/40 text-purple-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedCode ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">{isAr ? 'تم نسخ الكود' : 'Copied!'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isAr ? 'نسخ الكود' : 'Copy Code'}</span>
                </>
              )}
            </button>
          </div>

          {/* Code Block with Dark Synthwave Terminal Styling */}
          <div className="rounded-2xl overflow-hidden border border-purple-700/40 bg-[#06030c] shadow-2xl">
            <div className="px-4 py-2 bg-[#0c0617] border-b border-purple-900/40 flex items-center justify-between text-xs text-purple-400 font-mono">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                <span className="ms-2 font-semibold text-purple-300">{result.language.toLowerCase()}_solution</span>
              </div>
              <span>Mind AI Engine</span>
            </div>
            <pre className="p-4 sm:p-5 text-xs sm:text-sm text-cyan-200 font-mono overflow-x-auto leading-relaxed select-all">
              <code>{result.code}</code>
            </pre>
          </div>

          {/* Technical Explanation */}
          <div className="p-4 rounded-2xl bg-purple-950/30 border border-purple-800/30 text-xs sm:text-sm text-purple-200 leading-relaxed">
            <h4 className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-400" />
              <span>{isAr ? 'الشرح الهندسي والخوارزمي:' : 'Algorithmic Explanation:'}</span>
            </h4>
            <p className="whitespace-pre-line">{result.explanation}</p>
          </div>

          {/* Best Practices */}
          {result.bestPractices && result.bestPractices.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isAr ? 'أفضل الممارسات المعتمدة:' : 'Industry Best Practices:'}</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {result.bestPractices.map((bp, i) => (
                  <div key={i} className="p-3 rounded-xl bg-black/40 border border-purple-900/30 text-xs text-purple-200">
                    • {bp}
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};
