import { LessonItem, UserLessonProgress } from '../types';
import { initialMoroccanLessons } from '../data/moroccanLessonsData';

const CUSTOM_LESSONS_KEY = 'edusmart_custom_lessons';
const LESSON_PROGRESS_KEY = 'edusmart_lesson_progress';
const FAVORITES_KEY = 'edusmart_lesson_favorites';

export class LessonProgressService {
  // Retrieve all lessons: base Moroccan curriculum + user custom lessons
  getAllLessons(): LessonItem[] {
    const custom = this.getCustomLessons();
    return [...initialMoroccanLessons, ...custom];
  }

  getCustomLessons(): LessonItem[] {
    try {
      const raw = localStorage.getItem(CUSTOM_LESSONS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.warn('Failed to load custom lessons:', e);
      return [];
    }
  }

  saveCustomLesson(lesson: LessonItem): void {
    const current = this.getCustomLessons();
    const updated = [lesson, ...current.filter((l) => l.id !== lesson.id)];
    localStorage.setItem(CUSTOM_LESSONS_KEY, JSON.stringify(updated));
  }

  // Favorites
  getFavorites(): string[] {
    try {
      const raw = localStorage.getItem(FAVORITES_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  isFavorite(lessonId: string): boolean {
    return this.getFavorites().includes(lessonId);
  }

  toggleFavorite(lessonId: string): boolean {
    const favs = this.getFavorites();
    const exists = favs.includes(lessonId);
    let updated: string[];
    if (exists) {
      updated = favs.filter((id) => id !== lessonId);
    } else {
      updated = [...favs, lessonId];
    }
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    return !exists;
  }

  // Progress tracking (completed status & quiz results)
  getProgressMap(): Record<string, UserLessonProgress> {
    try {
      const raw = localStorage.getItem(LESSON_PROGRESS_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }

  getLessonProgress(lessonId: string): UserLessonProgress {
    const map = this.getProgressMap();
    return (
      map[lessonId] || {
        lessonId,
        completed: false,
        isFavorite: this.isFavorite(lessonId),
      }
    );
  }

  toggleCompleted(lessonId: string): boolean {
    const map = this.getProgressMap();
    const current = map[lessonId] || {
      lessonId,
      completed: false,
      isFavorite: this.isFavorite(lessonId),
    };
    const newState = !current.completed;
    map[lessonId] = {
      ...current,
      completed: newState,
      completedAt: newState ? new Date().toISOString() : undefined,
    };
    localStorage.setItem(LESSON_PROGRESS_KEY, JSON.stringify(map));
    return newState;
  }

  saveQuizScore(lessonId: string, score: number, total: number): void {
    const map = this.getProgressMap();
    const current = map[lessonId] || {
      lessonId,
      completed: false,
      isFavorite: this.isFavorite(lessonId),
    };
    const passed = score >= Math.ceil(total * 0.6);
    map[lessonId] = {
      ...current,
      quizScore: Math.max(current.quizScore || 0, score),
      quizTotal: total,
      quizPassed: passed,
      completed: current.completed || passed,
      lastStudiedAt: new Date().toISOString(),
    };
    localStorage.setItem(LESSON_PROGRESS_KEY, JSON.stringify(map));
  }

  getStats(subjectId?: string) {
    const all = this.getAllLessons();
    const filtered = subjectId ? all.filter((l) => l.subjectId === subjectId) : all;
    const map = this.getProgressMap();

    const total = filtered.length;
    const completed = filtered.filter((l) => map[l.id]?.completed).length;
    const favorites = filtered.filter((l) => this.isFavorite(l.id)).length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;

    return {
      total,
      completed,
      incomplete: total - completed,
      favorites,
      percentage,
    };
  }
}

export const lessonProgressService = new LessonProgressService();
