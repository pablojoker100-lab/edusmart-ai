import { UserProfile, EducationLevel, UserProgressData, StudyHistoryItem } from '../types';

const TOKEN_KEY = 'edusmart_auth_token';
const USER_KEY = 'edusmart_auth_user';

export const DEPLOYMENT_URL = 'https://ais-pre-ductfgt52qanruqecw7ato-855255389466.europe-west2.run.app';

export interface AuthResponse {
  success: boolean;
  token?: string;
  user?: UserProfile;
  message?: string;
  error?: string;
  resetCode?: string;
}

class AuthService {
  getDeploymentUrl(): string {
    if (typeof window !== 'undefined' && window.location.origin && !window.location.origin.includes('localhost') && !window.location.origin.includes('127.0.0.1')) {
      return window.location.origin;
    }
    return DEPLOYMENT_URL;
  }

  getToken(): string | null {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  }

  saveSession(token: string, user: UserProfile) {
    try {
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }

  clearSession() {
    try {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    } catch (e) {
      console.warn('Storage error:', e);
    }
  }

  getSavedUser(): UserProfile | null {
    try {
      const data = localStorage.getItem(USER_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  async register(
    email: string,
    password: string,
    name?: string,
    level?: EducationLevel
  ): Promise<AuthResponse> {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name, level }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || 'فشل إنشاء الحساب');
      }

      if (data.token && data.user) {
        this.saveSession(data.token, data.user);
      }
      return data;
    } catch (err: any) {
      return { success: false, message: err.message || 'حدث خطأ في الاتصال بالخادم' };
    }
  }

  async login(email: string, password: string): Promise<AuthResponse> {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || 'بيانات الدخول غير صحيحة');
      }

      if (data.token && data.user) {
        this.saveSession(data.token, data.user);
      }
      return data;
    } catch (err: any) {
      return { success: false, message: err.message || 'حدث خطأ أثناء تسجيل الدخول' };
    }
  }

  async loginWithGoogle(email?: string, name?: string, avatar?: string, level?: EducationLevel): Promise<AuthResponse> {
    try {
      const googleEmail = email || 'student@gmail.com';
      const googleName = name || 'طالب متميز';
      const googleAvatar = avatar || 'https://lh3.googleusercontent.com/a/default-user';

      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: googleEmail,
          name: googleName,
          avatar: googleAvatar,
          level: level || 'high',
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || 'فشل تسجيل الدخول بحساب Google');
      }

      if (data.token && data.user) {
        this.saveSession(data.token, data.user);
      }
      return data;
    } catch (err: any) {
      return { success: false, message: err.message || 'حدث خطأ في الاتصال بـ Google' };
    }
  }

  async logout(): Promise<void> {
    const token = this.getToken();
    if (token) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        });
      } catch (err) {
        console.warn('Logout network error:', err);
      }
    }
    this.clearSession();
  }

  async checkCurrentSession(): Promise<UserProfile | null> {
    const token = this.getToken();
    if (!token) return null;

    try {
      const res = await fetch('/api/auth/me', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        if (data.user) {
          localStorage.setItem(USER_KEY, JSON.stringify(data.user));
          return data.user;
        }
      }
    } catch {
      // Fallback to locally cached user if network is momentarily unavailable
    }

    return this.getSavedUser();
  }

  async forgotPassword(email: string): Promise<AuthResponse> {
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, message: err.message || 'فشل إرسال طلب استعادة كلمة المرور' };
    }
  }

  async resetPassword(email: string, resetCode: string, newPassword: string): Promise<AuthResponse> {
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, resetCode, newPassword }),
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, message: err.message || 'فشل إعادة تعيين كلمة المرور' };
    }
  }

  async getUserProgress(): Promise<UserProgressData> {
    const token = this.getToken();
    const fallback: UserProgressData = {
      solvedCount: 0,
      quizzesTaken: 0,
      averageScore: 0,
      history: [],
    };

    try {
      const res = await fetch('/api/user/progress', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn('Could not fetch progress:', e);
    }
    return fallback;
  }

  async recordActivity(item: {
    type: 'solve' | 'quiz' | 'summary' | 'explain';
    title: string;
    subject?: string;
    score?: string;
    details?: any;
  }): Promise<UserProgressData | null> {
    const token = this.getToken();
    try {
      const res = await fetch('/api/user/progress', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(item),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn('Could not record activity:', e);
    }
    return null;
  }

  async clearStudyHistory(): Promise<boolean> {
    const token = this.getToken();
    if (!token) return false;
    try {
      const res = await fetch('/api/user/progress/history', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      return res.ok;
    } catch {
      return false;
    }
  }
}

export const authService = new AuthService();
