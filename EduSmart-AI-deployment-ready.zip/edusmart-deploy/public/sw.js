/**
 * Mind AI - Service Worker
 * Progressive Web App (PWA) Offline & Caching Engine
 */

const CACHE_NAME = 'mind-ai-v2';

// Core Application Shell Assets to Pre-cache
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.svg',
  '/icons/icon.svg',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/icons/icon-maskable-512x512.png',
  '/icons/apple-touch-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png',
  '/apple-touch-icon.png'
];

// Install Event: Pre-cache App Shell & Activate immediately
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Mind AI SW] Pre-caching offline application shell');
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn('[Mind AI SW] Non-fatal precache warning:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activate Event: Clear obsolete caches & claim active clients
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            console.log('[Mind AI SW] Purging obsolete cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch Event: Intelligent Caching Strategy
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // 1. Never cache non-GET requests (e.g. POST /api/...)
  if (request.method !== 'GET') {
    return;
  }

  // 2. Bypass API requests to ensure real-time AI & Auth, with graceful offline fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request).catch(() => {
        return new Response(
          JSON.stringify({
            offline: true,
            error: 'OFFLINE_MODE',
            message: 'أنت في وضع عدم الاتصال حالياً. سيتم حفظ طلبك محلياً حتى استعادة الاتصال بالإنترنت.'
          }),
          {
            status: 503,
            headers: { 'Content-Type': 'application/json; charset=utf-8' }
          }
        );
      })
    );
    return;
  }

  // 3. Cache-First for External Fonts (Google Fonts) & Static Media
  if (
    url.hostname.includes('fonts.googleapis.com') ||
    url.hostname.includes('fonts.gstatic.com') ||
    url.pathname.match(/\.(png|jpg|jpeg|svg|webp|ico|woff|woff2)$/)
  ) {
    event.respondWith(
      caches.match(request).then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }
        return fetch(request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseToCache);
            });
          }
          return networkResponse;
        }).catch(() => {
          // If offline and requesting an image, return default fallback if available
          if (request.destination === 'image') {
            return caches.match('/favicon.svg');
          }
        });
      })
    );
    return;
  }

  // 4. Stale-While-Revalidate for App Shell & Navigation
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      const fetchPromise = fetch(request).then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, responseToCache);
          });
        }
        return networkResponse;
      }).catch((fetchError) => {
        // If navigation request fails offline, serve root index.html
        if (request.mode === 'navigate') {
          return caches.match('/index.html') || caches.match('/');
        }
        throw fetchError;
      });

      return cachedResponse || fetchPromise;
    })
  );
});
